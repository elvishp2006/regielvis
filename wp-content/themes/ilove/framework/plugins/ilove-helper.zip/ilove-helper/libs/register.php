<?php
	/*-----------------------------------------------------------------------------------*/
	/*  Register Post Type
	/*-----------------------------------------------------------------------------------*/
	add_action( 'init', 'ilove_register_post_type' );
	function ilove_register_post_type()
	{
		// Family Members
		$labels_member = array(
			'name' 					=> __('Family Members', 'post type general name', 'plutonthemes'),
			'singular_name' 		=> __('Family Members', 'post type singular name', 'plutonthemes'),
			'add_new' 				=> __('Add New', 'member', 'plutonthemes'),
			'all_items' 			=> __('All Members', 'plutonthemes'),
			'add_new_item' 			=> __('Add New Members', 'plutonthemes'),
			'edit_item' 			=> __('Edit Members', 'plutonthemes'),
			'new_item' 				=> __('New Members', 'plutonthemes'),
			'view_item' 			=> __('View Members', 'plutonthemes'),
			'search_items' 			=> __('Search Family Members', 'plutonthemes'),
			'not_found' 			=> __('No Family Members Found', 'plutonthemes'),
			'not_found_in_trash' 	=> __('No Family Members Found in Trash', 'plutonthemes'),
			'parent_item_colon' 	=> '',
		);
		$args_member = array(
			'labels' 			=> $labels_member,
			'public' 			=> true,
			'show_ui' 			=> true,
			'capability_type' 	=> 'post',
			'hierarchical' 		=> false,
			'rewrite'			=> false,
			'query_var' 		=> true,
			'show_in_nav_menus' => false,
			'menu_icon' 		=> 'dashicons-groups',
			'supports' 			=> array('title', 'thumbnail', 'editor'),
		);
		register_post_type( 'member' , $args_member );
		register_taxonomy( 'member_cats',
			array('member'),
			array(
				'hierarchical' 		=> true,
				'label' 			=> 'Members Category',
				'show_admin_column'	=> 'true',
				'singular_label' 	=> 'Members Category',
				'rewrite' 			=> true,
				'query_var' 		=> true,
			)
		);


		// Portfolio
		$labels_po = array(
			'name' 					=> __('Portfolio', 'post type general name', 'plutonthemes'),
			'singular_name' 		=> __('Portfolio', 'post type singular name', 'plutonthemes'),
			'add_new' 				=> __('Add New', 'portfolio', 'plutonthemes'),
			'all_items' 			=> __('All Portfolio', 'plutonthemes'),
			'add_new_item' 			=> __('Add New Portfolio', 'plutonthemes'),
			'edit_item' 			=> __('Edit Portfolio', 'plutonthemes'),
			'new_item' 				=> __('New Portfolio', 'plutonthemes'),
			'view_item' 			=> __('View Portfolio', 'plutonthemes'),
			'search_items' 			=> __('Search Portfolio', 'plutonthemes'),
			'not_found' 			=> __('No Portfolio Found', 'plutonthemes'),
			'not_found_in_trash' 	=> __('No Portfolio Found in Trash', 'plutonthemes'),
			'parent_item_colon' 	=> '',
		);
		$args_po = array(
			'labels' 			=> $labels_po,
			'public' 			=> true,
			'show_ui' 			=> true,
			'capability_type' 	=> 'post',
			'hierarchical' 		=> false,
			'rewrite'           => false,
			'query_var' 		=> true,
			'show_in_nav_menus' => false,
			'menu_icon' 		=> 'dashicons-book',
			'supports' 			=> array('title', 'thumbnail', 'editor',),
		);
		register_post_type( 'portfolio' , $args_po );


		// Time Line
		$labels_ti = array(
			'name' 					=> __('Time Line', 'post type general name', 'plutonthemes'),
			'singular_name' 		=> __('Time Line', 'post type singular name', 'plutonthemes'),
			'add_new' 				=> __('Add New', 'time_line', 'plutonthemes'),
			'all_items' 			=> __('All Time Line', 'plutonthemes'),
			'add_new_item' 			=> __('Add New Time Line', 'plutonthemes'),
			'edit_item' 			=> __('Edit Time Line', 'plutonthemes'),
			'new_item' 				=> __('New Time Line', 'plutonthemes'),
			'view_item' 			=> __('View Time Line', 'plutonthemes'),
			'search_items' 			=> __('Search Time Line', 'plutonthemes'),
			'not_found' 			=> __('No Time Line Found', 'plutonthemes'),
			'not_found_in_trash' 	=> __('No Time Line Found in Trash', 'plutonthemes'),
			'parent_item_colon' 	=> '',
		);
		$args_ti = array(
			'labels' 			=> $labels_ti,
			'public' 			=> true,
			'show_ui' 			=> true,
			'capability_type' 	=> 'post',
			'hierarchical' 		=> false,
			'rewrite'			=> false,
			'query_var' 		=> true,
			'show_in_nav_menus' => false,
			'menu_icon' 		=> 'dashicons-backup',
			'supports' 			=> array('title', 'editor'),
		);
		register_post_type( 'time_line' , $args_ti );


		// Favourites
		$labels_fa = array(
			'name' 					=> __('Favourites', 'post type general name', 'plutonthemes'),
			'singular_name' 		=> __('Favourites', 'post type singular name', 'plutonthemes'),
			'add_new' 				=> __('Add New', 'favourites', 'plutonthemes'),
			'all_items' 			=> __('All Favourites', 'plutonthemes'),
			'add_new_item' 			=> __('Add New Favourites', 'plutonthemes'),
			'edit_item' 			=> __('Edit Favourites', 'plutonthemes'),
			'new_item' 				=> __('New Favourites', 'plutonthemes'),
			'view_item' 			=> __('View Favourites', 'plutonthemes'),
			'search_items' 			=> __('Search Favourites', 'plutonthemes'),
			'not_found' 			=> __('No Favourites Found', 'plutonthemes'),
			'not_found_in_trash' 	=> __('No Favourites Found in Trash', 'plutonthemes'),
			'parent_item_colon' 	=> '',
		);
		$args_fa = array(
			'labels' 			=> $labels_fa,
			'public' 			=> true,
			'show_ui' 			=> true,
			'capability_type' 	=> 'post',
			'hierarchical' 		=> false,
			'rewrite'			=> false,
			'query_var' 		=> true,
			'show_in_nav_menus' => false,
			'menu_icon' 		=> 'dashicons-smiley',
			'supports' 			=> array('title'),
		);
		register_post_type( 'favourites' , $args_fa );

	}
