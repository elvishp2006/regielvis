<?php
/**
 * Include and setup custom metaboxes and fields.
 *
 * @category YourThemeOrPlugin
 * @package  Metaboxes
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/webdevstudios/Custom-Metaboxes-and-Fields-for-WordPress
 */

add_filter( 'cmb_meta_boxes', 'ilove_sample_metaboxes' );
/**
 * Define the metabox and field configurations.
 *
 * @param  array $meta_boxes
 * @return array
 */
function ilove_sample_metaboxes( array $meta_boxes ) {

	// Start with an underscore to hide fields from custom fields list
	$prefix = 'vm_';


	/**
	 * Sample metabox to demonstrate each field type included
	 */
	$meta_boxes['post_metabox'] = array(

	  'title' => 'Post metas',
	  'pages' => array('post'),
	  'context'    => 'normal',
	  'id'         => $prefix . 'post_metas',
	  'priority'   => 'low',
	  'show_names' => true, // Show field names on the left
	  'fields' => array(
		   	array(
		       'name' => 'Gallery',
		       'desc' => '',
		       'id' => $prefix .'gallery',
		       'type' => 'file_list',
		       'preview_size' => array( 100, 100 ), // Default: array( 50, 50 )
		   	),
		   	array(
		       'name' => 'Post Image',
		       'desc' => 'Upload an image or enter an URL.',
		       'id' => $prefix . 'image',
		       'type' => 'file',
		       'allow' => array( 'url', 'attachment' ) // limit to just attachments with array( 'attachment' )
		   	),
		   	array(
			    'name' => __( 'Video oEmbed', 'plutonthemes' ),
			    'desc' => __( 'Enter a youtube, vimeo URL. Supports services listed at <a href="http://codex.wordpress.org/Embeds">http://codex.wordpress.org/Embeds</a>.', 'plutonthemes' ),
			    'id'   => $prefix . 'video',
			    'type' => 'oembed',
		   	),
		   	array(
			    'name' => __( 'Audio oEmbed', 'plutonthemes' ),
			    'desc' => __( 'Enter a soundcloud URL.', 'plutonthemes' ),
			    'id'   => $prefix . 'audio',
			    'type' => 'oembed',
		   	),
	  	)

	);


	/**
	 * Sample metabox to demonstrate each field type included
	 */
	$meta_boxes['portfolio_metabox'] = array(
		'id'         => 'plutonvm_portfolio_metabox',
		'title'      => __( 'Portfolio Metas', 'plutonthemes' ),
		'pages'      => array( 'portfolio' ), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true,
		'fields'     => array(
			array(
				'name' => __( 'Post By', 'plutonthemes' ),
				'id'   => $prefix . 'po_by',
				'type' => 'text',
			)
		),
	);


	/**
	 * Sample metabox to demonstrate each field type included
	 */
	$meta_boxes['time_line_metabox'] = array(
		'id'         => 'plutonvm_time_line_metabox',
		'title'      => __( 'Time Line Metas', 'plutonthemes' ),
		'pages'      => array( 'time_line' ), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true,
		'fields'     => array(
			array(
				'name' => __( 'Date and Author', 'plutonthemes' ),
				'desc' => __( 'Insert date and author', 'plutonthemes' ),
				'id'   => $prefix . 'time_date',
				'type' => 'text',
			),
			array(
				'name'		=> __( 'Select Icon', 'plutonthemes' ),
				'desc'		=> __( 'Select icon display for post', 'plutonthemes' ),
				'id'		=> $prefix . 'time_icon',
				'type'		=> 'select',
				'options'	=> array(
					'icolove' => __( 'Icon Font Love', 'plutonthemes' ),
					'awesome' => __( 'Icon Font Awesome', 'plutonthemes' )
				)
			),
			array(
				'name'		=> __( 'Select Icon', 'plutonthemes' ),
				'desc'		=> __( 'Select icon display for post', 'plutonthemes' ),
				'id'		=> $prefix . 'time_icolove',
				'type'		=> 'select',
				'options'	=> array(
					'icolove-babyboy' => 'Baby Boy',
					'icolove-babygirl' => 'Baby Girl',
					'icolove-book' => 'Book',
					'icolove-clothes' => 'Clothes',
					'icolove-coffee' => 'Coffee',
					'icolove-football' => 'Football',
					'icolove-gamepad' => 'Gamepad',
					'icolove-graduate' => 'Graduate',
					'icolove-home' => 'Home',
					'icolove-like' => 'Like',
					'icolove-lips' => 'Lips',
					'icolove-married' => 'Married',
					'icolove-mic' => 'Mic',
					'icolove-music' => 'Music',
					'icolove-pet' => 'Pet',
					'icolove-place' => 'Place',
					'icolove-plane' => 'Plane',
					'icolove-pregnancy' => 'Pregnancy',
					'icolove-ring' => 'Ring',
					'icolove-film' => 'Film',
					'icolove-car' => 'Car',
					'icolove-meal' => 'Meal',
					'icolove-palette' => 'Palette',
					'icolove-weather' => 'Weather',
					'icolove-movie' => 'Movie',
					'icolove-party' => 'Party',
					'icolove-gallery' => 'Gallery',
					'icolove-broken-heart' => 'Broken Heart',
				)
			),
			array(
				'name' => __( 'Class Font Awesome', 'plutonthemes' ),
				'desc' => __( 'Insert class font awesome example: (fa-facebook)', 'plutonthemes' ),
				'id'   => $prefix . 'time_awesome',
				'type' => 'text',
			)
		),
	);


	/**
	 * Sample metabox to demonstrate each field type included
	 */
	$meta_boxes['favourites_metabox'] = array(
		'id'         => 'plutonvm_favourites_metabox',
		'title'      => __( 'Favourites Metas', 'plutonthemes' ),
		'pages'      => array( 'favourites' ), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true,
		'fields'     => array(
			array(
				'name'		=> __( 'Select Icon', 'plutonthemes' ),
				'desc'		=> __( 'Select icon display for post', 'plutonthemes' ),
				'id'		=> $prefix . 'fa_icon',
				'type'		=> 'select',
				'options'	=> array(
					'icolove' => __( 'Icon Font Love', 'plutonthemes' ),
					'awesome' => __( 'Icon Font Awesome', 'plutonthemes' )
				)
			),
			array(
				'name'		=> __( 'Select Icon', 'plutonthemes' ),
				'desc'		=> __( 'Select icon display for post', 'plutonthemes' ),
				'id'		=> $prefix . 'fa_icolove',
				'type'		=> 'select',
				'options'	=> array(
					'icolove-babyboy' => 'Baby Boy',
					'icolove-babygirl' => 'Baby Girl',
					'icolove-book' => 'Book',
					'icolove-clothes' => 'Clothes',
					'icolove-coffee' => 'Coffee',
					'icolove-football' => 'Football',
					'icolove-gamepad' => 'Gamepad',
					'icolove-graduate' => 'Graduate',
					'icolove-home' => 'Home',
					'icolove-like' => 'Like',
					'icolove-lips' => 'Lips',
					'icolove-married' => 'Married',
					'icolove-mic' => 'Mic',
					'icolove-music' => 'Music',
					'icolove-pet' => 'Pet',
					'icolove-place' => 'Place',
					'icolove-plane' => 'Plane',
					'icolove-pregnancy' => 'Pregnancy',
					'icolove-ring' => 'Ring',
					'icolove-film' => 'Film',
					'icolove-car' => 'Car',
					'icolove-meal' => 'Meal',
					'icolove-palette' => 'Palette',
					'icolove-weather' => 'Weather',
					'icolove-movie' => 'Movie',
					'icolove-party' => 'Party',
					'icolove-gallery' => 'Gallery',
					'icolove-broken-heart' => 'Broken Heart',
				)
			),
			array(
				'name' => __( 'Class Font Awesome', 'plutonthemes' ),
				'desc' => __( 'Insert class font awesome example: (fa-facebook)', 'plutonthemes' ),
				'id'   => $prefix . 'fa_awesome',
				'type' => 'text',
			),
			array(
				'name' => __( 'Title Groom', 'plutonthemes' ),
				'desc' => __( 'Title groom display', 'plutonthemes' ),
				'id'   => $prefix . 'fa_gr_title',
				'type' => 'text',
			),
			array(
				'name' => __( 'Description Groom', 'plutonthemes' ),
				'desc' => __( 'Description groom display', 'plutonthemes' ),
				'id'   => $prefix . 'fa_gr_desc',
				'type' => 'textarea',
			),
			array(
				'name' => __( 'Title Bride', 'plutonthemes' ),
				'desc' => __( 'Title bride display', 'plutonthemes' ),
				'id'   => $prefix . 'fa_br_title',
				'type' => 'text',
			),
			array(
				'name' => __( 'Description Bride', 'plutonthemes' ),
				'desc' => __( 'Description bride display', 'plutonthemes' ),
				'id'   => $prefix . 'fa_br_desc',
				'type' => 'textarea',
			)
		),
	);



	/**
	 * Sample metabox to demonstrate each field type included
	 */
	$meta_boxes['member_metabox'] = array(
		'id'         => 'plutonvm_member_metabox',
		'title'      => __( 'Members Metas', 'plutonthemes' ),
		'pages'      => array( 'member' ), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		'fields'     => array(
			array(
				'name' => __( 'Relationship', 'plutonthemes' ),
				'desc' => __( 'Relationship for groom and bride', 'plutonthemes' ),
				'id'   => $prefix . 'member_relationship',
				'type' => 'text',
			),
			array(
				'name' => __( 'Link Twitter', 'plutonthemes' ),
				'id'   => $prefix . 'member_twitter',
				'type' => 'text',
			),
			array(
				'name' => __( 'Link Facebook', 'plutonthemes' ),
				'id'   => $prefix . 'member_facebook',
				'type' => 'text',
			),
			array(
				'name' => __( 'Link Youtube', 'plutonthemes' ),
				'id'   => $prefix . 'member_youtube',
				'type' => 'text',
			),
			array(
				'name' => __( 'Link Google Plus', 'plutonthemes' ),
				'id'   => $prefix . 'member_googleplus',
				'type' => 'text',
			),
			array(
				'name' => __( 'Link Pinterest', 'plutonthemes' ),
				'id'   => $prefix . 'member_pinterest',
				'type' => 'text',
			)
		),
	);


	/**
	 * Metabox for the user profile screen
	 */
	$meta_boxes['user_edit'] = array(
		'id'         => 'user_edit',
		'title'      => __( 'User Profile Metabox', 'cmb' ),
		'pages'      => array( 'user' ), // Tells CMB to use user_meta vs post_meta
		'show_names' => true,
		'cmb_styles' => false, // Show cmb bundled styles.. not needed on user profile page
		'fields'     => array(
			array(
				'name' => __( 'Facebook URL', 'cmb' ),
				'id'   => $prefix . 'facebookurl',
				'type' => 'text_url',
			),
			array(
				'name' => __( 'Twitter URL', 'cmb' ),
				'id'   => $prefix . 'twitterurl',
				'type' => 'text_url',
			),
			array(
				'name' => __( 'Google+ URL', 'cmb' ),
				'id'   => $prefix . 'googleplusurl',
				'type' => 'text_url',
			),
			array(
				'name' => __( 'Linkedin URL', 'cmb' ),
				'id'   => $prefix . 'linkedinurl',
				'type' => 'text_url',
			)
		)
	);

	/**
	 * Metabox for an options page. Will not be added automatically, but needs to be called with
	 * the `cmb_metabox_form` helper function. See wiki for more info.
	 */
	$meta_boxes['options_page'] = array(
		'id'      => 'options_page',
		'title'   => __( 'Theme Options Metabox', 'cmb' ),
		'show_on' => array( 'key' => 'options-page', 'value' => array( $prefix . 'theme_options', ), ),
		'fields'  => array(
			array(
				'name'    => __( 'Site Background Color', 'cmb' ),
				'desc'    => __( 'field description (optional)', 'cmb' ),
				'id'      => $prefix . 'bg_color',
				'type'    => 'colorpicker',
				'default' => '#ffffff'
			),
		)
	);

	// Add other metaboxes as needed

	return $meta_boxes;
}

add_action( 'init', 'ilove_initialize_cmb_meta_boxes', 9999 );
/**
 * Initialize the metabox class.
 */
function ilove_initialize_cmb_meta_boxes() {

	if ( ! class_exists( 'cmb_Meta_Box' ) )
		require_once ILOVE_HELPER_PATH . '/metaboxes/init.php';

}
