<?php
global $mini;

if( !function_exists( 'ilove_extend_mini_composer' ) ){

	add_action( 'init', 'ilove_extend_mini_composer' );
	function ilove_extend_mini_composer() {

		global $mini;

		$member_cate = get_categories( 'taxonomy=member_cats&hide_empty=0' );
		$member_list = array();
		foreach ( $member_cate as $cat ) {
			$member_list[ $cat->cat_ID ] = $cat->name;
		}

		$blog_cats = get_categories();
		$blog_list = array();
		foreach ( $blog_cats as $bcat ) {
			$blog_list[$bcat->cat_ID] = $bcat->name;
		}
		wp_reset_postdata();
		wp_reset_query();

		$mini_map = array(
			'ilove_title' => array(
				'name' => 'Title',
				'description' => __('Display title and description', 'plutonthemes'),
				'icon' => 'fa-font',
				'category' => 'ilove Theme',
				'params' => array(
					array(
						'name' => 'title',
						'label' => __( 'Title', 'plutonthemes' ),
						'type' => 'text',
						'admin_label' => true,
						'description' => __( 'Insert title', 'plutonthemes' ),
						'value' => 'Insert Text'
					),
					array(
						'name' => 'desc',
						'label' => 'Content',
						'type' => 'textarea',
						'value' => '',
					),
					array(
						'name' 		=> 'style',
						'label'		=> __( 'Style Display', 'plutonthemes' ),
						'type' 		=> 'select',
						'options'	=> array(
							'1' => __('Black', 'plutonthemes'),
							'2' => __('White', 'plutonthemes')
						)
					),
					array(
						'name' => 'class',
						'label' => __( 'Extract Class', 'plutonthemes' ),
						'type' => 'text',
						'description' => __( 'Insert class', 'plutonthemes' ),
						'value' => ''
					)
				)
			),
			'ilove_couple' => array(
				'name' => 'Groom and Bride',
				'description' => __('Display groom and bride', 'plutonthemes'),
				'icon' => 'fa-heart',
				'category' => 'ilove Theme',
				'params' => array(
					array(
						'name' => 'groom_name',
						'label' => __( 'Name Groom', 'plutonthemes' ),
						'type' => 'text',
						'admin_label' => true,
						'description' => __( 'Insert Name', 'plutonthemes' ),
						'value' => ''
					),
					array(
						'name' => 'groom_desc',
						'label' => __( 'Description Groom', 'plutonthemes' ),
						'type' => 'textarea',
						'value' => '',
					),
					array(
						'name' => 'groom_image',
						'label' => __( 'Groom Image', 'plutonthemes' ),
						'type' => 'attach_image',
					),
					array(
						'name' => 'title',
						'label' => __( 'Key', 'plutonthemes' ),
						'type' => 'text',
						'value' => '&'
					),
					array(
						'name' => 'bride_name',
						'label' => __( 'Name Bride', 'plutonthemes' ),
						'type' => 'text',
						'admin_label' => true,
						'description' => __( 'Insert Name', 'plutonthemes' ),
						'value' => ''
					),
					array(
						'name' => 'bride_desc',
						'label' => __( 'Description Bride', 'plutonthemes' ),
						'type' => 'textarea',
						'value' => '',
					),
					array(
						'name' => 'bride_image',
						'label' => __( 'Bride Image', 'plutonthemes' ),
						'type' => 'attach_image',
					)
				)
			),
			'ilove_time_line' => array(
				'name' => 'Time Line',
				'description' => __('Display time line list post', 'plutonthemes'),
				'icon' => 'fa-clock-o',
				'category' => 'ilove Theme',
				'params' => array(
					array(
						'name' => 'number',
						'label' => __( 'Number Post', 'plutonthemes' ),
						'type' => 'text',
						'admin_label' => true,
						'description' => __( 'Insert number post display', 'plutonthemes' ),
						'value' => '5'
					),
					array(
						'name' 		=> 'oder',
						'label'		=> __( 'Order', 'plutonthemes' ),
						'type' 		=> 'select',
						'options'	=> array(
							'ASC' => __('By ASC', 'plutonthemes'),
							'DESC' => __('By DESC', 'plutonthemes')
						)
					)
				)
			),
			'ilove_favourites' => array(
				'name' => 'Favourites',
				'description' => __('Display favourites list post', 'plutonthemes'),
				'icon' => 'fa-smile-o',
				'category' => 'ilove Theme',
				'params' => array(
					array(
						'name' => 'number',
						'label' => __( 'Number Post', 'plutonthemes' ),
						'type' => 'text',
						'admin_label' => true,
						'description' => __( 'Insert number post display', 'plutonthemes' ),
						'value' => '4'
					),
					array(
						'name' 		=> 'style',
						'label'		=> __( 'Style Display', 'plutonthemes' ),
						'type' 		=> 'select',
						'options'	=> array(
							'1' => __('List', 'plutonthemes'),
							'2' => __('Owl Carousel', 'plutonthemes')
						)
					),
					array(
						'name' 		=> 'order',
						'label'		=> __( 'Order', 'plutonthemes' ),
						'type' 		=> 'select',
						'options'	=> array(
							'ASC' => __('By ASC', 'plutonthemes'),
							'DESC' => __('By DESC', 'plutonthemes')
						)
					)
				)
			),
			'ilove_member' => array(
				'name' => 'Family Members',
				'description' => __('Display member list post', 'plutonthemes'),
				'icon' => 'fa-users',
				'category' => 'ilove Theme',
				'params' => array(
					array(
						'name' 		=> 'style',
						'label'		=> __( 'Style Display', 'plutonthemes' ),
						'type' 		=> 'select',
						'options'	=> array(
							'1' => __('Owl Carousel', 'plutonthemes'),
							'2' => __('List Style', 'plutonthemes')
						)
					),
					array(
						'name' => 'number',
						'label' => __( 'Number Post', 'plutonthemes' ),
						'type' => 'text',
						'admin_label' => true,
						'description' => __( 'Insert number post display', 'plutonthemes' ),
						'value' => '4'
					),
					array(
						'name' => 'cate',
						'label' => __( 'Select Category', 'plutonthemes' ),
						'type' => 'multiple',
						'options' => $member_list
					),
					array(
						'name' 		=> 'oder',
						'label'		=> __( 'Order', 'plutonthemes' ),
						'type' 		=> 'select',
						'options'	=> array(
							'ASC' => __('By ASC', 'plutonthemes'),
							'DESC' => __('By DESC', 'plutonthemes')
						)
					)
				)
			),
			'ilove_portfolio' => array(
				'name' => 'Portfolio',
				'description' => __('Display portfolio list post', 'plutonthemes'),
				'icon' => 'fa-book',
				'category' => 'ilove Theme',
				'params' => array(
					array(
						'name' => 'number',
						'label' => __( 'Number Post', 'plutonthemes' ),
						'type' => 'text',
						'admin_label' => true,
						'description' => __( 'Insert number post display (only insert even number)', 'plutonthemes' ),
						'value' => '14'
					),
					array(
						'name' 		=> 'order',
						'label'		=> __( 'Order', 'plutonthemes' ),
						'type' 		=> 'select',
						'options'	=> array(
							'ASC' => __('By ASC', 'plutonthemes'),
							'DESC' => __('By DESC', 'plutonthemes')
						)
					)
				)
			),
			'ilove_blog' => array(
				'name' => 'Blog Posts',
				'description' => __('Display blog masonry post', 'plutonthemes'),
				'icon' => 'fa-pencil-square-o',
				'category' => 'ilove Theme',
				'params' => array(
					array(
						'name' => 'number',
						'label' => __( 'Number Post', 'plutonthemes' ),
						'type' => 'text',
						'admin_label' => true,
						'description' => __( 'Insert number post display', 'plutonthemes' ),
						'value' => '9'
					),
					array(
						'name' => 'cate',
						'label' => __( 'Select Category', 'plutonthemes' ),
						'type' => 'multiple',
						'options' => $blog_list
					),
					array(
						'name' 		=> 'order',
						'label'		=> __( 'Order', 'plutonthemes' ),
						'type' 		=> 'select',
						'options'	=> array(
							'ASC' => __('By ASC', 'plutonthemes'),
							'DESC' => __('By DESC', 'plutonthemes')
						)
					)
				)
			),
			'ilove_counter' => array(
				'name' => 'Counter',
				'description' => __('Display counter number', 'plutonthemes'),
				'icon' => 'fa-spinner',
				'category' => 'ilove Theme',
				'params' => array(
					array(
						'name' => 'title',
						'label' => __( 'Title', 'plutonthemes' ),
						'type' => 'text',
						'admin_label' => true,
						'description' => __( 'Insert title display', 'plutonthemes' ),
						'value' => 'Insert Title'
					),
					array(
						'name' => 'number',
						'label' => __( 'Number Counter', 'plutonthemes' ),
						'type' => 'text',
						'admin_label' => true,
						'description' => __( 'Insert number counter display', 'plutonthemes' ),
						'value' => '345'
					),
					array(
						'name' => 'icon',
						'label' => 'Icon',
						'type' => 'icon_picker',
						'admin_label' => true,
						'description' => __( 'Select icon display', 'plutonthemes' )
					)
				)
			),
			'ilove_events' => array(
				'name' => 'Special Events',
				'description' => __('Display special events', 'plutonthemes'),
				'icon' => 'fa-home',
				'category' => 'ilove Theme',
				'params' => array(
					array(
						'name' => 'title',
						'label' => __( 'Title', 'plutonthemes' ),
						'type' => 'text',
						'admin_label' => true,
						'description' => __( 'Insert title display', 'plutonthemes' ),
						'value' => 'Insert Title'
					),
					array(
						'name' => 'desc',
						'label' => __( 'Description', 'plutonthemes' ),
						'type' => 'textarea',
						'admin_label' => true,
						'description' => __( 'Insert description display', 'plutonthemes' ),
						'value' => ''
					),
					array(
						'name' => 'icon',
						'label' => 'Icon',
						'type' => 'icon_picker',
						'admin_label' => true,
						'description' => __( 'Select icon display', 'plutonthemes' )
					),
					array(
						'name' 		=> 'active',
						'label'		=> __( 'Status', 'plutonthemes' ),
						'type' 		=> 'select',
						'options'	=> array(
							'0' => __('Disable', 'plutonthemes'),
							'1' => __('Active', 'plutonthemes')
						)
					)
				)
			),
			'ilove_infobox' => array(
				'name' => 'Info Box',
				'description' => __('Display Infomation Box', 'plutonthemes'),
				'icon' => 'fa-codepen',
				'category' => 'ilove Theme',
				'params' => array(
					array(
						'name' => 'title',
						'label' => __( 'Title', 'plutonthemes' ),
						'type' => 'text',
						'admin_label' => true,
						'description' => __( 'Insert title display', 'plutonthemes' ),
						'value' => 'Insert Title'
					),
					array(
						'name' => 'desc',
						'label' => __( 'Description', 'plutonthemes' ),
						'type' => 'textarea',
						'description' => __( 'Insert description display', 'plutonthemes' ),
						'value' => ''
					),
					array(
						'name' => 'title_bottom',
						'label' => __( 'Title Bottom', 'plutonthemes' ),
						'type' => 'text',
						'admin_label' => true,
						'description' => __( 'Insert title bottom display', 'plutonthemes' ),
						'value' => ''
					),
					array(
						'name' => 'title_bottom_link',
						'label' => __( 'Link Title Bottom', 'plutonthemes' ),
						'type' => 'text',
						'description' => __( 'Insert link for title bottom display', 'plutonthemes' ),
						'value' => ''
					),
				)
			),
			'ilove_location' => array(
				'name' => 'Map Wedding',
				'description' => __('Display location wedding', 'plutonthemes'),
				'icon' => 'fa-map-marker',
				'category' => 'ilove Theme',
				'params' => array(
					array(
						'name' => 'title',
						'label' => __( 'Title', 'plutonthemes' ),
						'type' => 'text',
						'admin_label' => true,
						'description' => __( 'Insert title display', 'plutonthemes' ),
						'value' => 'Insert Title'
					),
					array(
						'name' => 'desc',
						'label' => __( 'Description', 'plutonthemes' ),
						'type' => 'textarea',
						'description' => __( 'Insert description display', 'plutonthemes' ),
						'value' => ''
					),
					array(
						'name' => 'location',
						'label' => __( 'Select Location', 'plutonthemes' ),
						'type' => 'google_map',
						'admin_label' => true
					)
				)
			)
		);

		if( method_exists( $mini, 'add_map' ) ){
			$mini->add_map( $mini_map );
		}

	}
}
