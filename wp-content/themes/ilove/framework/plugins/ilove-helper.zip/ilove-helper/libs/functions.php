<?php
	/*---------------------------------------------------------------------*/
	/*  Load metabox script
	/*---------------------------------------------------------------------*/
	function ilove_metabox_admin_script()
	{
		if( is_admin() ) {
			wp_register_script('custommetabox', ILOVE_HELPER_BASE . '/metaboxes/js/custommetabox.js', array( 'jquery' ), ILOVE_HELPER_VERSION, true);
			wp_enqueue_script('custommetabox');
		}
	}
	add_action('admin_enqueue_scripts','ilove_metabox_admin_script');