jQuery(document).ready(function($) {
    'use strict';

    //Post settings
    function post_format_setting() {

        if ($('#post-format-image').is(':checked')) {
            $('#vm_post_metas').fadeIn();
            $('.cmb_id_vm_gallery').hide();
            $('.cmb_id_vm_image').fadeIn();
            $('.cmb_id_vm_video').hide();
            $('.cmb_id_vm_audio').hide();

        } else if ($('#post-format-gallery').is(':checked')) {
            $('#vm_post_metas').fadeIn();
            $('.cmb_id_vm_gallery').fadeIn();
            $('.cmb_id_vm_image').hide();
            $('.cmb_id_vm_video').hide();
            $('.cmb_id_vm_audio').hide();

        } else if ($('#post-format-video').is(':checked')) {
            $('#vm_post_metas').fadeIn();
            $('.cmb_id_vm_gallery').hide();
            $('.cmb_id_vm_image').hide();
            $('.cmb_id_vm_video').fadeIn();
            $('.cmb_id_vm_audio').hide();

        } else if ($('#post-format-audio').is(':checked')) {
            $('#vm_post_metas').fadeIn();
            $('.cmb_id_vm_gallery').hide();
            $('.cmb_id_vm_image').hide();
            $('.cmb_id_vm_video').hide();
            $('.cmb_id_vm_audio').fadeIn();

        } else {
            $('#vm_post_metas').hide();
        }
    }
    post_format_setting();

    var select_type = $('#post_formats_select input');

    $(this).change(function() {
        post_format_setting();
    });

    // Time line settings
    function time_setting() {
        var select_type = $('#vm_time_icon option');

        var time_icolove = $('.cmb_id_vm_time_icolove');
        var time_awesome = $('.cmb_id_vm_time_awesome');

        select_type.each(function() {
            if (($(this).attr('selected') == 'selected') && ($(this).attr('value') == 'icolove')) {
                time_icolove.fadeIn();
                time_awesome.hide();
            } else if (($(this).attr('selected') == 'selected') && ($(this).attr('value') == 'awesome')) {
                time_icolove.hide();
                time_awesome.fadeIn();
            }
        });
    }
    time_setting();

    var select_type = $('#vm_time_icon');

    $(this).change(function() {
        time_setting();
    });

    // Favourites settings
    function fa_setting() {
        var select_type = $('#vm_fa_icon option');

        var fa_icolove = $('.cmb_id_vm_fa_icolove');
        var fa_awesome = $('.cmb_id_vm_fa_awesome');

        select_type.each(function() {
            if (($(this).attr('selected') == 'selected') && ($(this).attr('value') == 'icolove')) {
                fa_icolove.fadeIn();
                fa_awesome.hide();
            } else if (($(this).attr('selected') == 'selected') && ($(this).attr('value') == 'awesome')) {
                fa_icolove.hide();
                fa_awesome.fadeIn();
            }
        });
    }
    fa_setting();

    var select_type = $('#vm_fa_icon');

    $(this).change(function() {
        fa_setting();
    });

});
