<?php
	/*-----------------------------------------------------------------------------------*/
	/*  Ilove Title
	/*-----------------------------------------------------------------------------------*/
	function ilove_shortcode_ilove_title( $atts, $content = null ) {
		$atts = shortcode_atts( array(
			'title' => 'Insert Text',
			'desc' => '',
			'style' => '1',
			'class' => ''
		), $atts, 'ilove_title' );

		extract( $atts );

		$output  = '';

		if ( isset( $style ) && $style ==2 ) {
			$style_class = 'underline2';
		} else {
			$style_class = 'underline';
		}

		ob_start();
		?>
			<div class="heading">
				<?php if ( !empty( $title ) ): ?>
					<h2 class="wow fadeInUp <?php echo esc_attr( $style_class ); ?> <?php echo ( !empty( $class ) ) ? $class : ''; ?> padtop50" data-wow-delay="0.5s"><?php echo $title; ?></h2>
				<?php endif ?>
				<?php if ( !empty( $desc ) ): ?>
					<p class="wow fadeInUp" data-wow-delay="0.7s">
						<?php echo base64_decode( $desc ); ?>
					</p>
				<?php endif ?>
			</div>
		<?php
		$result = ob_get_contents();
		ob_end_clean();
		$output .= $result;

		return $output;
	}
	add_shortcode( 'ilove_title', 'ilove_shortcode_ilove_title' );
