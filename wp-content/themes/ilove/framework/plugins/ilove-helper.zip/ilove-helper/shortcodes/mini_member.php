<?php
	/*-----------------------------------------------------------------------------------*/
	/*  Ilove Member
	/*-----------------------------------------------------------------------------------*/
	function ilove_shortcode_ilove_member( $atts, $content = null ) {
		$atts = shortcode_atts( array(
			'style' => '1',
			'number' => '4',
			'cate' => '',
			'oder' => 'ASC'
		), $atts, 'ilove_member' );

		extract( $atts );

		$output  = '';

		// Fix for pagination
		if( is_front_page() ) { $paged = ( get_query_var( 'page' ) ) ? get_query_var( 'page' ) : 1; } else { $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1; }

		// General args
		$args = array(
			'paged' => $paged,
			'post_type' => 'member',
			'posts_per_page' => $number,
			'orderby' => 'date',
			'order' => $oder
		);

		// Category args
		if ( !empty( $cate ) ) {
			$terms = explode( ',', $cate );
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'member_cats',
					'field' => 'id',
					'terms' => $terms,
					'operator' => 'IN',
				)
			);
		}

		// Do the query
		$block_query = new WP_Query( $args );

		ob_start();
		?>
			<?php if ( isset( $style ) && $style == 2 ): ?>
				<div class="member-style2 text-center">
					<?php
						if ( $block_query->have_posts() ) : while ( $block_query->have_posts() ) : $block_query->the_post();
							global $post;
							$relationship = get_post_meta( $post->ID, 'vm_member_relationship', true );
							$twitter = get_post_meta( $post->ID, 'vm_member_twitter', true );
							$facebook = get_post_meta( $post->ID, 'vm_member_facebook', true );
							$youtube = get_post_meta( $post->ID, 'vm_member_youtube', true );
							$googleplus = get_post_meta( $post->ID, 'vm_member_googleplus', true );
							$pinterest = get_post_meta( $post->ID, 'vm_member_pinterest', true );
					?>
							<div class="bestfriends cs-style-3 wow fadeInUp" data-wow-delay="0.5s">
								<?php if ( has_post_thumbnail() ): ?>
									<figure>
										<?php the_post_thumbnail( 'full', array( 'class' => 'img-responsive' ) ); ?>
									</figure>
								<?php endif; ?>
								<h4><?php the_title(); ?></h4>
								<?php if ( !empty( $relationship ) ): ?>
									<h5><?php echo $relationship; ?></h5>
								<?php endif; ?>
								<?php if ( !empty( $twitter ) || !empty( $facebook ) || !empty( $youtube ) || !empty( $googleplus ) || !empty( $pinterest ) ): ?>
									<div class="social-icons">
										<ul>
											<?php if ( !empty( $twitter ) ): ?>
												<li class="twitter"><a href="<?php echo esc_url( $twitter ); ?>" target="_blank"><?php echo __( 'Twitter', 'plutonthemes' ); ?></a></li>
											<?php endif; ?>
											<?php if ( !empty( $facebook ) ): ?>
												<li class="facebook"><a href="<?php echo esc_url( $facebook ); ?>" target="_blank"><?php echo __( 'Facebook', 'plutonthemes' ); ?></a></li>
											<?php endif; ?>
											<?php if ( !empty( $youtube ) ): ?>
												<li class="youtube"><a href="<?php echo esc_url( $youtube ); ?>" target="_blank"><?php echo __( 'YouTube', 'plutonthemes' ); ?></a></li>
											<?php endif; ?>
											<?php if ( !empty( $googleplus ) ): ?>
												<li class="googleplus"><a href="<?php echo esc_url( $googleplus ); ?>" target="_blank"><?php echo __( 'Google +', 'plutonthemes' ); ?></a></li>
											<?php endif; ?>
											<?php if ( !empty( $pinterest ) ): ?>
												<li class="pinterest"><a href="<?php echo esc_url( $pinterest ); ?>" target="_blank"><?php echo __( 'Pinterest', 'plutonthemes' ); ?></a></li>
											<?php endif; ?>
										</ul>
									</div>
								<?php endif; ?>
							</div>
					<?php
							endwhile;
						else :
							echo __( 'No post. Create post Family Members in admin', 'plutonthemes' );
						endif;
						wp_reset_postdata();
						wp_reset_query();
					?>
				</div>
			<?php else: ?>
				<?php wp_enqueue_script( 'owl.carousel.min' ); ?>
				<div class="owl-family member-style1 owl-carousel wow fadeInUp" data-wow-delay="0.7s">
					<?php
						if ( $block_query->have_posts() ) : while ( $block_query->have_posts() ) : $block_query->the_post();
							global $post;
							$relationship = get_post_meta( $post->ID, 'vm_member_relationship', true );
					?>
							<div class="owl-item">
								<div class="family-member">
									<?php if ( has_post_thumbnail() ): ?>
										<?php the_post_thumbnail( 'full', array( 'class' => 'img-responsive' ) ); ?>
									<?php endif ?>
									<h4><?php the_title( ); ?></h4>
									<?php if ( !empty( $relationship ) ): ?>
										<h5><?php echo $relationship; ?></h5>
									<?php endif ?>
								</div>
							</div>
					<?php
							endwhile;
						else :
							echo __( 'No post. Create post Family Members in admin', 'plutonthemes' );
						endif;
						wp_reset_postdata();
						wp_reset_query();
					?>
				</div>
			<?php endif; ?>
		<?php
		$result = ob_get_contents();
		ob_end_clean();
		$output .= $result;

		return $output;
	}
	add_shortcode( 'ilove_member', 'ilove_shortcode_ilove_member' );
