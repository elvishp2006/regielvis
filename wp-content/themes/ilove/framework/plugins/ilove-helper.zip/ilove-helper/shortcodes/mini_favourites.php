<?php
	/*-----------------------------------------------------------------------------------*/
	/*  Ilove Favourites
	/*-----------------------------------------------------------------------------------*/
	function ilove_shortcode_ilove_favourites( $atts, $content = null ) {
		$atts = shortcode_atts( array(
			'number' => '4',
			'style' => '1',
			'order' => 'ASC'
		), $atts, 'ilove_favourites' );

		extract( $atts );

		$output  = '';

		// Fix for pagination
		if( is_front_page() ) { $paged = ( get_query_var( 'page' ) ) ? get_query_var( 'page' ) : 1; } else { $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1; }

		// General args
		$args = array(
			'paged' => $paged,
			'post_type' => 'favourites',
			'posts_per_page' => $number,
			'orderby' => 'date',
			'order' => $order
		);

		// Do the query
		$block_query = new WP_Query( $args );

		ob_start();
		?>
            <?php if ( isset( $style ) && $style == 1 ): ?>
                <ul class="timeline">
    				<?php
    					if ( $block_query->have_posts() ) : while ( $block_query->have_posts() ) : $block_query->the_post();
    						global $post;
    						$fa_icon = get_post_meta( $post->ID, 'vm_fa_icon', true );
    						$fa_gr_title = get_post_meta( $post->ID, 'vm_fa_gr_title', true );
    						$fa_gr_desc  = get_post_meta( $post->ID, 'vm_fa_gr_desc', true );
    						$fa_br_title = get_post_meta( $post->ID, 'vm_fa_br_title', true );
    						$fa_br_desc  = get_post_meta( $post->ID, 'vm_fa_br_desc', true );
    						if ( $fa_icon == 'icolove' ) {
    							$icon = 'icon ' . get_post_meta( $post->ID, 'vm_fa_icolove', true );
    						} else {
    							$icon = 'fa ' . get_post_meta( $post->ID, 'vm_fa_awesome', true );
    						}
    				?>
                            <li>
                                <div class="timeline-badge tooltips wow fadeIn" data-wow-delay="0.5s" data-toggle="tooltip" data-placement="top" title="<?php the_title(); ?>">
									<i class="<?php echo esc_attr( $icon ); ?>"></i>
								</div>
                                <div class="timeline-left wow fadeInLeft" data-wow-delay="0.7s">
                                    <h4 class="timeline-title"><?php echo $fa_gr_title; ?></h4>
                                    <p><?php echo $fa_gr_desc; ?></p>
                                </div>
                                <div class="timeline-right wow fadeInRight" data-wow-delay="0.7s">
                                    <h4 class="timeline-title"><?php echo $fa_br_title; ?></h4>
                                    <p><?php echo $fa_br_desc; ?></p>
                                </div>
                            </li>
    				<?php
    						endwhile;
    					else :
    						echo __( 'No post. Create post Time Line in admin', 'plutonthemes' );
    					endif;
    					wp_reset_postdata();
    					wp_reset_query();
    				?>
    			</ul>
            <?php else: ?>
				<div class="owl-common owl-carousel wow fadeInUp" data-wow-delay="0.7s">
					<?php
    					if ( $block_query->have_posts() ) : while ( $block_query->have_posts() ) : $block_query->the_post();
    						global $post;
    						$fa_icon = get_post_meta( $post->ID, 'vm_fa_icon', true );
    						$fa_gr_title = get_post_meta( $post->ID, 'vm_fa_gr_title', true );
    						$fa_gr_desc  = get_post_meta( $post->ID, 'vm_fa_gr_desc', true );
    						$fa_br_title = get_post_meta( $post->ID, 'vm_fa_br_title', true );
    						$fa_br_desc  = get_post_meta( $post->ID, 'vm_fa_br_desc', true );
    						if ( $fa_icon == 'icolove' ) {
    							$icon = 'icon ' . get_post_meta( $post->ID, 'vm_fa_icolove', true );
    						} else {
    							$icon = 'fa ' . get_post_meta( $post->ID, 'vm_fa_awesome', true );
    						}
    				?>
                            <div class="owl-item">
                                <div class="common">
                                	<div class="<?php echo esc_attr( $icon ); ?> common-icon tooltips" data-toggle="tooltip" data-placement="top" title="<?php the_title(); ?>"></div>
                                    <h4><?php echo $fa_gr_title; ?></h4>
                                </div>
                                <div class="common">
                                	<div class="<?php echo esc_attr( $icon ); ?> common-icon tooltips" data-toggle="tooltip" data-placement="top" title="<?php the_title(); ?>"></div>
                                    <h4><?php echo $fa_br_title; ?></h4>
                                </div>
                            </div>
    				<?php
    						endwhile;
    					else :
    						echo __( 'No post. Create post Time Line in admin', 'plutonthemes' );
    					endif;
    					wp_reset_postdata();
    					wp_reset_query();
    				?>
				</div>
            <?php endif; ?>
		<?php
		$result = ob_get_contents();
		ob_end_clean();
		$output .= $result;

		return $output;
	}
	add_shortcode( 'ilove_favourites', 'ilove_shortcode_ilove_favourites' );
