<?php
	/*-----------------------------------------------------------------------------------*/
	/*  Ilove Blog
	/*-----------------------------------------------------------------------------------*/
	function ilove_shortcode_ilove_blog( $atts, $content = null ) {
		$atts = shortcode_atts( array(
			'number' => '4',
			'cate' => '',
			'order' => 'ASC'
		), $atts, 'ilove_blog' );

		extract( $atts );

		$output  = '';

		// Fix for pagination
		if( is_front_page() ) { $paged = ( get_query_var( 'page' ) ) ? get_query_var( 'page' ) : 1; } else { $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1; }

		// General args
		$args = array(
			'paged' => $paged,
			'post_type' => 'post',
			'posts_per_page' => $number,
			'orderby' => 'date',
			'order' => $order
		);

		// Category args
		if ( !empty( $cate ) ) {
			$terms = explode( ',', $cate );
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'category',
					'field' => 'id',
					'terms' => $terms,
					'operator' => 'IN',
				)
			);
		}

		// Do the query
		$block_query = new WP_Query( $args );
		wp_enqueue_script( 'imagesloaded.pkgd.min' );
		wp_enqueue_script( 'masonry.pkgd.min' );

		ob_start();
		?>
			<div class="blogs wow fadeInUp" data-wow-delay="0.5s">
				<?php
					if ( $block_query->have_posts() ) : while ( $block_query->have_posts() ) : $block_query->the_post();
						global $post;
                        $post_id  = (int)get_post_thumbnail_id( );
                        $post_img = wp_get_attachment_image_src( $post_id, 'full' );
				?>
                        <div class="blog cs-style-3 wow fadeInUp" data-wow-delay="0.5s">
                            <?php if ( has_post_thumbnail() ): ?>
                                <a href="<?php the_permalink(); ?>">
                                    <figure>
                                        <img src="<?php echo esc_url( $post_img[0] ); ?>" class="img-responsive" alt="">
                                    </figure>
                                </a>
                            <?php endif; ?>
                            <div class="date"><?php the_time( 'd M' ); ?></div>
                            <div class="year"><?php the_time( 'Y' ); ?></div>
                            <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                            <?php the_excerpt(); ?>
                            <div class="stats">
                                <?php echo __( 'By', 'plutonthemes' ); ?> : <a href="<?php echo get_author_posts_url($post->post_author); ?>"><?php echo get_the_author_meta('display_name' ); ?></a>
                                <?php if( comments_open() ) : ?>
                            		| <a href="<?php comments_link(); ?>"><?php comments_number( __('0 Comment','plutonthemes'), __('1 Comment','plutonthemes'), __('% Comments','plutonthemes') ); ?></a>
                            	<?php endif; ?>
                            </div>
                        </div>
				<?php
						endwhile;
					else :
						echo __( 'No post. Create post Blog Post in admin', 'plutonthemes' );
					endif;
					wp_reset_postdata();
					wp_reset_query();
				?>
			</div>
		<?php
		$result = ob_get_contents();
		ob_end_clean();
		$output .= $result;

		return $output;
	}
	add_shortcode( 'ilove_blog', 'ilove_shortcode_ilove_blog' );
