<?php
	/*-----------------------------------------------------------------------------------*/
	/*  Ilove Couple
	/*-----------------------------------------------------------------------------------*/
	function ilove_shortcode_ilove_couple( $atts, $content = null ) {
		$atts = shortcode_atts( array(
			'title' => '&',
			'groom_name' => '',
			'groom_desc' => '',
			'groom_image' => '',
			'bride_name' => '',
			'bride_desc' => '',
			'bride_image' => ''
		), $atts, 'ilove_couple' );

		extract( $atts );

		$output  = '';

		if ( !empty( $groom_image ) ) {
			$groom_image_full = wp_get_attachment_image_src( $groom_image, 'full' );
			$groom_link = $groom_image_full[0];
			$groom_style = 'background-image:url('. esc_url( $groom_link ) .')';
		} else {
			$groom_style = '';
		}
		if ( !empty( $bride_image ) ) {
			$bride_image_full = wp_get_attachment_image_src( $bride_image, 'full' );
			$bride_link = $bride_image_full[0];
			$bride_style = 'background-image:url('. esc_url( $bride_link ) .')';
		}

		ob_start();
		?>
			<div class="row">
				<div class="col-md-6">
					<ul class="ch-grid man wow flipInX" data-wow-delay="0.5s">
						<li>
							<div class="ch-item ch-img-1" style="<?php echo $groom_style; ?>">
								<div class="ch-info">
									<?php if ( !empty( $groom_name ) ): ?>
										<h3><?php echo wp_kses_stripslashes( $groom_name ); ?></h3>
									<?php endif ?>
									<?php if ( !empty( $groom_desc ) ): ?>
										<p><?php echo base64_decode( $groom_desc ); ?></p>
									<?php endif ?>
								</div>
							</div>
						</li>
					</ul>
				</div>
				<?php if ( !empty( $title ) ): ?>
					<div class="and"><?php echo $title; ?></div>
				<?php endif ?>
				<div class="col-md-6">
					<ul class="ch-grid woman wow flipInX" data-wow-delay="0.5s">
						<li>
							<div class="ch-item ch-img-2" style="<?php echo $bride_style; ?>">
								<div class="ch-info">
									<?php if ( !empty( $bride_name ) ): ?>
										<h3><?php echo $bride_name; ?></h3>
									<?php endif ?>
									<?php if ( !empty( $bride_desc ) ): ?>
										<p><?php echo base64_decode( $bride_desc ); ?></p>
									<?php endif ?>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</div>
		<?php
		$result = ob_get_contents();
		ob_end_clean();
		$output .= $result;

		return $output;
	}
	add_shortcode( 'ilove_couple', 'ilove_shortcode_ilove_couple' );