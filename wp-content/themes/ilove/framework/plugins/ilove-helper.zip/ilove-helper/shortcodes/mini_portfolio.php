<?php
	/*-----------------------------------------------------------------------------------*/
	/*  Ilove Portfolio
	/*-----------------------------------------------------------------------------------*/
	function ilove_shortcode_ilove_portfolio( $atts, $content = null ) {
		$atts = shortcode_atts( array(
			'number' => '14',
			'order' => 'ASC'
		), $atts, 'ilove_portfolio' );

		extract( $atts );

		$output  = '';

		if ( $number%2 == 1 ) {
			$number = $number - 1;
		}

		// Fix for pagination
		if( is_front_page() ) { $paged = ( get_query_var( 'page' ) ) ? get_query_var( 'page' ) : 1; } else { $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1; }

		// General args
		$args = array(
			'paged' => $paged,
			'post_type' => 'portfolio',
			'posts_per_page' => $number,
			'orderby' => 'date',
			'order' => $order
		);

		// Do the query
		$block_query = new WP_Query( $args );

		wp_enqueue_script( 'owl.carousel.min' );
		wp_enqueue_script( 'jquery.magnific-popup.min' );

		ob_start();
		?>
			<div class="bigmoments">
				<div class="owl-moments owl-carousel">
					<?php
						$dem = 1;
						if ( $block_query->have_posts() ) : while ( $block_query->have_posts() ) : $block_query->the_post();
							global $post;
							$post_by = get_post_meta( $post->ID, 'vm_po_by', true );
					?>
							<?php if ( $dem%2 == 1 ): ?>
								<div class="col-xs-12 col-sm-6 col-md-3 owl-item">
							<?php endif ?>
									<ul class="grid cs-style-3">
										<li>
											<figure>
												<?php if ( has_post_thumbnail() ): ?>
													<?php
														$_thumbs = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
														$img_url = $_thumbs['0'];
													?>
													<img src="<?php echo esc_url( $img_url ); ?>" class="img-responsive" alt="<?php the_title(); ?>">
													<a href="<?php echo esc_url( $img_url ); ?>" class="popup-image" data-effect="mfp-zoom-in">
														<span class="fa fa-photo fa-2x"></span>
													</a>
												<?php endif ?>
												<figcaption>
													<h4><?php the_title(); ?></h4>
													<?php if ( !empty( $post_by ) ): ?>
														<span><?php echo __( 'by', 'plutonthemes' ) ?> <?php echo $post_by; ?></span>
													<?php endif ?>
												</figcaption>
											</figure>
										</li>
									</ul>
							<?php if ( $dem%2 == 0 ): ?>
								</div>
							<?php endif ?>
					<?php
							$dem++;
							endwhile;
						else :
							echo __( 'No post. Create post Portfolio in admin', 'plutonthemes' );
						endif;
						wp_reset_postdata();
						wp_reset_query();
					?>
				</div>
			</div>
		<?php
		$result = ob_get_contents();
		ob_end_clean();
		$output .= $result;

		return $output;
	}
	add_shortcode( 'ilove_portfolio', 'ilove_shortcode_ilove_portfolio' );