<?php
	/*-----------------------------------------------------------------------------------*/
	/*  Ilove Counter
	/*-----------------------------------------------------------------------------------*/
	function ilove_shortcode_ilove_counter( $atts, $content = null ) {
		$atts = shortcode_atts( array(
			'title' => 'Insert Text',
			'number' => '345',
			'icon' => ''
		), $atts, 'ilove_counter' );

		extract( $atts );

		$output  = '';

		wp_enqueue_script( 'jquery.countTo' );

		if ( empty( $number ) ) {
			$number = 100;
		}

		ob_start();
		?>
			<div class="counting wow flipInY" data-wow-delay="0.7s">
				<div class="fun-facts ico"><span class="fa <?php echo esc_attr( $icon ); ?>"></span></div>
				<span class="counts" data-from="0" data-to="<?php echo esc_attr( $number ); ?>" data-speed="5000" data-refresh-interval="50">0</span>
				<?php if ( !empty( $title ) ): ?>
					<h5><?php echo $title; ?></h5>
				<?php endif ?>
			</div>
		<?php
		$result = ob_get_contents();
		ob_end_clean();
		$output .= $result;

		return $output;
	}
	add_shortcode( 'ilove_counter', 'ilove_shortcode_ilove_counter' );