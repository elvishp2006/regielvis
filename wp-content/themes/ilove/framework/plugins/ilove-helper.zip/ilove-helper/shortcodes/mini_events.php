<?php
	/*-----------------------------------------------------------------------------------*/
	/*  Ilove Special Events
	/*-----------------------------------------------------------------------------------*/
	function ilove_shortcode_ilove_events( $atts, $content = null ) {
		$atts = shortcode_atts( array(
			'title' => 'Insert Text',
			'desc' => '',
			'icon' => '',
			'active' => '0'
		), $atts, 'ilove_events' );

		extract( $atts );

		$output  = '';

		$class_active = '';
		if ( isset( $active ) && $active == 1 ) {
			$class_active = ' alternative';
		}

		ob_start();
		?>
			<div class="event<?php echo esc_attr( $class_active ); ?> wow flipInX" data-wow-delay="0.5s">
				<i class="fa <?php echo esc_attr( $icon ); ?>"></i>
				<?php if ( !empty( $title ) ): ?>
					<h4 class="text-uppercase"><?php echo $title; ?></h4>
				<?php endif ?>
				<?php if ( !empty( $desc ) ): ?>
					<p><?php echo base64_decode( $desc ); ?></p>
				<?php endif ?>
			</div>
		<?php
		$result = ob_get_contents();
		ob_end_clean();
		$output .= $result;

		return $output;
	}
	add_shortcode( 'ilove_events', 'ilove_shortcode_ilove_events' );