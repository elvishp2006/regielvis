<?php
	/*-----------------------------------------------------------------------------------*/
	/*  Ilove Time Line
	/*-----------------------------------------------------------------------------------*/
	function ilove_shortcode_ilove_time_line( $atts, $content = null ) {
		$atts = shortcode_atts( array(
			'number' => '5',
			'oder' => 'ASC'
		), $atts, 'ilove_time_line' );

		extract( $atts );

		$output  = '';

		// Fix for pagination
		if( is_front_page() ) { $paged = ( get_query_var( 'page' ) ) ? get_query_var( 'page' ) : 1; } else { $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1; }

		// General args
		$args = array(
			'paged' => $paged,
			'post_type' => 'time_line',
			'posts_per_page' => $number,
			'orderby' => 'date',
			'order' => $oder
		);

		// Do the query
		$block_query = new WP_Query( $args );

		ob_start();
		?>
			<ul class="timeline">
				<?php
					$dem = 1;
					if ( $block_query->have_posts() ) : while ( $block_query->have_posts() ) : $block_query->the_post();
						global $post;
						$time_date = get_post_meta( $post->ID, 'vm_time_date', true );
						$time_icon = get_post_meta( $post->ID, 'vm_time_icon', true );
						if ( $time_icon == 'icolove' ) {
							$icon = 'icon ' . get_post_meta( $post->ID, 'vm_time_icolove', true );
						} else {
							$icon = 'fa ' . get_post_meta( $post->ID, 'vm_time_awesome', true );
						}

						if ( $dem%2==1 ) {
							$class_time = '';
						} else {
							$class_time = 'timeline-inverted';
						}
				?>
						<li class="<?php echo esc_attr( $class_time ); ?>">
							<div class="timeline-badge wow fadeInUp" data-wow-delay="0.5s">
								<i class="<?php echo esc_attr( $icon ); ?>"></i>
							</div>
							<div class="timeline-panel wow fadeInLeft" data-wow-delay="0.7s">
								<div class="timeline-heading">
									<h4 class="timeline-title"><?php the_title( ); ?></h4>
									<p><small class="text-muted"><i class="glyphicon glyphicon-time"></i> <?php echo $time_date; ?></small></p>
								</div>
								<div class="timeline-body"><?php the_content( ); ?></div>
							</div>
						</li>
				<?php
						$dem++;
						endwhile;
					else :
						echo __( 'No post. Create post Time Line in admin', 'plutonthemes' );
					endif;
					wp_reset_postdata();
					wp_reset_query();
				?>
			</ul>
		<?php
		$result = ob_get_contents();
		ob_end_clean();
		$output .= $result;

		return $output;
	}
	add_shortcode( 'ilove_time_line', 'ilove_shortcode_ilove_time_line' );