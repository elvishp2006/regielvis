<?php
	/*-----------------------------------------------------------------------------------*/
	/*  Ilove Location
	/*-----------------------------------------------------------------------------------*/
	function ilove_shortcode_ilove_location( $atts, $content = null ) {
		$atts = shortcode_atts( array(
			'title' => 'Insert Text',
			'desc' => '',
			'location' => ''
		), $atts, 'ilove_location' );

		extract( $atts );
		$marker = get_template_directory_uri() . '/assets/images/marker.png';
		$location = explode( '|', $location);

		$output  = '';
		wp_enqueue_script( 'map-api' );
		$location_id = rand( 10,99 );

		ob_start();
		?>
			<div id="map-<?php echo $location_id; ?>" class="wow fadeInUp" data-wow-delay="0.7s"></div>
			<style type="text/css">
				#map-<?php echo $location_id; ?>{
					height:450px;
					margin:70px 15px 40px;
				}
				#map-<?php echo $location_id; ?> h3{
					color:#ef6a8a;	
				}
			</style>
			<script type="text/javascript">
			jQuery(document).ready(function($) {
				google.maps.event.addDomListener(window, 'load', init);
				function init() {
					var mainPosition = new google.maps.LatLng( <?php echo $location[0] ?>, <?php echo $location[1] ?> );
					var mapOptions = {
						zoom: <?php echo $location[2] ?>,
						scrollwheel: false,
						disableDefaultUI: true,
						center: mainPosition, // Melbourne
						styles: [{"featureType":"landscape","elementType":"labels","stylers":[{"visibility":"off","hue": "#ffffff"}]},{"featureType":"transit","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"poi","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"stylers":[{"hue":"#00aaff"},{"saturation":-100},{"gamma":2.15},{"lightness":12}]},{"featureType":"road","elementType":"labels.text.fill","stylers":[{"visibility":"on"},{"lightness":24}]},{"featureType":"road","elementType":"geometry","stylers":[{"lightness":57}]}]
					};
					var mapElement = document.getElementById('map-<?php echo $location_id; ?>');
					var map = new google.maps.Map(mapElement, mapOptions);


					var contentString =
						'<div class="map-content">'+
						'<h3><?php echo $title; ?></h3>'+
						'<p><?php echo base64_decode( $desc ); ?></p>'+
						'</div>'

					var image = '<?php echo esc_url( $marker ); ?>';
					var myLatLng = new google.maps.LatLng( <?php echo $location[0] ?>, <?php echo $location[1] ?> );
					var mapMarker = new google.maps.Marker({
						position: myLatLng,
						map: map,
						icon: image,
						title:  'Frostbyte Interactive'
					});
					var infowindow = new google.maps.InfoWindow({
						content: contentString
					});
					google.maps.event.addListener(mapMarker, 'click', function() {
						infowindow.open(map, mapMarker);
					});
				}
			});
			</script>
		<?php
		$result = ob_get_contents();
		ob_end_clean();
		$output .= $result;

		return $output;
	}
	add_shortcode( 'ilove_location', 'ilove_shortcode_ilove_location' );
