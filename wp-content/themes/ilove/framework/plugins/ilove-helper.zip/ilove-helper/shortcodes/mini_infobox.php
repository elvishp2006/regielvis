<?php
	/*-----------------------------------------------------------------------------------*/
	/*  Ilove Info Box
	/*-----------------------------------------------------------------------------------*/
	function ilove_shortcode_ilove_infobox( $atts, $content = null ) {
		$atts = shortcode_atts( array(
			'title' => 'Insert Text',
			'desc' => '',
			'title_bottom' => '',
			'title_bottom_link' => ''
		), $atts, 'ilove_infobox' );

		extract( $atts );

		$output  = '';

		ob_start();
		?>
            <div class="day-details wow fadeInUp" data-wow-delay="0.7s">
                <?php if ( !empty( $title ) ): ?>
                    <h4><?php echo $title; ?></h4>
                <?php endif; ?>
                <?php if ( !empty( $desc ) ): ?>
                    <p><?php echo base64_decode( $desc ); ?></p>
                <?php endif; ?>
                <?php if ( !empty( $title_bottom ) ): ?>
                    <h4><strong>
                        <?php if ( !empty( $title_bottom_link ) ): ?>
                            <a href="<?php echo esc_url( $title_bottom_link ); ?>"><?php echo $title_bottom; ?></a>
                        <?php else: ?>
                            <?php echo $title_bottom; ?>
                        <?php endif; ?>
                    </strong></h4>
                <?php endif; ?>
            </div>
		<?php
		$result = ob_get_contents();
		ob_end_clean();
		$output .= $result;

		return $output;
	}
	add_shortcode( 'ilove_infobox', 'ilove_shortcode_ilove_infobox' );
