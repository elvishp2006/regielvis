<?php
/*
 * Plugin Name: Ilove Theme Helper
 * Plugin URI: http://wordpress.org/
 * Description: Help Themes of PlutonThemes works correctly.
 * Author: PlutonThemes
 * Author URI: http://themeforest.net/user/plutonthemes
 * Version: 1.0
 * Text Domain: plutonthemes
 * License: GPL version 2 or later - http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
*/

define('ILOVE_HELPER_VERSION', '1.0');
define('ILOVE_HELPER_PATH', dirname(__FILE__));
define('ILOVE_HELPER_IMG',  plugins_url() . '/ilove-helper/images');
define('ILOVE_HELPER_BASE', plugins_url() . '/ilove-helper');

class PlutonHelper{

	public $path;

	public $path_url;

	public function __construct(){
		$this->path = ILOVE_HELPER_PATH;
		$this->path_url = ILOVE_HELPER_BASE;

		$this->init();
	}


	/*---------------------------------------------------------------------*/
	/* Init
	/*---------------------------------------------------------------------*/
	public function init(){
		if( $this->is_plugin_active( 'mini_composer/mini_composer.php' ) == true ){
			require_once ILOVE_HELPER_PATH . '/libs/register.php';
			require_once ILOVE_HELPER_PATH . '/libs/ex_metaboxes.php';
			require_once ILOVE_HELPER_PATH . '/libs/functions.php';
			require_once ILOVE_HELPER_PATH . '/libs/mini_map.php';

			$this->load_shortcode();
		}
	}

	/*---------------------------------------------------------------------*/
	/* Check plugin is active
	/*---------------------------------------------------------------------*/
	public function is_plugin_active( $plugin ){

		include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

		if(is_plugin_active( $plugin )) {
			return true;
		} else {
			return false;
		}
	}

	/*---------------------------------------------------------------------*/
	/*  Add all shortcodes file
	/*---------------------------------------------------------------------*/
	public function load_shortcode(){

		foreach (glob($this->path."/shortcodes/*.php") as $filename)
		{
			include $filename;
		}

	}


}

new PlutonHelper();