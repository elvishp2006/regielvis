/*
 * Mini Composer Project
 *
 * (c) Copyright King-Theme.com
 *
 * Must obtain permission before using this script in any other purpose
 *
 * mini.builder.js
 *
*/

( function($){
	 
	if( typeof( mini ) == 'undefined' )
		window.mini = {};
	 
	$().extend( mini.views, {
			
		builder : new mini.backbone.views('no-model').extend({
			
			render : function(){
				
				var el = $( mini.template( 'container' ) );
				
				$('#mini-container').remove();
				$('#postdivrich').hide().after( el );
				
				this.el = el;
				
				return el;
							
			},
			
			events : {
				'.classic-mode:click' : mini.switch,
				'.basic-add:click' : mini.backbone.add,
				'.mini-add-sections:click' : 'sections',
				'.post-settings:click' : 'post_settings',
				'#minifooters li.quickadd:click' : 'footer'
			},
			
			sections : function(){
				
				mini.cfg = $().extend( mini.cfg, mini.backbone.stack.get('miniConfigs') );
				
				var atts = { 
						title: 'Sections Manager', 
						width: 800, 
						class: 'no-footer bg-blur-style section-manager-popup', 
						help: 'http://minicomposer.com/documentation/sections-manager/?source=client_installed' 
					},
					pop = mini.tools.popup.render( this, atts ),
					arg = {},
					sections = $( mini.template( 'install-global-sections', arg ) );
					
				if( mini.cfg.profile !== undefined )
					pop.find('h3.m-p-header').append( ' - Profile <span class="msg-profile-label-display">'+mini.cfg.profile.replace(/\-/g,' ')+'</span>' );
				
				pop.find('.m-p-body').append( sections );
				
				if( typeof arg.callback == 'function' )
					arg.callback( sections );

			},
			
			post_settings : function( e ){
				
				var atts = { title: 'Page Settings', width: 800, class: 'no-footer bg-blur-style' },
					pop = mini.tools.popup.render( this, atts ),
					arg = { classes : $('#mini-page-body-classes').val(), css : $('#mini-page-css-code').val() },
					sections = $( mini.template( 'post-settings', arg ) );
				
				pop.find('.m-p-body').append( sections );
				
				if( typeof arg.callback == 'function' )
					arg.callback( sections, $ );
				
				return false;
					
			},
			
			footer : function(){
				
				var content = $(this).data('content');
				
				if( content == 'custom' ){
					
					var atts = { 
						title: mini.__.i36, 
						width: 750, 
						class: 'push-custom-content',
						save_text: 'Push to builder'
					},
					pop = mini.tools.popup.render( this, atts );
					
					var copied = mini.backbone.stack.get('miniRowClipboard');
					if( copied === undefined || copied == '' )
						copied = '';
					pop.find('.m-p-body').html( mini.__.i37+'<p></p><textarea style="width: 100%;height: 300px;">'+copied+'</textarea>');
					
					pop.data({
						callback : function( pop ){
							
							var content = pop.find('textarea').val();
							if( content !== '' )
								mini.backbone.push( content );
						}
					});
					
					return;
					
				}else if( content == 'paste' ){
					content = mini.backbone.stack.get('miniRowClipboard');
					if( content === undefined || content == '' ){
						content = '[mini_column_text]<p>'+mini.__.i38+'</p>[/mini_column_text]';
					}
				}
				
				if( content != '' )
					mini.backbone.push( content );
				
			}
			
		} ),

		views_sections : new mini.backbone.views().extend({
			
			render : function( params ){
				
				var el = new $( mini.template( 'views-sections', params ) );
				mini.params.process_all( params.args.content, el.find('> .mini-views-sections-wrap'), 'views_section' );
				
				this.el = el;
				
				return el;
				
			},
			
			events : {
				'>.mini-views-sections-control .edit:click' : 'settings',
				'>.mini-views-sections-control .delete:click' : 'remove',
				'>.mini-views-sections-control .double:click' : 'double',
				'>.mini-views-sections-wrap .add-section:click' : 'add_section',
				'>.mini-views-sections-control .more:click' : 'more',
				'>.mini-views-sections-control .copy:click' : 'copy',
				'>.mini-views-sections-control .cut:click' : 'cut',
				'>.mini-views-sections-control:click' : function( e ){
					var tar = $(e.target);
					if( tar.hasClass('more') || tar.parent().hasClass('more') )
						return;
					$(this).find('.active').removeClass('active');
				},
			},
			
			add_section : function( e ){

				var wrp = $(this).closest('.mini-views-sections-wrap'),
					maps = mini.get.maps(this),
					smaps = mini.maps[maps.views.sections],
					content = '['+maps.views.sections+' title="New '+smaps.name+'"][/'+maps.views.sections+']';
				
				wrp.find('> .mini-views-sections-label .sl-active').removeClass('sl-active');
				wrp.find('> .mini-section-active').removeClass('mini-section-active');
					
				mini.params.process_all( content, wrp, 'views_section' );
				
			}
			
		} ),
		
		views_section : new mini.backbone.views().extend({
			
			render : function( params ){

				var el = $( mini.template( 'views-section', params ) );
				
				this.el = el;
				
				return el;
				
			},
			
			init : function( params, el ){
				
				var id = el.data('model'), 
					btn = params.parent_wrp.find('>.mini-views-sections-label .add-section'), 
					title = mini.tools.esc( params.args.title ),
					icon = '';
				if( params.args.icon != undefined )
					icon = '<i class="'+params.args.icon+'"></i> ';
					
				mini.ui.sortInit();
				
				var label = '<div class="section-label';
				if( params.first == true )
					label += ' sl-active';
				label += '" id="mini-pmodel-'+id+'" data-pmodel="'+id+'">'+icon+title+'</div>';
				
				btn.before( label );
				
				return btn;
	
			},
			
			events : {
				'>.mini-vs-control .settings:click' : 'settings',
				'>.mini-vs-control .double:click' : 'double',
				'>.mini-vs-control .add:click' : 'add',
				'>.mini-vs-control .delete:click' : 'remove',
				
			},
			
			settings : function(){
				
				var pop = mini.backbone.settings( this );
				if( !pop ){
					alert( mini.__.i39 );
					return;
				}
				pop.data({
					after_callback : function( pop ){
						
						var id = mini.get.model( pop.data('button') ),
							storage = mini.storage[ id ],
							el = $('#model-'+id),
							icon = '';
						if( storage.args.icon != undefined )
							icon = '<i class="'+storage.args.icon+'"></i> ';
							
						$('#mini-pmodel-'+id).html( icon+mini.tools.esc( storage.args.title ) );
						el.find('.mini-vertical-label').html( icon+mini.tools.esc( storage.args.title ) );
					}
				});
			},
			
			double : function(){
				
				var id = mini.get.model( this ),
					exp = mini.backbone.export( id ),
					wrp = $(this).closest('.mini-views-sections-wrap');
				
				wrp.find('> .mini-views-sections-label .sl-active').removeClass('sl-active');
				wrp.find('> .mini-section-active').removeClass('mini-section-active');
					
				mini.params.process_all( exp.begin+exp.content+exp.end, wrp, 'views_section' );
			},
			
			remove : function(){
				
				var id = mini.get.model( this ),
					lwrp = $('#mini-pmodel-'+id).parent();
					
				if( confirm('Are you sure?') ){	
					$('#mini-pmodel-'+id).remove();
					lwrp.find('.section-label').first().trigger('click');
					delete mini.storage[ id ];
					$('#model-'+id).remove();
				}
			}
	
			
		} ),
		
		row : new mini.backbone.views().extend({
			
			render : function( params, _return ){
				
				params.name = 'mini_row';
				params.end = '[/mini_row]';
				
				var el = $( mini.template( 'row', [ params.args.row_id, params.args.disabled ] ) ), atts = ' width="12/12"';
				
				var content = params.args.content.toString().trim();
				if( content.indexOf('[mini_column') !== 0 ){
					
					content = content.replace(/mini_column#/g,'mini_column##');
					content = content.replace(/mini_column /g,'mini_column# ').replace(/mini_column\]/g,'mini_column#]');
					
					var params = mini.params.merge( 'mini_column' );
					
					for( var i in params ){
						if( typeof( params[i].value ) != 'undefined' )
							atts += ' '+params[i].name
								 +'="'+mini.tools.esc_attr( params[i].value )+'"';
					}
					
					content = '[mini_column'+atts+']'+content+'[/mini_column]';
					
					delete params;
					
				}
				
				mini.params.process_columns( content, el.find('.mini-row-wrap') );
				
				if( _.isUndefined(_return) )
					$('#mini-container>#mini-rows').append( el );
				
				this.el = el;
				
				return el;
				
			},
			
			events : {
				'.row-container-control .close:click' : 'remove',
				'.row-container-control .settings:click' : 'edit',
				'.row-container-control .double:click' : 'double',
				'.row-container-control .copy:click' : 'copy',
				'.row-container-control .columns:click' : 'columns',
				'.row-container-control .collapse:click' : 'collapse',
				'.row-container-control .addToSections:click' : 'sections',
				'.row-container-control .rowStatus:click' : 'status',
			},
			
			columns : function(){
				
				var columns = $(this).closest('.mini-row').find('>.mini-row-wrap>.mini-column.mini-model');

				var pop = mini.tools.popup.render( 
							this, 
							{ 
								title: 'Row Layout', 
								class: 'no-footer',
								width: 341,
								content: mini.template( 'row-columns', {current:columns.length} ),
								help: 'http://minicomposer.com/documentation/resize-sortable-columns/?source=client_installed' 
							}
						);
						
				pop.find('.button').on( 'click', 
					{ 
						model: mini.get.model( this ),
						columns: columns,
						pop: pop
					}, 
					mini.views.row.set_columns 
				);
				
				pop.find('input[type=checkbox]').on('change',function(){
					
					var name = $(this).data('name');
					if( name == undefined )
						return;
						
					if( this.checked == true )
						mini.cfg[ name ] = 'checked';
					else mini.cfg[ name ] = '';
					
					mini.backbone.stack.set( 'miniConfigs', mini.cfg );
						
				});	
						
			},
			
			set_columns : function(e){
				
				var newcols = parseInt($(this).data('column')),
					columns = e.data.columns,
					wrow = $( '#model-'+e.data.model+' > .mini-row-wrap' );
					
				if( columns.length < newcols ){
					
					/* Add new columns */
					var id = columns.last().data('model'), el, reInit = false;
					content = '['+mini.storage[id].name+' width="'+(12/newcols)+'/12"][/'+mini.storage[id].name+']';
					
					columns.each(function(){
						mini.storage[$(this).data('model')].args.width = (12/newcols)+'/12';
					});
					
					columns.css({width: (100/newcols)+'%'});
					
					for( var i = 0; i < (newcols-columns.length) ; i++ ){
						
						var dobl = mini.backbone.double( columns.last().get(0) );
						
						
						if( $('#m-r-c-double-content').attr('checked') == undefined || columns.length === 0 ){
							
							dobl.find('.mini-model').each(function(){
								delete mini.storage[$(this).data('model')];
								$(this).remove();
							});
							
						}
						
					}
					
					if( reInit == true )
						mini.ui.sortInit();
						
				}else{
					/* Remove columns */
					var remove = [];
					
					for( var i = 0; i < (columns.length-newcols) ; i++ ){
					
						var found_empty = false;
					
						wrow.find('>.mini-column.mini-model,>.mini-column-inner.mini-model').each(function(){
							if( $(this).find('>.mini-column-wrap>.mini-model').length == 0 ){
								found_empty = this;
							}
						});
					
						if( found_empty != false ){
					
							$(found_empty).remove();
					
						}else{
					
							var last = wrow.find('>.mini-column.mini-model,>.mini-column-inner.mini-model').last(), 
								plast = last.prev();
								
							if( $('#m-r-c-keep-content').attr('checked') != undefined && plast.get(0) != undefined ){
								last.find('>.mini-column-wrap>.mini-model').each(function(){
									plast.find('>.mini-column-wrap').append( this );
								});
							}else{
								last.find('>.mini-column-wrap>.mini-model').each(function(){
									delete mini.storage[$(this).data('model')];
								});
							}
							
							
							last.remove();
							
						}		
					}
					
					wrow.find('>.mini-column.mini-model,>.mini-column-inner.mini-model').each(function(){
					
						mini.storage[ $(this).data('model') ].args.width = '1/'+newcols;
						$(this).css({width: (100/newcols)+'%'});
					
					});
				}
				
				e.data.pop.remove();
				
			},
			
			collapse : function(){
				var elm = $(this).closest('.mini-row');
				if( !elm.hasClass('collapse') ){
					elm.addClass('collapse');
				}else{
					elm.removeClass('collapse');
				}	
			},
			
			sections : function( e ){
				
				mini.cfg = $().extend( mini.cfg, mini.backbone.stack.get('miniConfigs') );
				
				var atts = { title: mini.__.i40, width: 800, class: 'no-footer bg-blur-style', help: 'http://minicomposer.com/documentation/sections-manager/?source=client_installed' };
				var pop = mini.tools.popup.render( this, atts );
				
				if( mini.cfg.profile !== undefined )
					pop.find('h3.m-p-header').append( ' - <span class="msg-profile-label-display">'+mini.cfg.profile.replace(/\-/g,' ')+'</span>' );
				
				pop.data({ model: mini.get.model(this) });
				
				var args = {};
				var sections = $( mini.template( 'add-global-sections', args ) );
				
				pop.find('.m-p-body').append( sections );
				
				if( typeof args.callback == 'function' )
					args.callback( sections );
				
			},
			
			copy : function( e ){
					
				if( $(this).hasClass('copied') )
					return;
									
				var model = mini.get.model( this ),
					expo = mini.backbone.export( model );
					
				mini.backbone.stack.set( 'miniRowClipboard', expo.begin+expo.content+expo.end );
				
				mini.tools.toClipboard( expo.begin+expo.content+expo.end );
				
				$(this).addClass('copied');
				
				setTimeout( function( el ){
					$(el).removeClass('copied');
				}, 600, this );
				
				return;
	
			},
			
			edit : function( e ){
				
				var pop = mini.backbone.settings( this );
				if( !pop ){
					alert( mini.__.i41 );
					return;
				}
				
				pop.data({ after_callback : function( pop ){
					
					var id = mini.get.model( pop.data('button') ),
						params = mini.storage[ id ].args,
						html = '',
						el = $('#model-'+id+'>.mini-row-admin-view');

					if( params.row_id != undefined && params.row_id != '__empty__' )
						html += '#'+params.row_id+' ';
					
					el.html( html );
					
				}});
				
			},
			
			status : function( e ){
					
				var model = mini.get.model( this ), stt = '';
				if( mini.storage[ model ] !== undefined && mini.storage[ model ].args !== undefined ){
					
					if( $(this).hasClass('disabled') ){
						
						$(this).removeClass('disabled').closest('.mini-model').removeClass('collapse');
						delete mini.storage[ model ].args.disabled;
						
					}else{
						
						$(this).addClass('disabled').closest('.mini-model').addClass('collapse');
						mini.storage[ model ].args.disabled = 'on';
						
					}
					
					mini.changed = true;
					
				}
				
			}
			
		} ),
				
		column : new mini.backbone.views().extend({
			
			render : function( params ){
				
				params.name = 'mini_column'; params.end = '[/mini_column]';
				
				var _w = params.args['width'];
				if( _w != undefined ){
					_w = _w.split('/');
					_w = parseFloat((_w[0]/_w[1])*100).toFixed(4)+'%';
				}else{
					_w = '100%';
				}
				
				var el = $( mini.template( 'column', { width: _w } ) );

				mini.params.process_all( params.args.content, el.find('.mini-column-wrap') );
				
				this.el = el;
				
				return el;
				
			},
			
			events : {
				'>.column-container-control .mini-column-settings:click' : 'settings',
				'>.column-container-control .mini-column-toleft:click' : 'toLeft',
				'>.column-container-control .mini-column-toright:click' : 'toRight',
				'>.mini-column-control .mini-column-add:click' : 'add',
				'>.mini-column-control >.close:click' : 'remove',
			},
			
			
			remove : function( e, id ){
				
				if( !confirm( mini.__.sure ) )
					return;
				
				if( id == undefined )
					var id = mini.get.model( this );
				
				var col = $( '#model-'+id ),
					row = $( '#model-'+mini.get.model( col.parent().get(0) ) );
				
				col.find('.mini-model').each(function(){
					delete mini.storage[ mini.get.model(this) ];
				});
					
				col.remove();
				delete mini.storage[ id ];
				
				var cols = row.find('> .mini-row-wrap > .mini-model');
				cols.each(function(){
					var cid = $(this).data('model');
					mini.storage[ cid ].args.width = (12/cols.length)+'/12';
					$(this).css({ width: (100/cols.length)+'%' });
				});
				
			},
			
			toLeft : function( e ){
				
				var id = 	mini.get.model( this ),
					el = 	$('#model-'+id),
					prev = 	el.prev();
				
				if( !prev.get(0))
					return false;
					
				if( e.data.change_width( prev.data('model'), -1 ))
					return e.data.change_width( id, 1 );
				
			},
			
			toRight : function( e ){
				
				var id = 	mini.get.model( this ),
					el = 	$('#model-'+id),
					next = 	el.next();
				
				if( !next.get(0))
					return false;
				
				if( e.data.change_width( next.data('model'), -1 ))
					return e.data.change_width( id, 1 );
				
			},
			
			change_width : function( id, st ){
				
				var el  = $('#model-'+id),
					stg = mini.storage[id],
					sw  = stg.args.width.split('/');
					
					if( sw[1] != 12 ){
						sw[0] = parseInt(sw[0])*(12/parseInt(sw[1]));
						sw[1] = 12;
					}
					
				if( _.isUndefined( stg ) )
					return false;
				if( ( st == 1 && sw[1]/sw[0] == 1 ) || ( st == -1 && sw[1]/sw[0] == 6 ) || sw[0] == 2.4 )
					return false;
				if( st == -1 && sw[1]/sw[0] == 6 )
					return false;
				
				sw[0] =  parseInt(sw[0])+parseInt(st);
				
				mini.storage[id].args.width = sw[0]+'/'+sw[1];
				el.css({width:(100*(sw[0]/sw[1]))+'%'});
				
				return true;
				
			}
			
		}),
		
		mini_row_inner : new mini.backbone.views().extend({
			
			render : function( params ){
				
				params.name = 'mini_row_inner'; params.end = '[/mini_row_inner]';
				
				var el = $( mini.template( 'row-inner' ) );
				
				var content = params.args.content.toString().trim();
				
				if( content.indexOf('[mini_column') !== 0 ){
					content = '[mini_column_inner width="12/12"]'+
							   content.replace(/mini_column_inner/g,'mini_column_inner#')+
							   '[/mini_column_inner]';
				}			   
					
				mini.params.process_all( content, el.find('.mini-row-wrap') );
				
				this.el = el;
				
				return el;
			
			},
			
			events : {
				'.mini-row-inner-control > .settings:click' : 'settings',
				'.mini-row-inner-control > .double:click' : 'double',
				'.mini-row-inner-control > .delete:click' : 'remove',
				'.mini-row-inner-control > .copyRowInner:click' : 'copy',
				'.mini-row-inner-control > .columns:click' : 'columns',
				'.mini-row-inner-control > .collapse:click' : 'collapse',
			},
			
			collapse : function(){
				var elm = $('#model-'+mini.get.model(this));
				if( !elm.hasClass('collapse') ){
					elm.addClass('collapse');
				}else{
					elm.removeClass('collapse');
				}	
			},
			
			columns : function(){
				
				var columns = $(this).closest('.mini-row-inner').find('>.mini-row-wrap>.mini-column-inner.mini-model');

				var pop = mini.tools.popup.render( 
							this, 
							{ 
								title: mini.__.i42, 
								class: 'no-footer',
								width: 341,
								content: mini.template( 'row-columns', {current:columns.length} ),
								help: 'http://minicomposer.com/documentation/resize-sortable-columns/?source=client_installed' 
							}
						);
						
				pop.find('.button').on( 'click', 
					{ 
						model: mini.get.model( this ),
						columns: columns,
						pop: pop
					}, 
					mini.views.row.set_columns 
				);
				
				pop.find('input[type=checkbox]').on('change',function(){
					
					var name = $(this).data('name');
					if( name == undefined )
						return;
						
					if( this.checked == true )
						mini.cfg[ name ] = 'checked';
					else mini.cfg[ name ] = '';
					
					mini.backbone.stack.set( 'miniConfigs', mini.cfg );
						
				});	
						
			},
			
			copy : function(){
				
				if( $(this).hasClass('copied') )
					return;
					
				$(this).addClass('copied');
				setTimeout( function( el ){ el.removeClass('copied'); }, 1000, $(this) );
				
				mini.backbone.copy( this );
				
			}
			
		}),
		
		mini_column_inner : new mini.backbone.views().extend({
			
			render : function( params ){
				
				params.name = 'mini_column_inner'; params.end = '[/mini_column_inner]';
				
				var _w = params.args['width'];
				if( _w != undefined ){
					_w = _w.split('/');
					_w = ((_w[0]/_w[1])*100)+'%';
				}else{
					_w = '100%';
				}
				
				var el = $( mini.template( 'column-inner', { width: _w } ) );
	
				if( params.args.content !== undefined && params.args.content != '' )
					mini.params.process_all( params.args.content, el.find('.mini-column-wrap') );
				
				this.el = el;
					
				return el;
			
			},
			
			events : {
				'>.column-inner-control .mini-column-settings:click' : 'settings',
				'>.column-inner-control .mini-column-toleft:click' : 'toLeft',
				'>.column-inner-control .mini-column-toright:click' : 'toRight',
				'>.mini-column-control .mini-column-add:click' : 'add',
				'>.mini-column-control >.close:click' : 'remove',
			},

			toLeft : function( e ){
				
				var id = 	mini.get.model( this ),
					el = 	$('#model-'+id),
					prev = 	el.prev();
				
				if( !prev.get(0))
					return false;
					
				if( mini.views.column.change_width( prev.data('model'), -1 ))
					return mini.views.column.change_width( id, 1 );
				
			},
			
			toRight : function( e ){
				
				var id = 	mini.get.model( this ),
					el = 	$('#model-'+id),
					next = 	el.next();
				
				if( !next.get(0))
					return false;
				
				if( mini.views.column.change_width( next.data('model'), -1 ))
					return mini.views.column.change_width( id, 1 );
				
			},
			
			remove : function( e  ){
				
				mini.views.column.remove( e, mini.get.model( this ) );

			},
			
		}),
					
		mini_element : new mini.backbone.views().extend({
			
			render : function( params ){
				
				var map = $().extend( {}, mini.maps._std );
				map = $().extend( map, mini.maps[ params.name ] );
				
				var el = $( mini.template( 'element', { map : map, params : params } ) );
				
				setTimeout( function( params, map, el ){
					el.append( mini.params.admin_label.render({map: map, params: params, el: el }));
				}, parseInt(Math.random()*100)+100, params, map, el );
				
				this.el = el;
					
				return el;
				
			},
			
			events : {
				'>.mini-element-control .edit:click' : 'edit',
				'>.mini-element-control .delete:click' : 'remove',
				'>.mini-element-control .double:click' : 'double',
				'>.mini-element-control .more:click' : 'more',
				'>.mini-element-control .copy:click' : 'copy',
				'>.mini-element-control .cut:click' : 'cut',
				'>.mini-element-control:click' : function( e ){
					var tar = $(e.target);
					if( tar.hasClass('more') || tar.parent().hasClass('more') )
						return;
					$(this).find('.active').removeClass('active');
				},
			},
			
			edit : function( e ){
				
				var pop = mini.backbone.settings( this );
				if( !pop ){
					alert( mini.__.i43 );
					return;
				}	
				
				$(this).closest('.mini-element').addClass('editting');
				pop.data({cancel: function(pop){
					
					$( pop.data('button') ).closest('.mini-element').removeClass('editting');
					
				},after_callback : function( pop ){
					
					var id = mini.get.model( pop.data('button') ),
						params = mini.storage[ id ], 
						map = $().extend( {}, mini.maps._std ),
						el = $('#model-'+id);
					
					map = $().extend( map, mini.maps[ params.name ] );
					el.find('>.admin-view').remove();
					el.append( mini.params.admin_label.render({map: map, params: params, el: el }));
	
				}});
				
			}
			
		}),
							
		mini_undefined : new mini.backbone.views().extend({
			
			render : function( params ){
				
				var map = $().extend( {}, mini.maps._std );
				map = $().extend( map, mini.maps[ params.name ] );
				
				var el = $( mini.template( 'undefined', { map : map, params : params } ) );
				
				this.el = el;
				
				return el;
				
			},
			
			events : {
				'>.mini-element-control .edit:click' : 'edit',
				'>.mini-element-control .delete:click' : 'remove',
				'>.mini-element-control .double:click' : 'double'
			},
			
			edit : function( e ){

				var pop = mini.backbone.settings( this );
				if( !pop ){
					alert( mini.__.i45 );
					return;
				}	
				
				$(this).closest('.mini-element').addClass('editting');
				pop.data({cancel: function(pop){
					
					$( pop.data('button') ).closest('.mini-element').removeClass('editting');
					
				},after_callback : function( pop ){
					
					$( pop.data('button') ).closest('.mini-element').removeClass('editting');
					
					var id = mini.get.model( pop.data('button') ),
						params = mini.storage[ id ], 
						map = $().extend( {}, mini.maps._std ),
						el = $('#model-'+id);
					
					map = $().extend( map, mini.maps[ params.name ] );
					el.find('>.admin-view').remove();
					el.append( mini.params.admin_label.render({map: map, params: params, el: el }));
	
				}});
				
			},
			
			remove : function( e ){
				if( confirm( mini.__.sure ) ){
					var elm = $(this).closest('div.mini-element');
					var mid = elm.data('model');
					elm.remove();
					delete mini.storage[mid];	
				}
			}
			
		}),

	} );
	
} )( jQuery );