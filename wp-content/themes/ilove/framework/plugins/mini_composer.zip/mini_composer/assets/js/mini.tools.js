/*
 * Mini Composer Project
 *
 * (c) Copyright King-Theme.com
 *
 * Must obtain permission before using this script in any other purpose
 *
 * mini.tools.js
 *
*/

( function($){
	
	if( typeof( mini ) == 'undefined' )
		window.mini = {};
		
	$().extend( mini.tools, {
		
		esc_slug : function (str){
			
			str = str.replace(/^\s+|\s+$/g, '');
			str = str.toLowerCase();
			
			var from = "àáäâèéëêìíïîòóöôùúüûñç·/_,:;";
			var to   = "aaaaeeeeiiiioooouuuunc------";
		
			for (var i=0, l=from.length ; i<l ; i++)
			{
				str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
			}
		
			str = str.replace(/[^a-z0-9 -]/g, '')
				.replace(/\s+/g, '-')
				.replace(/-+/g, '-');
		
			return str;
			
		},
		
		esc_attr : function( str ) {
			if( !str ){
				return '';
			}
		    return str.toString()
		    		  .replace(/</g, ':lt:')
		    		  .replace(/>/g, ':gt:')
		    		  .replace(/\[/g, ':lsqb:')
		    		  .replace(/\]/g, ':rsqb:')
		    		  .replace(/"/g, ':quot:')
		    		  .replace(/'/g, ':apos:');
		},
		
		unesc_attr : function( str ) {
			if( !str ){
				return '';
			}
		    return str.toString()
		 		      .replace(/:lt:/g, '<')
		    		  .replace(/:gt:/g, '>')
		    		  .replace(/:lsqb:/g, '[')
		    		  .replace(/:rsqb:/g, ']')
		    		  .replace(/:quot:/g, '"')
		    		  .replace(/:apos:/g, '\'');
		},

		esc : function( str ) {
			if( !str ){
				return '';
			}
		    return str.toString().replace(/&/g, '&amp;')
		    		  .replace(/</g, '&lt;')
		    		  .replace(/>/g, '&gt;')
		    		  .replace(/"/g, '&quot;')
		    		  .replace(/'/g, '&apos;');
		},
		
		unesc : function(str) {
			if( str == undefined ){
				return '';
			}
		    return str.toString().replace(/&amp;/g, '&')
		    		  .replace(/&lt;/g, '<')
		    		  .replace(/&gt;/g, '>')
		    		  .replace(/&quot;/g, '"')
		    		  .replace(/&apos;/g, '\'');
		},
		
		rawdecode : function( input ){
			return decodeURIComponent( input+'' );
		},
		
		rawencode : function( input ){
			input = (input+'').toString();
			return encodeURIComponent( input ).
				   replace(/!/g,'%21').
				   replace(/'/g,'%27').
				   replace(/\(/g,'%28').
				   replace(/\)/g,'%29').
				   replace(/\*/g,'%2A');
		},
		
		decode_css : function( css ){
			
			var css_code = '';
			
			css = css.replace( /\s+/g, ' ' )
				 .replace(/\/\*[^\/\*]+\*\//g,'')
				 .replace(/[^a-zA-Z0-9\-\_\. \:\(\)\%\+\~\;\#\'\{\}\@\/]+/g,'')
				 .trim().split( '{' );
			
			for( var n in css  ){
				
				if( css[n].indexOf('}') > -1 )
				{
					css[n] = css[n].split('}');
					css[n][0] = css[n][0].split(';');
					for( var m in css[n][0] )
					{
						if( css[n][0][m].trim() != '' )
							css_code += "	"+css[n][0][m]+";\n";
					}
					if( css[n][1].trim() != '' )
						css_code += "}\n"+css[n][1]+"{\n";
					else 
						css_code += "}\n";	
					if( css[n][2] != undefined )	
						css_code += "}\n";	
				}
				else if( css[n].trim() != '' )
				{
					css_code += css[n]+"{\n"
				}
				
			}
			
			return css_code;

		},
		
		encode_css : function( css ){
			
			if( css == undefined )
				css = '';
			css = css.replace(/\/\*[^\/\*]+\*\//g,'')
					 .replace( /\ \ /g, '' )
					 .replace(/[^a-zA-Z0-9\-\_\. \:\(\)\%\+\~\;\#\'\{\}\@\/]+/g,'').trim();
					 
			return css;
				
		},
		
		getFormData : function( $form ){
			
		    var unindexed = $form.serializeArray(), indexed = {}, avoidRepeat = {}, name, obs, j, k;
		
		    $.map( unindexed, function( n, i ){
			    
			    if( n['name'].indexOf('[') == -1 ){
				    
				    if( n['value'] != '' ){
					    if( indexed[ n['name'] ] == undefined || indexed[ n['name'] ] == '__empty__' )
							indexed[ n['name'] ] = n['value'];
						else
							indexed[ n['name'] ] += ','+n['value'];
				    }else if( indexed[ n['name'] ] === undefined ){
						indexed[ n['name'] ] = '';
				    }
			    	
			    	
			    }else{
				    
				    n['name'] = "["+n['name'].replace('[','][');
				    name = n['name'].replace( /\[/g, "['" ).replace( /\]/g, "']" );
			    
		        
			        obs = [];
			       
			        [].forEach.call( n['name'].split(']['), function( sp ){
				        sp = sp.replace( /\[/g, '' ).replace( /\]/g, '' ).trim();
				        obs[ obs.length ] = sp;
			        });
			        
			        if( obs.length > 0 ){
				        k = '';
				        for( j=0; j<obs.length; j++){
					        k += "['"+obs[j]+"']";
					        eval("if( indexed"+k+"==undefined )indexed"+k+"={};");
				        }
			        }
			        
				    eval("indexed"+name+" = n['value'];");
			    
			    }
		        
		    });
			
		    return indexed;
		    
		},
		
		basename : function( str ){
			
			var base = str.split(/[\\/]/).pop();
				
		    if( base.lastIndexOf(".") != -1 )       
		        base = base.substring( 0, base.lastIndexOf(".") );
		        
			return base;
		       	
		},
		
		toClipboard : function( str ) {
			
			if (window.clipboardData) {
                window.clipboardData.setData ("Text");
            }else {
	   			
	   			document.oncopy = function(event) {
					event.clipboardData.setData('text', str);
					event.preventDefault();
				};
				
				document.execCommand("Copy", false, null);
				
				document.oncopy = null;
				
			}
		},
		
		rgb2hex : function( rgb ) {

			if( rgb.indexOf('rgb') == -1 )
				return rgb;
		
			rgb = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);

			function hex(x) {
				return ("0" + parseInt(x).toString(16)).slice(-2);
			}

			return "#" + hex(rgb[1]) + hex(rgb[2]) + hex(rgb[3]);

		},
		
		hex2rgb : function(hex) {

		    r = hex.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i);
		    if (r) {
		            return r.slice(1,4).map(function(x) { return parseInt(x, 16); });
		    }
		    // short version
		    r = hex.match(/^#([0-9a-f])([0-9a-f])([0-9a-f])$/i);
		    if (r) {
		            return r.slice(1,4).map(function(x) { return 0x11 * parseInt(x, 16); });
		    }
		    return hex;
		},
		
		base64 : {
			
		    codex : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
		
		    encode : function (input){
			    
			    if( input == undefined ){
					return '';
				}
				
		        var output = new this.stringBuffer();
		
		        var enumerator = new this.utf8EncodeEnumerator(input);
		        
		        while (enumerator.moveNext()){
			        
		            var chr1 = enumerator.current;
		
		            enumerator.moveNext();
		            var chr2 = enumerator.current;
		
		            enumerator.moveNext();
		            var chr3 = enumerator.current;
		
		            var enc1 = chr1 >> 2;
		            var enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
		            var enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
		            var enc4 = chr3 & 63;
		
		            if (isNaN(chr2)){
		                enc3 = enc4 = 64;
		            }
		            else if (isNaN(chr3)){
		                enc4 = 64;
		            }
		
		            output.append(this.codex.charAt(enc1) 
		            			+ this.codex.charAt(enc2) 
		            			+ this.codex.charAt(enc3) 
		            			+ this.codex.charAt(enc4));
		        }
		
		        return output.toString();
		    },
		
		    decode : function (input){
			    
			    if( input == undefined ){
					return '';
				}
			    
		        var output = new this.stringBuffer();
		
		        var enumerator = new this.decodeEnumerator(input);
		        while (enumerator.moveNext()){
			        
		            var charCode = enumerator.current;
		
		            if (charCode < 128){
		                output.append(String.fromCharCode(charCode));
		            }else if ((charCode > 191) && (charCode < 224)){
		                enumerator.moveNext();
		                var charCode2 = enumerator.current;
		
		                output.append(String.fromCharCode(((charCode & 31) << 6) | (charCode2 & 63)));
		            }else{
		                enumerator.moveNext();
		                var charCode2 = enumerator.current;
		
		                enumerator.moveNext();
		                var charCode3 = enumerator.current;
		
		                output.append(String.fromCharCode(((charCode & 15) << 12) | ((charCode2 & 63) << 6) | (charCode3 & 63)));
		            }
		        }
		
		        return output.toString();
		    },
		    
		    stringBuffer : function() {
			    this.buffer = []
			},
			
			utf8EncodeEnumerator : function(input) {
			    this._input = input;
			    this._index = -1;
			    this._buffer = []
			},
			
			decodeEnumerator : function(input) {
			    this._input = input;
			    this._index = -1;
			    this._buffer = []
			}

		},
		
		media : {
			
			el : null,
			
			callback : null,
			
			uploader : null,
			
			open : function( e ){
				
				if( typeof e.preventDefault == 'function' )
					e.preventDefault();
				
				
				atts = $().extend(
							{ frame: 'select', multiple: false, title: 'Choose Image', button: 'Choose Image', type: 'image' },
							e.data.atts );
				
				mini.tools.media.el = this;
				
				if( typeof e.data.callback == 'function' )
					mini.tools.media.callback = e.data.callback;
				else mini.tools.media.callback = null;
				
		        if ( mini.tools.media.uploader ) {
		           return mini.tools.media.uploader.open();
		        }
				
				var insertImage = wp.media.controller.Library.extend({
				    defaults :  _.defaults({
			            id: 'insert-image',
			            title: atts.title,
			            button: {
			                text: atts.button
			            },
			            multiple: false,
						editing:   true,
						allowLocalEdits: true,
			            displaySettings: true,
			            displayUserSettings: true,    
			            type : atts.type
				      }, wp.media.controller.Library.prototype.defaults )
				});

		        //Extend the wp.media object
		        mini.tools.media.uploader = wp.media.frames.file_frame = wp.media({         
		            frame: atts.frame,
		            state : 'insert-image',
				    states : [ new insertImage() ]
		        });
				
		        mini.tools.media.uploader.on('select', function( e ) {
			        
			        var currentSize = $('.attachment-display-settings .size').val()
		        	var state = mini.tools.media.uploader.state('insert-image');
		            var attachments = state.get('selection');
		            
		            if( attachments.length === 0 ){
			            
			            if( $('#embed-url-field').get(0) && $('#embed-url-field').val() != null ){
				            if( typeof mini.tools.media.callback == 'function' )
					     	 	mini.tools.media.callback( { 
						     	 		url: $('#embed-url-field').val(), sizes: {} }, 
						     	 		$(mini.tools.media.el) 
						     	 	);
			            }
			            
		            }else{
			            
			            attachments.map( function( attachment ) {
				            
					     	 var attachment = attachment.toJSON();
					     	 attachment.size = currentSize;
					     	 if( typeof mini.tools.media.callback == 'function' )
					     	 	mini.tools.media.callback( attachment, $(mini.tools.media.el) );
					    });
				    
				    }
		
		        });
				
				mini.tools.media.uploader.on('open', function( e ) {
					 	
				 	var ids = $(mini.tools.media.el).parent().find('.mini-param').val();
				 	if( ids === undefined || ids == null || ids == '' )
				 		return;
				 		
				 	ids = ids.split(',');
			 	
				 	var selection = mini.tools.media.uploader.state().get('selection');
				 	var attachments = [];
				 	
				 	ids.forEach(function( id ){
						attachments[ attachments.length ] = wp.media.attachment( id );
					});
					
					selection.add( attachments );

				 						
				});
				
		        //Open the uploader dialog
		       return mini.tools.media.uploader.open();
			   
		    },		
		    
		    els : null,
			
			callbacks : null,
			
			uploaders : null,
			
			opens : function( e ){
				
				if( typeof e.preventDefault == 'function' )
					e.preventDefault();
				
				mini.tools.media.els = this;
				
				if( typeof e.data == 'function' )
					mini.tools.media.callbacks = e.data;
				else mini.tools.media.callbacks = null;	
				
		        if ( mini.tools.media.uploaders ) {
		           mini.tools.media.uploaders.open();
		           return false;
		        }
				
		        //Extend the wp.media object
		        mini.tools.media.uploaders = wp.media.frames.file_frame = wp.media({
		            title: mini.__.i46,
		            button: {
		                text: mini.__.i46
		            },
		            multiple: true,
					editing:   true,
					allowLocalEdits: true,
		            displaySettings: true,
		            displayUserSettings: true,
		            
		        });
		 
		        mini.tools.media.uploaders.on('select', function( e ) {
		        
		            var attachments = mini.tools.media.uploaders.state().get('selection');
		            attachments.map( function( attachment ) {
				     	 var attachment = attachment.toJSON();
				     	 if( typeof mini.tools.media.callbacks == 'function' )
				     	 	mini.tools.media.callbacks( attachment, $(mini.tools.media.els) );
				    });
		
		        });
		        
		        mini.tools.media.uploaders.on('open', function( e ) {
					
					// Maybe we dont need to active selected images
					return false;
					 	
				 	var ids = $(mini.tools.media.els).parent().find('.mini-param').val();
				 	if( ids === undefined || ids == null || ids == '' )
				 		return;
				 		
				 	ids = ids.split(',');
			 	
				 	var selection = mini.tools.media.uploaders.state().get('selection');
				 	var attachments = [];
				 	
				 	ids.forEach(function( id ){
						attachments[ attachments.length ] = wp.media.attachment( id );
					});
					
					selection.add( attachments );
				 						
				});
		        
		        //Open the uploader dialog
				mini.tools.media.uploaders.open();
			   
			   return false;
			   
		    }
	
		},
		
		popup : new mini.backbone.views( 'no-model' ).extend({
			
			render : function( el, atts ){
				
				var keepCurrent = false;
				if( atts != undefined ){
					if( atts.keepCurrentPopups == true ){
						keepCurrent = true;
					}
				}
				
				if( keepCurrent == false )
					$('.mini-params-popup .sl-close.sl-func').trigger('click');
				
				$('.sys-colorPicker').remove();
				$('.mini-controls .more.active').removeClass('active');
				
				var pop_width = 580;
				if( atts.width != undefined )
					pop_width = atts.width;
				var coor = this.coordinates( el, pop_width, keepCurrent );
				
				var atts = $().extend({ 
						top: coor[0], 
						left: coor[1],
						pos: coor[2],
						bottom: coor[3],
						tip: coor[4],
						width: pop_width,
						class: '',
						drag: true,
						content: '', 
						title: 'Settings',
						help: '',
						footer: true,
						footer_text: '',
						save_text: mini.__.save,
						cancel_text: mini.__.cancel
					}, atts );
				
				if( atts.footer === false && atts.class.indexOf('no-footer') == -1 )
					atts.class += ' no-footer';	
						
				this.el = $( mini.template( 'popup', atts ) );
				this.el.data({ 'button' : el, 'keepCurrentPopups' : keepCurrent });
				
				if( atts.tip != 0 )
					this.el.find( '.wp-pointer-arrow' ).css({marginRight: -atts.tip+'px'});
								
				if( atts.scrollBack == true )
					this.el.data({ 'scrolltop' : $(window).scrollTop() });
					
				$('body').append( this.el  );
				
				if( atts.drag == true ){
					mini.ui.draggable( this.el.get(0), 'h3.m-p-header' );
				}
				
				$( this.el ).css({opacity: 1});
				
				setTimeout( function( el, atts ){
					
					var wsct = $(window).scrollTop(), wh = $(window).height(),
						wheight = wsct+(wh*0.4),
						newrect = el.get(0).getBoundingClientRect();
						
					if( ( atts.top > wheight && el.height()+atts.top > wsct + wh && atts.bottom == 0 ) )
						mini.ui.scrollAssistive( (atts.top - 50), false );
					else if( newrect.top < 0 )
						mini.ui.scrollAssistive( (wsct+newrect.top) - 50, false );
					
				}, 1, this.el, atts );
				
				return this.el;
				
			},
			
			coordinates : function( el, pop_width, keepCurrent ){
				
				if( $(el).closest('#mini-container').get(0) )
					var grids = document.getElementById('mini-container').getBoundingClientRect();
				else var grids = document.getElementById('wpbody-content').getBoundingClientRect();
				
				if( el === undefined )
					return [0,0,0,0];
					
				var coor = el.getBoundingClientRect(),
					swidth = (grids.width/3),
					sleft = coor.left-grids.left,
					top = coor.top+$(window).scrollTop()+coor.height,
					bottom = 0,
					left = coor.left+$(window).scrollLeft()+(coor.width/2),
					tip = 0,
					pos = '',
					wheight = $(document).height(),
					wwidth = $(document).width();
					
				if( sleft < swidth ){
					pos = 'left';
					left -= 63;
				}else if( sleft > swidth && sleft < swidth*2 ){
					pos = 'center';
					left -= (pop_width/2);
				}else if( sleft > swidth*2 && sleft < swidth*3 ){
					pos = 'right';
					left -= (pop_width-63);
				}
				if( wheight - top < 200 && $(window).scrollTop() > 0 ){
					
					bottom = wheight-top+(coor.height/2);
					$('html').height( wheight - parseInt( $('html').css('padding-top') ) );
				
				}else if( keepCurrent !== true ){
					$('html').height('');
				}
				
				if( left < 50 ){
					tip = left - 50;
					left = 50;
				}
				
				if(  left+swidth > wwidth ){
					left -= ( (left+swidth) - wwidth ) + 50;
				}
				return [ top, left, pos, bottom, tip ];
				
			},
			
			events : {
				'.m-p-controls>li>.cancel,.m-p-header .sl-close:click' : 'cancel',
				'.m-p-header:dblclick' : 'cancel',
				'.m-p-controls>li>.save,.m-p-header .sl-check:click' : 'save'
			},
			
			cancel : function( e ){

				// We will dont close the popup when in instant saving
				if( $('#instantSaving').length > 0 )
					return;

				if( e.target.tagName == 'INPUT' )
					return;
				
				var el = $(this).closest('.mini-params-popup'), keepCurrent = el.data('keepCurrentPopups');
				
				if( typeof el.data('before_cancel') == 'function' ){
					if( el.data('before_cancel')( el, e ) == 'prevent' )
						return;
				}	
					
				if( typeof el.data('cancel') == 'function' )
					el.data('cancel')( el);
				
				if( typeof el.data('after_cancel') == 'function' )
					el.data('after_cancel')( el );
					
				if( el.data('scrolltop') != undefined )
					e.data.scrollback( el.data('scrolltop'), el.data('button') );
					
				if( el.data('keepCurrentPopups') !== true )
					$('html').height('');
					
				el.remove();
				$('.sys-colorPicker').remove();
				// remove date picker
				$('.pika-single').remove();
				
				if( keepCurrent == false )
					$('.mini-params-popup .sl-close.sl-func').trigger('click');
				
			},
			
			save : function( e ){
				
				var el = $(this).closest('.mini-params-popup'), keepCurrent = el.data('keepCurrentPopups');
				
				e.data.el = el;
				
				if( typeof el.data('before_callback') == 'function')
					el.data('before_callback')( el );
					
				if( typeof el.data('callback') == 'function')
					el.data('callback')( el );
					
				if( typeof el.data('after_callback') == 'function')
					el.data('after_callback')( el );
				
				// We will dont close the popup when in instant saving
				if( $('#instantSaving').length > 0 )
					return;	
					
				if( el.data('scrolltop') != undefined )
					e.data.scrollback( el.data('scrolltop'), el.data('button') );
				
				//el.remove();
				el.find('.sl-close.sl-func').trigger('click');
				
				if( keepCurrent == false ){
					$('.mini-params-popup .sl-close.sl-func').trigger('click');
					$('html').height('');
				}
				
			},
			
			scrollback : function( sctop, btn ){
				
				
				var now = $(window).scrollTop();
				
				if( Math.abs( sctop - now ) > 200 ){
					
					mini.ui.scrollAssistive( sctop );
					
					$( btn ).removeClass('bum-effs');
					if( btn.tagName != 'INPUT'  )
						setTimeout( function( el ){ 
							
							$(el).addClass('bum-effs');
							setTimeout(function( el ){
								$(el).removeClass('bum-effs');
							}, 1500, el );
							
						}, 100, btn );
					
				}
				
			},
			
			add_tab : function( pop, args ){
				
				args = $().extend( { title: '', class: '', cfg: '', callback: function(){} }, args );
				
				var ul = pop.find('.m-p-wrap ul.mini-pop-tabs'), 
					slug = 'mini-tab-'+Math.abs(parseInt(Math.random()*1000)), 
					li = $('<li data-tab="'+slug+'" data-cfg="'+args.cfg+'" class="'+args.class+'">'+args.title+'</li>');
				
				if( !ul.get(0) ){
					
					/* if this is first tab be added */
					ul = $('<ul class="mini-pop-tabs"></ul>');
					
					if( pop.find('.fields-edit-form').length > 0 ){
						
						var fli = $('<li data-tab="fields-edit-form" class="mini-tab-general-title active"><i class="et-tools"></i> General</li>')
						ul.append( fli );
						fli.on( 'click', function(){
							
							var wrp = $(this).closest('.m-p-wrap');
							
							wrp.find('>.mini-pop-tabs li').removeClass('active');
							$(this).addClass('active');
							
							wrp.find('.m-p-body>.mini-pop-tab').removeClass('form-active');
							wrp.find('.m-p-body>.fields-edit-form').addClass('form-active');
						
						});
						
					}
					
					
					pop.find('.m-p-header').after( ul );
					
				}
				
				ul.append( li );
				
				/* Add event for new tab which just be created */
				li.on( 'click', args.callback, function(e){
					
					var slug = $(this).data('tab'), wrp = $(this).closest('.m-p-wrap').find('>.m-p-body');
					
					$(this).closest('.m-p-wrap').find('>.mini-pop-tabs li').removeClass('active');
					$(this).addClass('active');
					wrp.find('>.mini-pop-tab').removeClass('form-active');
					var tab = wrp.find('>.'+slug);
					
					if( tab.get(0) ){
						
						tab.addClass('form-active');
						
						var callback = $(this).data('callback');
						if( typeof callback == 'function' )
							callback( this, tab );
						
						return;
						
					}
					
					tab = $('<form class="mini-pop-tab '+slug+' form-active"></form>');
					
					wrp.append( tab );
					
					tab.on( 'submit', function(){
						$(this).closest('.mini-params-popup').find('.m-p-footer .save').trigger('click');
						return false;
					});
					
					if( typeof e.data == 'function' )
						tab.append( e.data( this , tab ) );
					
					var callback = $(this).data('callback');
					if( typeof callback == 'function' )
						callback( this, tab );
						
				});
				
			}
			
		}),
		
		editor : {
			
			insert : function( id, html ){
				
				var editor,
					hasTinymce = typeof tinymce !== 'undefined',
					hasQuicktags = typeof QTags !== 'undefined';
			
				wpActiveEditor = id;
				
				if ( hasTinymce ) {
					editor = tinymce.get( wpActiveEditor );
				}

				if ( editor && ! editor.isHidden() ) {
					editor.execCommand( 'mceInsertContent', false, html );
				} else if ( hasQuicktags ) {
					QTags.insertContent( html );
				} else {
					document.getElementById( wpActiveEditor ).value = html;
				}

			},
			
			init : function ( textarea ) {
				
				if ( $( '#wp-link' ).parent().hasClass( 'wp-dialog' ) ) {
					$( '#wp-link' ).wpdialog( 'destroy' );
				}
				var eid = textarea.attr( "id" ), tmi = window.tinyMCEPreInit, tmic = tmi.mceInit, tmiq = tmi.qtInit;
				try {
					
					if ( _.isUndefined( tinyMCEPreInit.qtInit[ eid ] ) ) {
						tmiq[ eid ] = _.extend( {}, tmiq[ window.wpActiveEditor ], { id: eid } );
					}
					if ( tmi && tmic[ window.wpActiveEditor ] ) {
						tmic[ eid ] = _.extend( 
							{}, 
							tmic[ window.wpActiveEditor ],
							{
								resize: 'vertical',
								height: 250,
								id: eid,
								setup: function ( e ) {
									if ( typeof(e.on) != 'undefined' ) {
										e.on( 'init', function ( e ) {
											e.target.focus();
											window.wpActiveEditor = eid;
										});
									} else {
										e.onInit.add( function ( e ) {
											e.focus();
											window.wpActiveEditor = eid;
										});
									}
								}
							}
						);
						
						tmic[ eid ].wp_autoresize_on = false;
						
						window.wpActiveEditor = eid;
											
					}
					
					quicktags( tmic[ eid ] );
					QTags._buttonsInit();
					
					if ( window.tinymce ) {
						
						window.switchEditors && window.switchEditors.go( eid, 'tmce' );
						
						if ( tinymce.majorVersion === "4" ) {
							tinymce.execCommand( 'mceAddEditor', true, eid );
						}
						
					}
					
				} catch ( e ) {
					$( '#wp-' + eid + '-wrap' ).html('Tinymce Error!');
					if ( console && console.error ) {
						console.error( e );
					}
				}
			}			
		},
		
		get_icons : function(){
			
			if( mini.icons != undefined )
				return mini.icons;
			
			function css_text(x) { return x.cssText; }
			var file = document.getElementById('mini-icons-css');
			if( !file )
				return '';
			var css = Array.prototype.map.call( file.sheet.cssRules, css_text ).join('\n'), html = '';	
			
			css = css.split('::before');
			
			css.forEach(function( i ){
				i = i.split('.')[1];
				if( i !== undefined && i.indexOf('/') == -1 )
					html += '<i title="'+i.replace(/[^a-z-0-9]/g, "")+'" class="'+i.replace(/[^a-z-0-9]/g, "")+'"></i>';
			});
			
			mini.icons = html;

			return html;
			
		}
		
	} );
	
	mini.tools.base64.stringBuffer.prototype.append = function append(string) {
	    this.buffer.push(string);
	    return this
	};
	
	mini.tools.base64.stringBuffer.prototype.toString = function toString() {
	    return this.buffer.join("")
	};
	
	mini.tools.base64.utf8EncodeEnumerator.prototype = {
		
	    current: Number.NaN,
	    
	    moveNext: function() {
	        if (this._buffer.length > 0) {
	            this.current = this._buffer.shift();
	            return true
	        } else if (this._index >= (this._input.length - 1)) {
	            this.current = Number.NaN;
	            return false
	        } else {
	            var charCode = this._input.charCodeAt(++this._index);
	            if ((charCode == 13) && (this._input.charCodeAt(this._index + 1) == 10)) {
	                charCode = 10;
	                this._index += 2
	            }
	            if (charCode < 128) {
	                this.current = charCode
	            } else if ((charCode > 127) && (charCode < 2048)) {
	                this.current = (charCode >> 6) | 192;
	                this._buffer.push((charCode & 63) | 128)
	            } else {
	                this.current = (charCode >> 12) | 224;
	                this._buffer.push(((charCode >> 6) & 63) | 128);
	                this._buffer.push((charCode & 63) | 128)
	            }
	            return true
	        }
	    }
	};
	
	mini.tools.base64.decodeEnumerator.prototype = {
		
	    current: 64,
	    
	    moveNext: function() {
	        if (this._buffer.length > 0) {
	            this.current = this._buffer.shift();
	            return true
	        } else if (this._index >= (this._input.length - 1)) {
	            this.current = 64;
	            return false
	        } else {
	            var enc1 = mini.tools.base64.codex.indexOf(this._input.charAt(++this._index));
	            var enc2 = mini.tools.base64.codex.indexOf(this._input.charAt(++this._index));
	            var enc3 = mini.tools.base64.codex.indexOf(this._input.charAt(++this._index));
	            var enc4 = mini.tools.base64.codex.indexOf(this._input.charAt(++this._index));
	            var chr1 = (enc1 << 2) | (enc2 >> 4);
	            var chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
	            var chr3 = ((enc3 & 3) << 6) | enc4;
	            this.current = chr1;
	            if (enc3 != 64) this._buffer.push(chr2);
	            if (enc4 != 64) this._buffer.push(chr3);
	            return true
	        }
	    }
	};
	
	
} )( jQuery );
