/*
 * Mini Composer
 *
 * Copyright King-Theme.com
 *
 *
*/

var mini_front = ( function($){

	return {

		win_height : 0,

		win_width : 0,

		parallax_timer : null,

		init : function(){

			var parallaxable = $('div[data-mini-parallax="true"]');
			if( parallaxable.length > 0 )
			{
				parallaxable.each( function(){
					var speed = $(this).data('speed')*0.4;
					$(this).parallax("50%", speed);
				});
			}

			this.accordion();

			this.tabs();

			this.youtube_row_background.init();

			$( window ).on( 'resize', mini_row_full );

			$( window ).trigger( 'resize' );

			if( window.location.href.indexOf('#') > -1 ){
				$('a[href="#'+window.location.href.split('#')[1]+'"]').trigger('click');
			}

			//Google maps
			this.google_maps.add();

			this.image_gallery.slider();

			this.image_gallery.masonry();

			this.carousel_images();

			this.carousel_post();

			this.countdown_timer();

			this.piechar.init();

			this.progress_bar.run();

			this.flipbox_fixed_height();

			this.progress_bar_fixed_height();

			this.ajax_action();
		},

		refresh: function( el ){

			setTimeout( function( el){

				mini_front.google_maps.resize( el );
				mini_front.flipbox_fixed_height();
				mini_front.piechar.update( el );
				mini_front.progress_bar.update( el );
				mini_front.image_gallery.masonry_refresh( el );

				if($('.mini_video_play').length > 0){
					mini_video_play.refresh( el );
				}

			}, 100, el );

		},

		accordion: function(){

			$('.mini_accordion_wrapper').each(function(){

				$( this ).find('>div.mini_accordion_section>h3.mini_accordion_header>a').off('click').on('click',function( e ){

					var wrp = $(this).closest('.mini_accordion_wrapper'),
						section = $(this).closest('.mini_accordion_section'),
						allowopenall = (true === wrp.data('allowopenall')) ? true : false,
						changed = section.find('>h3.mini_accordion_header').hasClass('ui-state-active');

					if( allowopenall === false ){

						wrp.find( '>.mini_accordion_section>.mini_accordion_content' ).slideUp();

						wrp.find('>h3.mini_accordion_header').removeClass('ui-state-active');

						section.find('>.mini_accordion_content').stop().slideDown();
						section.find('>h3.mini_accordion_header').addClass('ui-state-active');

					}else{

						if( section.find('>h3.mini_accordion_header').hasClass('ui-state-active') ){
							section.find('>.mini_accordion_content').stop().slideUp();
							section.find('>h3.mini_accordion_header').removeClass('ui-state-active');
						}else{
							section.find('>.mini_accordion_content').stop().slideDown();
							section.find('>h3.mini_accordion_header').addClass('ui-state-active');
						}

					}

					if( changed != section.find('>h3.mini_accordion_header').hasClass('ui-state-active') )
						mini_front.refresh( section.find('>.mini_accordion_content') );

					e.preventDefault();

				}).eq(0).trigger('click');

			});
		},

		tabs: function(){

			$('.mini_tabs > .mini_wrapper').each( function( index ){

				var $_this = $(this),
					tab_group = $_this.parent('.mini_tabs.group'),
					tab_event = ('yes' === tab_group.data('open-on-mouseover')) ? 'mouseover' : 'click',
					effect_option = ('yes' === tab_group.data('effect-option')) ? true : false,
					active_section = parseInt( tab_group.data('tab-active') ) - 1;


				if( -1 === active_section )
					active_section = 0;

				$( this ).find('>.mini_tabs_nav>li>a,.ui-tabs-nav>li>a').off('click').on( 'click', function(e){
					e.preventDefault();
				} ).off( tab_event ).on( tab_event, function(e){

					if( $(this).parent().hasClass('ui-tabs-active') ){
						e.preventDefault();
						return;
					}
					
					var labels = $(this).closest('.mini_tabs_nav,.ui-tabs-nav').find('>li'),
						index = labels.index( this.parentNode ),
						tab_list = $(this).closest('.mini_wrapper').find('>.mini_tab'),
						new_panel = tab_list.eq( index );

					labels.removeClass('ui-tabs-active');
					$(this).parent().addClass('ui-tabs-active');

					tab_list.hide();
					new_panel.show();

					if( effect_option === true)
						new_panel.css({'opacity':0}).animate({opacity:1});

					mini_front.refresh( new_panel );

					e.preventDefault();

				}).eq( active_section ).trigger( tab_event );

			});

		},

		youtube_row_background: {

			init: function(){

				$( '.mini_row' ).each( function () {
					var $row = $( this ),
						youtubeUrl,
						youtubeId;

					if ( $row.data( 'mini-video-bg' ) ) {
						youtubeUrl = $row.data( 'mini-video-bg' );
						youtubeId = mini_front.youtube_row_background.getID( youtubeUrl );

						if ( youtubeId ) {
							$row.find( '.mini_wrap-video-bg' ).remove();
							mini_front.youtube_row_background.add( $row, youtubeId );
						}

					} else {
						$row.find( '.mini_wrap-video-bg' ).remove();
					}
				} );
			},

			getID: function ( url ) {
				if ( 'undefined' === typeof(url) ) {
					return false;
				}

				var id = url.match( /(?:https?:\/{2})?(?:w{3}\.)?youtu(?:be)?\.(?:com|be)(?:\/watch\?v=|\/)([^\s&]+)/ );
				if ( null !== id ) {
					return id[ 1 ];
				}

				return false;
			},

			add: function( $obj, youtubeId, counter ) {

				if( YT === undefined )
					return;

				if ( 'undefined' === typeof( YT.Player ) ) {

					counter = 'undefined' === typeof( counter ) ? 0 : counter;
					if ( counter > 100 ) {
						console.warn( 'Too many attempts to load YouTube api' );
						return;
					}

					setTimeout( function () {
						mini_front.youtube_row_background.add( $obj, youtubeId, counter++ );
					}, 100 );

					return;
				}

				var player,
					$container = $obj.prepend( '<div class="mini_wrap-video-bg"><div class="ifr_inner"></div></div>' ).find( '.ifr_inner' );

				player = new YT.Player( $container[0], {
					width: '100%',
					height: '100%',
					videoId: youtubeId,
					playerVars: {
						playlist: youtubeId,
						iv_load_policy: 3,
						enablejsapi: 1,
						disablekb: 1,
						autoplay: 1,
						controls: 0,
						showinfo: 0,
						rel: 0,
						loop: 1
					},
					events: {
						onReady: function ( e ) {
							e.target.mute().setLoop( true );
						}
					}
				} );

				mini_front.youtube_row_background.resize( $obj );

				$( window ).on( 'resize', function () {
					mini_front.youtube_row_background.resize( $obj );
				} );
			},

			resize: function( $obj ) {

				var ratio = 1.77, ifr_w, ifr_h,
					marginLeft, marginTop,
					inner_width = $obj.innerWidth(),
					inner_height = $obj.innerHeight();

				if ( ( inner_width / inner_height ) < ratio ) {
					ifr_w = inner_height * ratio;
					ifr_h = inner_height;
				} else {
					ifr_w = inner_width;
					ifr_h = inner_width * (1 / ratio);
				}

				marginLeft = - Math.round( ( ifr_w - inner_width ) / 2 ) + 'px';
				marginTop = - Math.round( ( ifr_h - inner_height ) / 2 ) + 'px';

				ifr_w += 'px';
				ifr_h += 'px';

				$obj.find( '.mini_wrap-video-bg iframe' ).css( {
					maxWidth: '1000%',
					marginLeft: marginLeft,
					marginTop: marginTop,
					width: ifr_w,
					height: ifr_h
				} );
			}

		},

		google_maps : {

			add: function(){
				$('.mini_google_maps').each( function(){
					var $_this = $( this ),
						_map_data = $( this ).find('.maps').data('map'),
						map_data = $.extend({map_id: $( this ).find('.maps').attr('id')}, _map_data );

					google.maps.event.addDomListener( window, 'load', mini_front.google_maps.initialize( map_data ) );

					$( this ).find('.close').on('click', function(){
						$_this.find('.map_popup_contact_form').toggleClass( "hidden" );
						$_this.find('.show_contact_form').fadeIn('slow');
					});

					$_this.find('.show_contact_form').on('click', function(){
						$_this.find('.map_popup_contact_form').toggleClass( "hidden" );
						$_this.find('.show_contact_form').fadeOut('slow');
					});
				});
			},

			initialize: function(map_data){
				var _scrollwheel = ( 'yes' === map_data.scrollwheel )? false : true;

				var mapProp = {
					center: new google.maps.LatLng( parseFloat(map_data.lat), parseFloat(map_data.lgn) ),
					zoom: parseInt(map_data.zoom) ,
					mapTypeId: google.maps.MapTypeId.ROADMAP,
					scrollwheel: _scrollwheel,
				};
				var map=new google.maps.Map(document.getElementById( map_data.map_id ), mapProp);

				var marker=new google.maps.Marker({
					position: {
						lat: parseFloat(map_data.lat),
						lng: parseFloat(map_data.lgn)
					}
				});

				marker.setMap(map);
			},

			resize: function( el ){

				el.find('.mini_google_maps').each( function(){
					var $_this = $( this ),
						_map_data = $( this ).find('.maps').data('map'),
						map_data = $.extend({map_id: $( this ).find('.maps').attr('id')}, _map_data );

					mini_front.google_maps.initialize( map_data );
				});

			}
		},

		image_gallery : {

			slider: function(){
				/*
				 * OWL slider
				 * For each item OWL slider
				 */
				$( '.mini-owlslider' ).each( function( index ){
					var slider_options =  $( this ).data('slide_options'),
						_autoplay 	= ( 'yes' === slider_options.auto_rotate ) ? true : false,
						_navigation = ( 'yes' === slider_options.navigation ) ? true : false,
						_pagination = ( 'yes' === slider_options.pagination ) ? true : false;

					$( this ).owlCarousel({

						autoPlay		: _autoplay,
						navigation 		: _navigation, // Show next and prev buttons
						pagination		: _pagination,
						slideSpeed 		: 300,
						paginationSpeed : 400,
						singleItem		:true,
						autoHeight		: true,
						items 			: 1

					});

				});
			},

			masonry : function(){
				$('.mini_image_gallery').each(function(){
					var $container = $( this );

					if(( 'yes' === $( this ).data('image_masonry')) ){
						$container.imagesLoaded( function(){
							$container.masonry({
						    	itemSelector : '.item-grid'
							});
						});
					}

				});
			},

			masonry_refresh : function( el ){

				el.find('.mini_image_gallery').each(function(){

					var $container = $( this );
					var load = $container.data('load');

					if(true !== load){
						if(( 'yes' === $( this ).data('image_masonry')) ){
							$container.imagesLoaded( function(){
								$container.masonry({
							    	itemSelector : '.item-grid'
								});
							});
						}

						$container.attr('data-load', true);
					}

				});
			}

		},

		carousel_images : function(){
			/*
			 * Carousel images
			 * For each item Carousel images
			 */
			$( '.mini-carousel-images' ).each( function( index ){

				var options 		= $( this ).data('owl-options'),
					_auto_play 		= ( 'yes' === options.auto_play ) ? true : false,
					_navigation 	= ( 'yes' === options.navigation ) ? true : false,
					_pagination 	= ( 'yes' === options.pagination ) ? true : false,
					_speed 			= options.speed,
					_items 			= options.items,
					_auto_height 	= ( 'yes' === options.auto_height ) ? true : false,
					_progress_bar 	= ( 'yes' === options.progress_bar ) ? true : false,
					_show_thumb 	= ( 'yes' === options.show_thumb ) ? true : false,
					_singleItem 	= false;

				if(_auto_play) _auto_play = parseInt( _speed ) * 1000;

				var progressBar = function(){};
				var moved = function(){};
				var pauseOnDragging = function(){};

				if( true === _auto_height || true === _progress_bar || true === _show_thumb )
					_singleItem = true;

				if( true === _progress_bar )
				{
					var time = _speed; // time in seconds

					var $progressBar,
						$bar,
						$elem,
						isPause,
						tick,
						percentTime;


					progressBar = function( elem ){
						$elem = elem;
						//build progress bar elements
						buildProgressBar();
						//start counting
						start();
					};

					var buildProgressBar =  function(){

						$progressBar = $("<div>",{
							class:"progressBar"
						});

						$bar = $("<div>",{
							class:"bar"
						});

						$progressBar.append($bar).prependTo($elem);

					};

					var start = function() {
						//reset timer
						percentTime = 0;
						isPause = false;
						//run interval every 0.01 second
						tick = setInterval(interval, 10);
					};


					var interval = function() {
						if(isPause === false){
							percentTime += 1 / time;

							$bar.css({
							   width: percentTime+"%"
							});
							//if percentTime is equal or greater than 100

							if(percentTime >= 100){
							  	//slide to next item
							  	$elem.trigger('owl.next');
							}
						}
					};

					pauseOnDragging = function (){
						isPause = true;
					};

					moved =    function(){
						//clear interval
						clearTimeout(tick);
						//start again
						start();
					};
				}

				if( true !== _show_thumb)
				{
					$( this ).owlCarousel({

						autoPlay		: _auto_play,
						navigation 		: _navigation,
						pagination 		: _pagination,
						slideSpeed 		: 300,
						paginationSpeed : 400,
						singleItem		: _singleItem,
						autoHeight		: _auto_height,
						items 			: _items,
						afterInit 		: progressBar,
						afterMove 		: moved,
						startDragging 	: pauseOnDragging

					});
				}
				else
				{
					var sync1 = $( this );
					var sync2 = sync1.next('.mini-sync2');

					var syncPosition =  function(el){
						var current = this.currentItem;

						$(sync2)
							.find(".owl-item")
							.removeClass("synced")
							.eq(current)
							.addClass("synced");

						if($(sync2).data("owlCarousel") !== undefined)
						{
							center(current);
						}
					};

					sync2.on("click", ".owl-item", function(e){
						e.preventDefault();

						var number = $(this).data("owlItem");
						sync1.trigger("owl.goTo",number);
					});

					var center =  function(number){
						var sync2visible = sync2.data("owlCarousel").owl.visibleItems;
						var num = number;
						var found = false;

						for(var i in sync2visible){
							if(num === sync2visible[i])
							{
								found = true;
							}
						}

						if(found===false){
							if( num> sync2visible[sync2visible.length-1] )
							{
								sync2.trigger("owl.goTo", num - sync2visible.length+2);
							}else
							{
								if(num - 1 === -1){
									num = 0;
								}

								sync2.trigger("owl.goTo", num);
							}
						}
						else if(num === sync2visible[sync2visible.length-1])
						{
							sync2.trigger("owl.goTo", sync2visible[1]);
						}
						else if(num === sync2visible[0])
						{
							sync2.trigger("owl.goTo", num-1);
						}

					};

					sync1.owlCarousel({
						autoPlay				: _auto_play,
						singleItem 				: true,
						slideSpeed 				: 1000,
						navigation				: _navigation,
						pagination				: _pagination,
						afterAction 			: syncPosition,
						responsiveRefreshRate 	: 200,
						autoHeight				: _auto_height,
						afterInit 				: progressBar,
						afterMove 				: moved,
						startDragging 			: pauseOnDragging
					});

					sync2.owlCarousel({
						items 				: 10,
						itemsDesktop      	: [1199, 8],
						itemsDesktopSmall   : [979, 6],
						itemsTablet       	: [768, 4],
						itemsMobile       	: [479, 2],
						pagination			: _pagination,
						responsiveRefreshRate : 100,
						afterInit : function(el){
							el.find(".owl-item").eq(0).addClass("synced");
						}
					});
				}

			});
		},

		carousel_post : function(){

			$( '.mini-owl-post-carousel' ).each( function( index ){
				var options = $( this ).data('owl-options');
				var	_auto_play 			= ( 'yes' === options.autoplay ) ? true : false,
					_navigation 		= ( 'yes' === options.navigation ) ? true : false,
					_pagination 		= ( 'yes' === options.pagination ) ? true : false,
					_speed 				= options.speed,
					_items 				= options.items,
					_auto_height 		= ( 'yes' === options.autoheight ) ? true : false,
					_singleItem 		= false;

				if(_auto_height === true) _singleItem = true;

				if(_auto_play) _auto_play = parseInt( _speed ) * 1000;

				$( this ).owlCarousel({

					autoPlay		: _auto_play,
					navigation 		: _navigation,
					pagination 		: _pagination,
					slideSpeed 		: 300,
					paginationSpeed : 400,
					singleItem		: _singleItem,
					autoHeight		: _auto_height,
					items 			: _items,

				});

			});
		},

		countdown_timer : function(){

			$( '.mini-countdown-timer' ).each( function( index ){
				var countdown_data = $( this ).data('countdown');

				$(this).countdown(countdown_data.date, function(event) {
			    	$(this).html(event.strftime(countdown_data.template));
			    });

			});
		},

		piechar : {

			init: function(){

				$('.mini_piechart').each(function(index){

					$( this ).viewportChecker({

						callbackFunction: function( elm ){

							mini_front.piechar.load( elm );

						},

						classToAdd: 'mini-pc-loaded'

					});

				});
			},

			load : function( el ){

				if( el.parent('div').width() < 10 )
					return 0;

				var _size 		= el.data( 'size' ),
					_linecap 	= ( 'yes' === el.data( 'linecap' )) ? 'round' : 'square',
					_barColor 	= el.data( 'barcolor' ),
					_trackColor = el.data( 'trackcolor' ),
					_autowidth 	= el.data( 'autowidth' );

				if('yes' === _autowidth){
					_size = el.parent('div').width();
					el.data( 'size', _size );
					el.find('.percent').css({ 'line-height' : _size + 'px' });
				}

				//Fix percent middle
				var percent_width = el.find('.percent').width() + el.find('.percent:after').width();
				var percent_height = el.find('.percent').height();

				el.easyPieChart({

					barColor: _barColor,
					trackColor: _trackColor,
					lineCap: _linecap,
					easing: 'easeOutBounce',

					onStep: function(from, to, percent) {

						$(this.el).find('.percent').text(Math.round(percent));
						$(this.el).find('.percent').show();
						$( this.el ).css({'width': _size, 'height': _size});

					},

					scaleLength: 0,
					lineWidth: 12,
					size: _size,

				});

			},

			update: function( el ){

				el.find('.mini_piechart').each( function(){

					mini_front.piechar.load( $( this ) );

				});

			}

		},

		progress_bar : {

			run: function(){

				// Hide the label at start
			    $('.mini-progress-bar .mini-ui-progress .ui-label').hide();
			    // Set initial value
			    $('.mini-progress-bar .mini-ui-progress').css('width', '7%');

			    // Simulate some progress
			    $('.mini-progress-bar .mini-ui-progress').each(function(){

			  		this.per = $(this).data('value');

			  		$( this ).viewportChecker({

						callbackFunction: function( el ){

							var pbw = el.parents('.mini_progress_bars'),
								animate = ('yes' === pbw.data('animate')) ? true: false;

							if(true === animate){
								el.animateProgress( el.get(0).per, function() {

									$(this).animateProgress(this.per, function() {
										$('.mini-progress-bar .ui-progress').each(function(){
									    	$(this).animateProgress(this.per);
										});
									});

								});
							}else{
								el.width(el.data('value')+'%');
								el.find('.ui-label').show('fast');
							}

						},
						classToAdd : 'mini-pb-loaded'
					});

			    });
			},

			update: function( el ){

				el.find('.mini-progress-bar .mini-ui-progress .ui-label').hide();
			    el.find('.mini-progress-bar .mini-ui-progress').css('width', '1%');

			    el.find('.mini-progress-bar .mini-ui-progress').each(function(){

				    $(this).animateProgress( $(this).data('value'), function() {
						$('.mini-progress-bar .ui-progress').each(function(){
					    	$(this).animateProgress( this.per );
						});
					});
				});

			}
		},

		flipbox_fixed_height : function(){

			$('.mini-flipbox').each(function(index){

				var parent = $(this).parent('div'),
					parent_width = parent.width(),
					img = $(this).find('img'),
					real_img_width = ( img.length > 0 ) ? img[0].naturalWidth : parent_width,
					real_img_height = ( img.length > 0 ) ? img[0].naturalHeight : parent.height(),
					w, h;

				w = parent_width;
				h = w * real_img_height / real_img_width;

				if( parent_width < real_img_width ){
					$( this ).width(w).height(h);
					$(this).find('.flipper,.front,.back').width(w).height(h);
				}else{
					$( this ).width(real_img_width).height(real_img_height);
					$(this).find('.flipper,.front,.back').width(real_img_width).height(real_img_height);
				}
			});
		},

		progress_bar_fixed_height : function(){

			$('.mini_progress_bars').each(function(){
				var $_this = $( this ),
					_style = ( '' !== $( this ).data('style') ) ? $( this ).data('style') : 1,
					progress_item = $( this ).find('.progress-item');

				if(_style <= 2){
					progress_item.find('.mini-progress-bar').each(function(){
						var height_progress_bar,
							borderWidth = $(this).css("border-bottom-width");

						if(_style == 1) height_progress_bar = 25;
						if(_style == 2)	height_progress_bar = 38;

						$( this ).height(height_progress_bar);
						$( this ).children('.mini-ui-progress').height(height_progress_bar);

					});
				}

			});
		},

		ajax_action : function(){

			$('.mini_facebook_recent_post').each(function(){
				var $_this = $( this ),
					session_id = $( this ).data( 'session' ),
					data_send = {
						action: 'mini_facebook_recent_post',
						session_id: session_id
					};

				$.ajax({
					url: mini_script_data.ajax_url,
					method: 'POST',
					dataType: 'json',
					data: data_send,
					success: function( response_data ){
						$_this.find('ul').html(response_data.html).before(response_data.header_html);
					}
				});

			});

			/*
			 * instagram feed images
			 * Send data to shortcode
			 */
			$('.mini_wrap_instagram').each(function(index){
				var $_this = $( this ),
					session_id = $( this ).data( 'session' ),
					data_send = {
						action: 'mini_instagrams_feed',
						session_id: session_id
					};

				$.ajax({
					url: mini_script_data.ajax_url,
					method: 'POST',
					dataType: 'json',
					data: data_send,
					success: function( response_data ){
						$_this.find('ul').html(response_data.html);
					}
				});
			});

			/*
			 * Twitter feed sider
			 * For each item Twitter feed sider
			 */
			$( '.mini_twitter_feed' ).each( function( index ) {

				var $_this = $( this ),
					session_id = $( this ).data( 'session' ),
					atts_data = {
						action: 'mini_twitter_timeline',
						session_id: session_id
					};

				var owl_option = $( this ).data( 'owl_option' );

				$.ajax({
					url: mini_script_data.ajax_url,
					method: 'POST',
					dataType: 'json',
					data: atts_data,
					success: function( response_data ){
						var display_style = $_this.data( 'display_style' );

						$_this.find('.result_twitter_feed').html( response_data.html );

						$_this.find('.result_twitter_feed').before('<div class="button_follow_wrap">'+response_data.header_data+'</div>');

						var _navigation = ( 'yes' === owl_option.show_navigation )? true : false,
							_pagination = ( 'yes' === owl_option.show_pagination )? true : false,
							_autoHeight = ( 'yes' === owl_option.auto_height )? true : false;

						if( 2 === display_style ){
							$_this.find('.mini-tweet-owl').owlCarousel({
								navigation 		: _navigation,
								pagination 		: _pagination,
								slideSpeed 		: 300,
								paginationSpeed : 400,
								singleItem		: true,
								items 			: 1,
								autoHeight		: _autoHeight
							});
						}
					}
				});

			});
		},

		mini_end : {}

	};
}(jQuery));

jQuery( document ).ready(function($){ mini_front.init($); });

/*
Plugin: jQuery Parallax
Version 1.1.3
Author: Ian Lunn
Twitter: @IanLunn
Author URL: http://www.ianlunn.co.uk/
Plugin URL: http://www.ianlunn.co.uk/plugins/jquery-parallax/

Dual licensed under the MIT and GPL licenses:
http://www.opensource.org/licenses/mit-license.php
http://www.gnu.org/licenses/gpl.html
*/

(function( $ ){
	var $window = $(window);
	var windowHeight = $window.height();

	$window.resize(function () {
		windowHeight = $window.height();
	});

	$.fn.parallax = function(xpos, speedFactor, outerHeight) {
		var $this = $(this);
		var getHeight;
		var firstTop;
		var paddingTop = 0;

		//get the starting position of each element to have parallax applied to it
		$this.each(function(){
		    firstTop = $this.offset().top;
		});

		if (outerHeight) {
			getHeight = function(jqo) {
				return jqo.outerHeight(true);
			};
		} else {
			getHeight = function(jqo) {
				return jqo.height();
			};
		}

		// setup defaults if arguments aren't specified
		if (arguments.length < 1 || xpos === null) xpos = "50%";
		if (arguments.length < 2 || speedFactor === null) speedFactor = 0.1;
		if (arguments.length < 3 || outerHeight === null) outerHeight = true;

		// function to be called whenever the window is scrolled or resized
		function update(){
			var pos = $window.scrollTop();

			$this.each(function(){
				var $element = $(this);
				var top = $element.offset().top;
				var height = getHeight($element);

				// Check if totally above or totally below viewport
				if (top + height < pos || top > pos + windowHeight) {
					return;
				}

				$this.css('backgroundPosition', xpos + " " + Math.round((firstTop - pos) * speedFactor) + "px");
			});
		}

		$window.bind('scroll', update).resize(update);
		update();
	};
})(jQuery);
