<?php

if( $code = rawurldecode( base64_decode( $atts['code'] ) ) )
{
	echo do_shortcode( $code );
}
else
{
	echo 'Mini Raw Code: Error content structure';	
}
