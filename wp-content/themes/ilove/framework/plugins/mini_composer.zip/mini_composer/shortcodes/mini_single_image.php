<?php
/*----------------------------------
 * Single image shortcode
 *--------------------------------*/

$output = $image = $image_title = $image_source = $image_external_link = $image_size = $image_size_el = $caption = $image_align = $on_click_action = $custom_link = $class =  $image_full = $html = '';

extract( $atts );

$default_src = mini_asset_url('images/get_start.jpg');

$image_source = $atts['image_source'];

$element_attributes = array();
$image_attributes = array();

$css_classes = array(
	'mini_shortcode',
	'mini_single_image',
	$atts['class'],
	isset($atts['css'])?$atts['css']:''
);

$image_url = '';
$image_id = $atts['image'];
$image_size = $atts['image_size'];
$on_click_action = $atts['on_click_action'];
$data_lightbox = '';

if( $image_source == 'external_link' )
{

	$image_full = $atts['image_external_link'];
	$image_url = $image_full;
	$size = $atts['image_size_el'];

	if( !empty( $image_url ) )
		$image_attributes[] = 'src="'.$image_url.'"';
	else
		$image_attributes[] = 'src="'.$default_src.'"';

	if( empty( $image_full ) )
		$image_full = $default_src;

	if ( preg_match( '/(\d+)x(\d+)/', $size, $matches ) ) {
		$width = $matches[1];
		$height = $matches[2];
		$image_attributes[] = 'width="'.$width.'"';
		$image_attributes[] = 'height="'.$height.'"';
	}
}
else
{

	if( $image_source == 'media_library' )
	{
		$image_id = preg_replace( '/[^\d]/', '', $image_id );
	}
	else
	{
		$post_id = get_the_ID();
		if ( $post_id && has_post_thumbnail( $post_id ) ) {
			$image_id = get_post_thumbnail_id( $post_id );
		} else {
			$image_id = 0;
		}
	}

	$image_full_width = wp_get_attachment_image_src( $image_id, 'full' );
	$image_full = $image_full_width[0];
	$image_data = wp_get_attachment_image_src( $image_id, $image_size );
	$image_url = $image_data[0];

	if( !empty( $image_url ) )
	{
		$image_attributes[] = 'src="'.$image_url.'"';
	}
	else
	{
		$image_attributes[] = 'src="'.$default_src.'"';
		$image_attributes[] = 'class="mini_image_empty"';
	}


	if( empty( $image_full ) )
		$image_full = $default_src;

}

if(!empty($caption)){
	$image_attributes[] = 'alt="'. trim(esc_attr($caption)) .'"';
}

if( $on_click_action == 'lightbox' )
{
	$data_lightbox = 'rel="prettyPhoto"';
	wp_enqueue_script('mini-prettyPhoto');
	wp_enqueue_style( 'mini-prettyPhoto' );
}
else if( $on_click_action == 'open_custom_link' )
{
	$image_full = $atts['custom_link'];
}


$css_class = implode(' ', $css_classes);
$element_attributes[] = 'class="' . esc_attr( trim( $css_class ) ) . '"';
if(!empty($image_align)){
	$element_attributes[] = 'style="text-align: ' . esc_attr( $image_align ) . ';"';
}

if( !empty($on_click_action) ){
	$html .= '<a '.$data_lightbox.' href="'.esc_attr($image_full).'" title="'. esc_attr($caption) .'"><img '. implode( ' ', $image_attributes ) .' /></a>';
}else{
	$html .= '<img '. implode( ' ', $image_attributes ) .' />';
}

if(!empty($caption)){
	$html .= '<p>'. esc_html($caption) .'</p>';
}

$output .= '<div ' . implode( ' ', $element_attributes ) . '>';
$output .= $html;
$output .= '</div>';


echo $output;
