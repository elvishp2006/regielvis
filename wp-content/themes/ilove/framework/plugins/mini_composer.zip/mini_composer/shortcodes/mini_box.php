<?php

$custom_class = '';

extract($atts);

$element_attributes = array();
$el_classes = array(
	'mini_box_wrap',
	$custom_class
);

$css = isset($css)?$css:'';

$element_attributes[] = 'class="'. esc_attr(implode(' ', $el_classes)) .'"';

echo '<div '. implode(' ', $element_attributes ) .'>';

if( $data = json_decode( base64_decode( $atts['data'] ) ) )
{
	echo mini_loop_box( $data );
}
else
{
	echo 'Mini Box: Error content structure';
}

echo '</div>';
