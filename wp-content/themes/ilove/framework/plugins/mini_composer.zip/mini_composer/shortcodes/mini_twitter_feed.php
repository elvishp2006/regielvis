<?php

$session_id = mini_random_string(10);
$_SESSION[$session_id] = json_encode( $atts );

$output = $output_title = $show_navigation = $show_pagination = $auto_height = '';

extract( $atts );

$element_attribute = array();

$el_classes = array(
	'mini_shortcode',
	'mini_wrap_twitter',
	'mini_twitter_feed',
	'mini_twitter_style-' . $display_style,
	$wrap_class,
	$custom_class,
	isset( $atts[ 'css' ] )? $atts[ 'css' ] : ''
);

$atts_data = array(
	'show_navigation' => $show_navigation,
	'show_pagination' => $show_pagination,
	'auto_height' => $auto_height
);

$element_attribute[] = 'id="mini_twitter_feed_'. mini_random_string( 5 ) .'"';
$element_attribute[] = 'class="'. esc_attr( implode( ' ', $el_classes ) ) .'"';
$element_attribute[] = 'data-session="'. esc_attr( $session_id ) .'"';
$element_attribute[] = 'data-owl_option="'. esc_attr( json_encode($atts_data) ) .'"';
$element_attribute[] = 'data-display_style="'. esc_attr( $display_style ) .'"';

if( !empty( $title ) ){
	$output_title = '<h3 class="mini-widget-title">'. esc_html( $title ) .'</h3>';
}

$max_height = !empty($max_height) ? intval($max_height) . 'px;': 'none;';

$output .= '<div '. trim( implode(' ', $element_attribute ) ) .'>'. $output_title .'<div class="result_twitter_feed" style="max-height: '. $max_height .'"><span>Loading...</span></div></div>';

echo $output;
