<?php

$width = '';
$output = '';

extract($atts);

$attributes = array();
$classes = array(
	'mini_column',
	$atts['col_class'],
	isset($atts['css'])?$atts['css']:'',
	@mini_ColDecimalToClass($width),
	isset($css) ? $css: ''
);

$attributes[] = 'class="' . esc_attr( trim( implode(' ', $classes) ) ) . '"';

$col_container_class = !empty( $atts['col_container_class'] ) ? ' '.$atts['col_container_class'] : '';

$output = '<div ' . implode( ' ', $attributes ) . '>'
		. '<div class="mini-col-container'.esc_attr( $col_container_class ).'">'
		. do_shortcode( str_replace('mini_column#', 'mini_column', $content ) )
		. '</div>'
		. '</div>';

echo $output;
