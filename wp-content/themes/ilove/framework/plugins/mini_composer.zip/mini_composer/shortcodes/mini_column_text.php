<?php

$output = '';
$class = isset( $atts[ 'class' ] ) ? $atts[ 'class' ].' mini_text_block' : 'mini_text_block';

$content = apply_filters('mini_cloumn_text', $content );

$output .= '<div class="'.esc_attr( $class ).'">';
$output .= do_shortcode( $content );
$output .= '</div>';

echo $output;
