<?php
/*
 * Google maps shortcode template
 */
global $mini;

$output = $title = $wrap_class = $contact_form = $disable_wheel_mouse = '';
$map_height = 250;
$contact_area_position = 'left';
$google_maps_info = array();

extract($atts);

wp_enqueue_script( 'mini-google-maps' );

$element_attributes = array();
$map_attributes     = array();

$css_classes = array(
    'mini_google_maps',
    'mini_shortcode',
    $wrap_class,
    $custom_class
);

$element_attributes[] = 'class="'. esc_attr( implode( ' ', $css_classes ) ) .'"';

$google_maps_info = explode('|', $map_location);
$map_data_json = json_encode(
    array(
        'lat'   => !empty( $google_maps_info[0] ) ? $google_maps_info[0] : '21.034856055581216',
        'lgn'   => isset( $google_maps_info[1] ) ? $google_maps_info[1] : '105.78365346708983',
        'zoom'  => isset( $google_maps_info[2] ) ? $google_maps_info[2] : '9',
        'scrollwheel' => strtolower($disable_wheel_mouse)
    )
);

if(!empty( $title )){
    $output .= '<h3 class="map_title">'. esc_html( $title ) .'</h3>';
}

//Contact form on maps
if( !empty($show_ocf) && 'yes' === $show_ocf ){
    if(!empty( $contact_form_sc )){
        $contact_form = '<div class="map_popup_contact_form '. $contact_area_position .'">';
        $contact_form .= '<a class="close" href="javascript:;"><i class="sl-close"></i></a>';
        $contact_form .= $mini->do_shortcode( base64_decode($contact_form_sc) );
        $contact_form .= '</div>';
        $contact_form .= '<a class="show_contact_form" href="javascript:;"><i class="fa fa-bars"></i></a>';
    }
}

$map_attributes[] = 'id="'. esc_attr($custom_class) .'"';
$map_attributes[] = 'class="maps"';
$map_attributes[] = 'data-map="'. esc_attr( $map_data_json ) .'"';

if(!empty($map_height))
    $map_attributes[] = 'style="height: '. esc_attr($map_height) .'px"';

$output .= '<div '. implode( ' ', $element_attributes ) .'>'. $contact_form .'<div '. implode(' ', $map_attributes) .'></div></div>';

echo $output;
