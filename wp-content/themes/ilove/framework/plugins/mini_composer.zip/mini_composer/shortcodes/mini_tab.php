<?php
/**
 * mini_tab shortcode
 **/
global $mini;
$tab_id = $title = '';
extract( $atts );

$css_class = array( 'mini_tab', 'ui-tabs-panel', 'mini_ui-tabs-hide', 'mini_clearfix' );

if( empty( $tab_id ) || (strpos( $tab_id,'%time%' ))){
	$tab_id = sanitize_title( $title );
}else{
	$tab_id = esc_attr( $tab_id );
}

if( isset( $class ) )
	array_push( $css_class, $class );

$output = '<div id="' . $tab_id . '" class="' . esc_attr( implode( ' ', $css_class ) ) . '">'.
		( ( '' === trim( $content ) ) 
		? __( 'Empty tab. Edit page to add content here.', 'MiniPageBuider' ) 
		: do_shortcode( str_replace('mini_tab#', 'mini_tab', $content ) ) ).
	'</div>';

echo $output;