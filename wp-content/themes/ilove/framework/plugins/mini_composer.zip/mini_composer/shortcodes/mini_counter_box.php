<?php
$output = $custom_css = $_before_number = $_after_number = '';

extract( $atts );

$style = (!empty($atts['style'])) ? $atts['style'] : 1;

$element_atttribute = array();

$el_classess = array(
	'mini_shortcode',
	'mini_counter_box',
	'mini-box-counter',
	'mini-box-counter-'.$style,
	$custom_class,
	$wrap_class
);

$element_atttribute[] = 'class="'. esc_attr( implode(' ', $el_classess ) ) .'"';

$label = (!empty($label)) ? '<h4>'. esc_html($label) .'</h4>' : '';
$icon = !empty($icon)? $icon: 'fa-leaf';

if(isset($style) && $style != 1){
	$icon = (!empty($icon)) ? '<i class="'. esc_html($icon).' element-icon"></i>' : '';
}else{
	$icon = '';
}

if(!empty($label_above) && 'yes' === $label_above){
	$_before_number = $icon . $label;
}else{
	$_before_number = $icon;
	$_after_number = $label;
}

$output .= '<div '. implode(' ', $element_atttribute) .'>
		'. $_before_number .'
		<span class="counterup">'. esc_html($number) .'</span>
		'. $_after_number .'
	</div>
';

wp_enqueue_script('mini-waypoints-min');
wp_enqueue_script('mini-counter-up');

echo $output;
