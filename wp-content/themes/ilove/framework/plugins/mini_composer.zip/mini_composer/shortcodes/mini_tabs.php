<?php

$title = $interval = $open_mouseover = $class = '';
extract( $atts );

$tabs_option = array(
	'open-on-mouseover' => $open_mouseover,
	'tab-active' => $active_section,
	'effect-option' => $effect_option,
);

$tabs_option_data = array();
foreach( $tabs_option as $name => $value ){
	array_push( $tabs_option_data, 'data-'.esc_attr( $name ).'="'.esc_attr( $value ).'"' );
}

$css_class = array( 'mini_tabs', 'group' );

if( 'vertical_tabs' === $type )
{
	array_push( $css_class, 'mini_vertical_tabs' );

	if( $vertical_tabs_position == 'right' )
		array_push( $css_class, 'tabs_right' );

	$tab_nav_class = '';

}else{
	$tab_nav_class = 'mini_tabs_nav';
}

if( isset( $css ) )
	array_push( $css_class, $css );

if( isset( $class ) )
	array_push( $css_class, $class );


echo '<div class="' . esc_attr( implode( ' ', $css_class ) ) . '" '.implode( ' ', $tabs_option_data ).'>';
echo '<div class="mini_wrapper ui-tabs mini_clearfix">';
echo '<ul class="'. $tab_nav_class .' ui-tabs-nav mini_clearfix">';

$content = preg_replace_callback( '/mini_tab\s([^\]\#]+)/i', function ( $matches ){

	if( !empty( $matches[0] ) )
	{

		$tab_atts = shortcode_parse_atts( $matches[0] );

		$title = '';
		if ( isset( $tab_atts['title'] ) )
			$title = $tab_atts['title'];

		if( isset( $tab_atts['icon'] ) )
			$title = '<i class="'.$tab_atts['icon'].'"></i> '.$title;

		echo '<li><a href="#'.$tab_atts['tab_id'].'">'.$title.'</textarea></a></li>';

	}

	return $matches[0];

} , $content );

echo '</ul>'.do_shortcode( str_replace('mini_tabs#', 'mini_tabs', $content ) ) .'</div></div>';
