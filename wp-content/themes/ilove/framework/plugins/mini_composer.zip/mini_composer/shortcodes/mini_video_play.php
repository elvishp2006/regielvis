<?php

$output = $title = $description = $video_info = '';
$video_height = '250';
$check_video = 'true';

extract( $atts );

if(!empty($video_width)){
	$video_height = intval($video_width)/1.77;
}

$video_link = (!empty($video_link))?$video_link:'https://www.youtube.com/watch?v=iNJdPyoqt8U'; //default video

if((preg_match('/youtu\.be/i', $video_link) || preg_match('/youtube\.com\/watch/i', $video_link)) ){
	$check_video = 'true';
	wp_enqueue_script('mini-youtube-api');
}else{
	if( (preg_match('/vimeo\.com/i', $video_link)) ){
		$check_video = 'true';
		wp_enqueue_script('mini-vimeo-api');
	}else{
		$check_video = 'false';
	}
}


//Check youtube video url
$pattern = '~
	^(?:https?://)?              # Optional protocol
	 (?:www\.)?                  # Optional subdomain
	 (?:youtube\.com|youtu\.be)  # Mandatory domain name
	 /watch\?v=([^&]+)           # URI with video id as capture group 1
	 ~x';

$has_match = preg_match($pattern, $video_link, $matches);

$video_attributes = array();

$video_classes = array(
	'mini_shortcode',
	'mini_video_play',
	'mini_video_wrapper',
	$wrap_class,
	isset($atts['css'])?$atts['css']:''
);

$video_attributes[] = 'class="'. esc_attr( implode(' ', $video_classes) ) .'"';

$video_attributes[] = 'data-video="'. esc_attr( $video_link ) .'"';
$video_attributes[] = 'data-width="'. esc_attr( $video_width ) .'"';
$video_attributes[] = 'data-height="'. esc_attr($video_height) .'"';
$video_attributes[] = 'data-fullwidth="'. esc_attr( $full_width ) .'"';
$video_attributes[] = 'data-autoplay="'. esc_attr( $auto_play ) .'"';

if( !empty($title) ) $video_info .= '<h3>'. $title .'</h3>';
if( !empty($description) ) $video_info .= '<p>'. base64_decode($description) .'</p>';

$output .= '<div '. implode(' ', $video_attributes) .'>
	<div class="video-info">'. $video_info .'</div>
</div>';

wp_enqueue_script( 'mini-video-play' );

if( $check_video === 'true' ){
	echo $output;
}else{
	echo __('MiniComposer error: Video format url incorrect', 'mini_composer');
}
