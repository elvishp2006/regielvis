<?php

$session_id = mini_random_string(10);
$_SESSION[$session_id] = json_encode( $atts );

$output = $wrap_class = '';
$count = 0;

extract( $atts );

$element_attributes = array();
$css_classes = array(
	'mini_shortcode',
	'mini_wrap_instagram',
	$wrap_class,
	isset($atts['css'])?$atts['css']:''
);

if ( !empty( $columns_style ) ) {
	$css_classes[] = 'mini_ins_col_' . $columns_style;
}

$css_class = implode( ' ', $css_classes );

$element_attributes[] = 'class="' . esc_attr( $css_class ) . '"';

$image_size = (!empty($image_size)) ? $image_size : 'thumbnail';
$number_show = (!empty( $number_show )) ? $number_show : 8;

$element_attributes[] = 'data-session="'. esc_attr( $session_id ) .'"';

$output .= '<div '. implode( ' ', $element_attributes ) .'>';

if(!empty($title)){
	$output .= '<h3 class="mini-widget-title">'. esc_html($title) .'</h3>';
}

$output .= '<ul>';

$mark_class = 'ins_mark_'.$image_size;
for($i=1; $i<=$number_show; $i++){
	switch ($i%$columns_style) {
		case '1':
			$li_class = 'el-start';
			break;
		case '0':
			$li_class = 'el-end';
			break;
		default:
			$li_class = '';
			break;
	}
	$output .= '<li class="'. esc_attr($mark_class .' '. $li_class) .'"></li>';
}

$output .= '</ul>';

$output .= '</div>';

echo $output;
