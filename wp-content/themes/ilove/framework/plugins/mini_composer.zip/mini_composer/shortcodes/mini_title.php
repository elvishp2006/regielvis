<?php

$output = '';
$type = 'h1';

extract( $atts );

$attributes = array();
$classes = array(
	'mini_title',
	$atts['class']
);

if( !empty( $atts['type'] ) )
	$type = esc_attr( $atts['type'] );
else $type = 'h1';

if( !empty( $atts['css'] ) )
	$classes[] = $atts['css'];

$attributes[] = 'class="' . esc_attr( implode(' ', $classes) ) . '"';

$output = '<'.$type.' '.implode( ' ', $attributes ) . '>'
		. do_shortcode( urldecode( base64_decode( $atts['text'] ) ) )
		. '</'.$type.'>';

if( $atts['title_wrap'] == 'yes' )
{
	$output = '<div class="'.esc_attr( $atts['title_wrap_class'] ).'">'.$output.'</div>';
}

echo $output;
