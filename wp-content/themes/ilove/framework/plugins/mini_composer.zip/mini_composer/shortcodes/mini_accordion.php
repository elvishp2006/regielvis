<?php
/**
 * mini_accordion shortcode
 **/
global $mini; 
extract( $atts );

$output = '';

$element_attributes = array();

$css_classes = array(
	'mini_accordion_wrapper'
);

if( isset( $class ) )
	array_push( $css_classes, $class );

if( $atts['open_all'] == 'yes' )
	$element_attributes[] = 'data-allowOpenAll="true"';
	
$css_class = implode(' ', $css_classes);
$element_attributes[] = 'class="' . esc_attr( trim( $css_class ) ) . '"';

$output .= '<div ' . implode( ' ', $element_attributes ) . '>';
$output .= do_shortcode( str_replace( 'mini_accordion#', 'mini_accordion', $content ) );
$output .= '</div>';

echo $output;