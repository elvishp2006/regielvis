<?php
/**
*
*	Mini Composer
*	(c) MiniComposer.com
*
*/

if(!defined('ABSPATH')) {
	header('HTTP/1.0 403 Forbidden');
	exit;
}

?>

<div id="mini-sections-manager">
	<div class="mgs-select-section">
		<h1 class="mgs-t01" id="mini-profile-title">
			<?php _e('Profile: ', 'mini_composer'); ?>
			<span class="msg-profile-label-display"></span>
			<a href="#" id="mini-add-new-section"><?php _e('Add New Section', 'mini_composer'); ?></a>
		</h1>
		<select class="filter-by-category">
			<option value=""> -- <?php _e('Filter by Category', 'mini_composer'); ?> -- </option>
		</select>
		<input type="search" class="filter-by-name" placeholder="<?php _e('Search by name', 'mini_composer'); ?>" />
		<div id="mini-section-settings"><i class="sl-settings"></i></div>
		<div data-label="<?php _e('Edit this section', 'mini_composer'); ?>" class="mgs-select-wrp layout-grid">
			<?php _e('Loading', 'mini_composer'); ?>...
		</div>
	</div>
</div>
<div id="poststuff" style="display:none;" class="mini-sections-manager">
	<button class="button button-large mini-backtoList">
		<i class="sl-action-undo"></i> <?php _e('Back to Sections List', 'mini_composer'); ?>
	</button>
    <div id="post-body" class="metabox-holder columns-2">
        <div id="post-body-content" style="position: relative;">
            <div id="postdivrich" class="postarea wp-editor-expand">

				<?php wp_editor( '', 'content' ); ?> 

            </div>
        </div>
        <!-- /post-body-content -->

        <div id="postbox-container-1" class="postbox-container mini-section-meta">
            <div id="submitdiv" class="postbox ">
                <h3 class="hndle"><span><?php _e('Section Settings', 'mini_composer'); ?></span></h3>
                <div class="inside">
	                <form id="mini-section-form">
		                <input type="submit" class="forceHide" />
	                    <div class="submitbox">
	                        <div class="misc-pub-section" id="mini-section-title">
		                        <label><?php _e('Title', 'mini_composer'); ?>:</label>
		                        <input id="title" type="text" placeholder="Enter new Title" class="inp-wa0" />
	                            <div class="clear"></div>
	                        </div>
	                        <div class="misc-pub-section" id="mini-section-category">
		                        <label><?php _e('Categories', 'mini_composer'); ?>:</label>
		                        <input type="text" placeholder="Enter new category name" class="inp-wa0" />
	                            <div class="mgs-tips pos-right">
									<ul></ul>
								</div>
	                            <div class="clear"></div>
	                        </div>
	                        <div class="misc-pub-section last" id="mini-section-screenshot">
		                       	<div class="msc-body mgc-cn-screenshot"></div>
	                            <div class="clear"></div>
	                        </div>
	
	                        <div id="major-publishing-actions">
	                            <div id="delete-action">
	                                <a class="submitdelete deletion" href="#">
		                                <?php _e('Delete This Section', 'mini_composer'); ?>
		                            </a>
	                           	</div>
	                            <div id="publishing-action">
	                                <button class="button button-primary button-large">
	                                	<i class="fa fa-check"></i> <?php _e('Update', 'mini_composer'); ?>
	                                </button>
	                            </div>
	                            <input type="hidden" id="msg-activated-section-id" />
	                            <div class="clear"></div>
	                        </div>
	                    </div>
	                </form>
                </div>
            </div>
            <div id="mini-save-success">
	            <div class="mss-wrp">
		            <i class="fa fa-check"></i>
		            <h3><?php _e('Saved Successfully', 'mini_composer'); ?></h3>
		            <span><?php _e('The data is saved in real-time and you do not need to reload the browser even in other tabs', 'mini_composer'); ?></span>
		            <button class="button button-large mini-backtoList"><i class="sl-action-undo"></i>  Back to List</button>
		              &nbsp; 
		            <button class="button button-large button-primary" id="ssCountDown">Ok</button>
	            </div>
            </div>
        </div>

    </div>
    <!-- /post-body -->
    <br class="clear">
</div>

<script type="text/javascript">
	
	
function mini_sections_load(){
	
	var $ = jQuery;
	
	$('.msg-profile-label-display').html( mini.cfg.profile );
	
	/* Build Sections List */
	$('#mini-sections-manager div.mgs-select-wrp').html( mini.ui.gsections.load( '<?php _e('Edit this section', 'mini_composer'); ?>', 0, mini.cfg.sectionsPerpage ) ).find('.mgs-scale-min').removeClass('mgs-scale-min');
	
	var cats = mini.ui.gsections.get_cats(), 
		ul = $('#mini-section-category .mgs-tips ul'),
		catfilter = $('#mini-sections-manager select.filter-by-category');
	
	ul.html('');
	catfilter.find('option').remove();
	catfilter.append('<option value=""> -- <?php _e('Filter by Category', 'mini_composer'); ?> -- </option>');
		
	if( Object.keys(cats).length > 0 ){
		for( var i in cats ){
			ul.append('<li data-name="'+i+'"><i class="fa fa-caret-right"></i> '+i+' ('+cats[i]+')</li>');
			catfilter.append('<option value="'+i+'">'+i+' ('+cats[i]+')</option>');
		}
	}else{
		ul.append('<li data-name="first category"><i class="fa fa-caret-right"></i> <?php _e('First Category', 'mini_composer'); ?></li><li></li>');
	}
	
	$('#mini-sections-manager .load-more').off('mouseover').on( 'mouseover', mini_loadmore_sections );
	
	$('#mini-section-category .mgs-tips li').off('click').on( 'click', function( e ){
			
		var input = $( '#mini-section-category input.inp-wa0' ),
			value = input.val().toString().trim(),
			data = $(this).data('name'),
			valz = value.split(',');
		
		for( var i in valz )
			valz[i] = valz[i].trim();
		
		if( value == '' )
			input.val( data );
		else if( $.inArray( data, valz ) == -1 )
			input.val( value+', '+data );
				
	} );
	
}

function mini_loadmore_sections( e ){
						
	var $ = jQuery,
		label = $(this).data('label'),
		from = $(this).data('from'),
		to = $(this).data('to');

	$(this).after( mini.ui.gsections.load( label, from, to ) ).remove();
	
	$(this).closest('.mgs-select-section').find('.filter-by-category').trigger('change');
	
	setTimeout(function(){
			$('.mgs-scale-min').removeClass('mgs-scale-min');
	}, 100 );
		
	$('#mini-sections-manager .load-more').off( 'mouseover').on( 'mouseover', mini_loadmore_sections );

}

function switchToEdit( sid ){
	
	var stack = mini.backbone.stack.get('miniGlobalSections'), $ = jQuery;
	
	$('.section-manager-popup').remove();
	
	if( sid == 'new' ){
		var sobj = {
			title : 'New Section',
			category : 'New Category',
			screenshot : '',
			data : '',
			id : parseInt( Math.random()*1000000 )
		}
	}else{
		
		for( var i in stack ){
			if( stack[i].id == sid )
				var sobj = stack[i];	
		}
		
	}
	
	if( sobj === undefined )
		return;
	
	$('#mini-save-success').hide();
		
	/*Defined sid*/
	$('#poststuff').data({ sid : sid });
	
	$('#mini-sections-manager').hide();
	$('#poststuff').show().find('#content-html').trigger('click');
	$('#content').val( sobj.data );

	mini.switch( true );
	
	$('#mini-section-title input').val( sobj.title );
	$('#mini-section-category input').val( sobj.category );
	
	if( sobj.id === undefined || sobj.id === null || sobj.id == '' )
		sobj.id = parseInt( Math.random()*1000000 );
		
	$('#msg-activated-section-id').val( sobj.id );
	
	atts = { value 	: sobj.screenshot, name	: 'screenshot' };
	var field = jQuery( mini.template( 'field-type-attach_image_url', atts ) );
	
	$('#mini-section-screenshot .msc-body').html( field );
		
	if( typeof atts.callback == 'function' )
		setTimeout( atts.callback, 1, field );
		
	if( $('#style-hide-itself').length == 0 )
		$('body').append('<style type="text/css" id="style-hide-itself"></style>');
		
	$('#style-hide-itself').html('.mini-params-popup .mini-add-sections .mgs-section-item.mgs-section-'+sobj.id+'{display:none;}');
		
}	

function delete_section( el ){
	
	if( confirm('Are you sure that you want to delete this section?') ){
					
		var $ = jQuery, item = $(el).closest('.mgs-section-item');
		
		if( mini_profiles[ mini.cfg.profile_slug ] === undefined )
			data = mini.tools.base64.encode( localStorage.miniGlobalSections );
		else data = '';
		
		$('body').append('<div id="instantSaving"><span><i class="fa fa-spinner fa-spin fa-3x"></i><br /><br />Deleting...</span></div>');
		
		$.post( mini_ajax_url, {

			'action': 'mini_delete_section',
			'id': $(el).data('sid'),
			'name': mini.cfg.profile,
			'slug': mini.cfg.profile_slug,
			'data': data,
			
		}, function (result) {
			
			$('#instantSaving').remove();
			
			if( result == 0 )
				alert('Access Denied!');
			else if( result.status == 'success' ){
				
				$('.mini-backtoList').trigger('click');
				item.remove();
				
				var data = mini.tools.base64.decode( result.data );
				
				mini.backbone.stack.set( 'miniGlobalSections',  data );
				mini.cfg.profile = result.name;
				mini.backbone.stack.set( 'miniConfigs', mini.cfg );
				
				if( mini_profiles[ mini.cfg.profile_slug ] === undefined ){
					mini_profiles[ mini.cfg.profile_slug ] = result.name;
				}
				
				if( mini_profiles_external[ mini.cfg.profile_slug ] !== undefined ){
					delete mini_profiles_external[ mini.cfg.profile_slug ];	
				}
				
			}
			else alert( result.message );
			
		});
		
	}	
}

jQuery(document).ready(function( $ ){
	
	mini.curentContentType = 'mini-sections';
	/*Make sure the stack is fresh*/
	mini.backbone.stack.reset( 'miniGlobalSections' );
	
	mini.trigger({
		
		el : $('#mini-sections-manager'),
		
		events : {
			'.mgs-select-section .filter-by-category:change' : 'filter',
			'.mgs-select-section .filter-by-name:keyup' : 'search',
			'#mini-add-new-section:click' : 'add_new',
			'#mini-section-settings:click' : 'settings',
			'.mgs-select-wrp:click' : 'actions',
		},
		
		actions : function( e ){
			
			e.preventDefault();
							
			var target = e.target;
			if( target == null )
				return;
			
			if( $(target).hasClass('mgs-sel-sceenshot') || $( target ).hasClass('edit-section') ){
				
				var sid = $(target).data('sid');
				if( sid != undefined ){
					switchToEdit( sid );
				}
				
			}
			else 
			if( $( target ).hasClass('mgs-delete') ){
								
				delete_section( target );
				
			}
			else 
			if( $(target).hasClass('load-more') ){
				
				$(target).trigger('mouseover');
				
			}
			
		},
		
		filter : function( e ){
			
			var wrp = $(this).closest('.mgs-select-section'),
				items = wrp.find('.mgs-section-item'),
				sections = wrp.find('.mgs-section-item'),
				i = 0;
			if( this.value == '' ){
				sections.removeClass('forceHide');
			}else{
				sections.addClass('forceHide');
				wrp.find('.mgs-section-item.category-'+mini.tools.esc_slug(this.value)).removeClass('forceHide');
			}
			
		},
		
		search : function( e ){
			
			clearTimeout( document.key_up );
			
			document.key_up = setTimeout( function( inp ){
				
				var items = $( inp ).closest('.mgs-select-section').find('.mgs-section-item');
				items.addClass('forceHide').removeClass('break-line');
				
				items.find('.mgs-si-info span').each( function(){
					
					if( this.innerHTML.toLowerCase().indexOf( inp.value.toLowerCase() ) > -1 )
						$(this.parentNode.parentNode).removeClass('forceHide');
						
				});
				
			}, 150, this );
		
			
		},
		
		add_new : function( e ){
			
			switchToEdit( 'new' );
				
		},
		
		settings : function( e ){
			
			var atts = { title: 'Mini Sections Settings', width: 800, class: 'no-footer bg-blur-style section-manager-popup page-sections-manager' },
				pop = mini.tools.popup.render( this, atts ),
				arg = { list : 'no' },
				sections = $( mini.template( 'install-global-sections', arg ) );
			
			pop.find('.m-p-body').append( sections );
			
			if( typeof arg.callback == 'function' )
				arg.callback( sections );
		}
		
	});	
	/* End Build Sections List */
	
	
	/* Settings Category Box */
	mini.trigger({
		
		el : $('#poststuff'),
		
		events : {
			'#mini-section-category input.inp-wa0:focus' : 'focus',
			'#mini-section-category input.inp-wa0:blur' : 'blur',
			'#delete-action a:click' : 'deletion',
			'#publishing-action button:click' : 'save',
			'.mini-backtoList:click' : 'backtoList',
			'#mini-section-form:submit' : function( e ){
				e.data.el.find('#publishing-action button').trigger('click');
				e.data.el.find('.show-tips').removeClass('show-tips');
				return false;	
			},
			'#ssCountDown:click' : function(){
				$('#mini-save-success').hide();
			}
		},
		
		focus : function( e ){
			this.placeholder='Select an exist category';
			$(this).closest('#mini-section-category').addClass('show-tips');
		},
		
		blur : function( e ){
			this.placeholder='Enter new category name';
			setTimeout( function( el ){
				el.removeClass('show-tips');
			}, 200, e.data.el.find('.show-tips') );	
		},
		
		deletion : function( e ){
			
			var sid = $('#poststuff').data('sid');
			if( sid != undefined ){
				delete_section( $('.mgs-section-'+sid+' .mgs-delete').get(0) );
			}
			
		},
		
		save : function( e ){
			
			if( $('#instantSaving').length > 0 )
				return;
			
			var sid = $('#poststuff').data('sid'),
				id =  mini.tools.esc( $('#msg-activated-section-id').val() );
				
			if( id === undefined || id == ''  )
				id = parseInt( Math.random()*1000000 );
				
			if( sid == undefined )return;
			
			var stack = mini.backbone.stack.get('miniGlobalSections');

			if( sid == 'new' ){
				
				mini.backbone.stack.reset( 'miniGlobalSections' );
				
				$('#poststuff').data({ 'sid' : id });

				setTimeout( mini.ui.gsections.refresh, 100 );
				
			}
			
			var title =  mini.tools.esc( $('#mini-section-title input').val() ),
				category =  mini.tools.esc( $('#mini-section-category input').val().toString().toLowerCase() ),
				screenshot = $('#mini-section-screenshot input.mini-param').val();
			
			if( title == '' ){
				alert('<?php _e('The title must not be empty', 'mini_composer'); ?>');
				return false;
			}
				
			if( category == '' ){
				alert('<?php _e('The category must not be empty', 'mini_composer'); ?>');
				return false;
			}
			
			
			
			
			var data = '', exp;
				
			$('#mini-container > #mini-rows > .mini-row').each(function(){
				exp =  mini.backbone.export( $(this).data('model') );
				data += exp.begin+exp.content+exp.end;
			});
			
			var obj = {
				'id'	: id,
				'title'	: title,
				'category'	: category,
				'screenshot'	: screenshot,
				'data'	: data
			}
			
			mini.ui.gsections.update_section( obj );
						
			mini.changed = false;

		},
		
		backtoList : function( e ){
			
			mini.changed = false;
			$('#mini-sections-manager').show();
			$('#poststuff').hide();
			$('#mini-container').remove();
			$('#mini-undo-deleted-element').css({top:-132});
		}
		
		
	});
	/* End Settings Box */
	
	function ssCountDown( s ){
		s = parseInt( s );
		if( s > 0 && $('#mini-save-success').css('display') == 'block' ){
			$('#ssCountDown').html('Ok ('+(s-1)+')');
			setTimeout( ssCountDown, 1000, s-1 );
		}else{
			$('#mini-save-success').hide();
		}
	}

	mini.ready.push( function(){
		
		if( mini_profiles[ mini.cfg.profile_slug ] !== undefined || mini_profiles_external[ mini.cfg.profile_slug ] !== undefined ){
			
			$.post( mini_ajax_url, {
				'action': 'mini_load_profile',
				'name': mini.cfg.profile_slug
			}, function ( result ) {
				
				if( result == 0 ){
					alert('Access Denied!');
					return;
				}
				
				if( result.status != 'success' ){
					alert( result.message );
				}else{
					
					result.data = mini.tools.base64.decode( result.data );
					mini.ui.gsections.doDownloadCallback( result );
					
					<?php
						
						if( isset( $_GET['id'] ) )
							echo 'switchToEdit('.$_GET['id'].');';
						
					?>
						
				}
				
			});	
		
		}else{
			
			mini_sections_load();
			<?php
						
				if( isset( $_GET['id'] ) )
					echo 'switchToEdit('.$_GET['id'].');';
				
			?>

		
		}
	
	} );
	
	
});
	
</script>