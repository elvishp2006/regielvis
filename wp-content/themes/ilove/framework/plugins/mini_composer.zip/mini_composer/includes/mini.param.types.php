<?php
/**
*
*	Mini Composer
*	(c) MiniComposer.com
*
*/
if(!defined('MINI_FILE')){
	header('HTTP/1.0 403 Forbidden');
	exit;
}

global $mini;

foreach(

	array(
		'text' => 'mini_param_type_text',
		'hidden' => 'mini_param_type_hidden',
		'textarea' => 'mini_param_type_textarea_raw_html',
		'select' => 'mini_param_type_select',
		'dropdown' => 'mini_param_type_select',
		'textarea_html' => 'mini_param_type_textarea_html',
		'multiple' => 'mini_param_type_multiple',
		'checkbox' => 'mini_param_type_checkbox',
		'radio' => 'mini_param_type_radio',
		'attach_image' => 'mini_param_type_attach_image',
		'attach_image_url' => 'mini_param_type_attach_image_url',
		'attach_images' => 'mini_param_type_attach_images',
		'color_picker' => 'mini_param_type_color_picker',
		'icon_picker' => 'mini_param_type_icon_picker',
		'date_picker' => 'mini_param_type_date_picker',
		'mini_box' => 'mini_param_type_mini_box',
		'wp_widget' => 'mini_param_type_wp_widget',
		'css_box_tbtl' => 'mini_param_type_css_box_tbtl',
		'css_box_border' => 'mini_param_type_css_box_border',
		'group' => 'mini_param_type_group',
		'google_map' => 'mini_param_type_googlemap',
		'link' => 'mini_param_type_link',
		'post_taxonomy' => 'mini_param_type_post_taxonomy',
		'number_slider' => 'mini_param_type_number_slider',
		'random' => 'mini_param_type_random',
	) as $name => $func ){

	$mini->add_param_type( $name, $func );
}


function mini_param_type_text(){
	echo '<input name="{{data.name}}" class="mini-param" value="{{data.value}}" type="text" />';
}

function mini_param_type_hidden(){
	echo '<input name="{{data.name}}" class="mini-param" value="{{data.value}}" type="hidden" />';
}

function mini_param_type_textarea_raw_html(){
?>
	<textarea cols="46" rows="8" class="mini-row-area">{{mini.tools.base64.decode( data.value )}}</textarea>

	<!--For instant saving, dont change to base64-->
	<textarea name="{{data.name}}"  style="display:none;"class="mini-param">{{mini.tools.base64.decode( data.value )}}</textarea>
	<#

		data.callback = function( el ){
			var pop = el.closest('.mini-params-popup');
			pop.data({ before_callback : function( pop ){
				var value = pop.find('textarea.mini-row-area').val();
				pop.find('textarea.mini-param').val( mini.tools.base64.encode( value ) );

			}});
		}

	#>
<?php
}

function mini_param_type_select(){
?>
		<select class="mini-param" name="{{data.name}}">
			<# if( data.options ){
				for( var n in data.options ){
					if( typeof data.options[n] == 'array' ||  typeof data.options[n] == 'object' ){
					#><optgroup label="{{n}}"><#
						for( var m in data.options[n] ){
							#><option<#
								if( m == data.value ){ #> selected<# }
								#> value="{{m}}">{{data.options[n][m]}}</option><#
						}
					#></optgroup><#

					}else{

			#><option<#
						if( n == data.value ){ #> selected<# }
					#> value="{{n}}">{{data.options[n]}}</option><#
					}
				}
			} #>
		</select>
<?php
}

function mini_param_type_textarea_html(){
?>
	<# var eid = parseInt( Math.random()*100000 ); #>

	<div class="mini-textarea_html-field-wrp">
		<div class="mini-editor-wrapper">
            <div id="wp-mini-content-{{eid}}-wrap" class="wp-core-ui wp-editor-wrap tmce-active">
                <div id="wp-mini-content-{{eid}}-editor-tools" class="wp-editor-tools hide-if-no-js">
                    <div id="wp-mini-content-{{eid}}-media-buttons" class="wp-media-buttons">
                        <button type="button" class="button mini-insert-media" data-editor="mini-content-{{eid}}">
                        	<i class="sl-cloud-upload"></i> <?php _e('Insert Media', 'mini_composer'); ?>
                        </button>
                    </div>
                    <div class="wp-editor-tabs">
                        <button type="button" class="wp-switch-editor switch-tmce" data-wp-editor-id="mini-content-{{eid}}"><?php _e('Visual', 'mini_composer'); ?></button>
                        <button type="button" class="wp-switch-editor switch-html" data-wp-editor-id="mini-content-{{eid}}"><?php _e('Text', 'mini_composer'); ?></button>
                    </div>
                </div>
                <div id="wp-mini-content-{{eid}}-editor-container" class="wp-editor-container">
                    <div id="qt_mini-content-{{eid}}_toolbar" class="quicktags-toolbar"></div>
                    <textarea class="wp-editor-area mini-param" rows="10" autocomplete="off" width="100%" name="{{data.name}}" id="mini-content-{{eid}}">{{data.value}}</textarea>
                </div>
            </div>
        </div>
	</div>
	<#
		data.callback = function( wrp, $ ){

			mini.tools.editor.init( $('#mini-content-'+eid) );

			wrp.closest('.mini-params-popup').data({ before_callback : function( pop ){

				if( pop.find('.wp-editor-wrap').hasClass('tmce-active') )
					pop.find('textarea.mini-param').val( tinyMCE.activeEditor.getContent() );

			}});

			wrp.find('.mini-insert-media').on('click', { callback : function( atts ){

				mini.tools.editor.insert( window.wpActiveEditor ,wp.media.string.image( null, atts ) );

			}, atts : {frame:'post'} }, mini.tools.media.open );

		}
	#>

<?php
}

function mini_param_type_multiple(){
?>

	<div mini-multiple-field-wrp>
		<select multiple>
			<# if( data.options ){
				var vals = data.value.split(',');
				for( var n in data.options ){
					if( typeof data.options[n] == 'array' ||  typeof data.options[n] == 'object' ){
					#><optgroup label="{{n}}"><#
						for( var m in data.options[n] ){
							#><option<#
								if( vals.indexOf( m ) > -1 ){ #> selected<# }
								#> value="{{m}}">{{data.options[n][m]}}</option><#
						}
					#></optgroup><#

					}else{

			#><option<#
						if( vals.indexOf( n ) > -1 ){ #> selected<# }
					#> value="{{n}}">{{data.options[n]}}</option><#
					}
				}
			} #>
		</select>
		<input type="hidden" name="{{data.name}}" class="mini-param" value="{{data.value}}" />
		<a href="#" class="clear-selected">
			<i class="sl-close"></i> <?php _e('Remove Selection', 'mini_composer'); ?>
		</a>
	</div>
	<#
		data.callback = function( el ){
			el.find('select').on( 'change', el, function(e){
				e.data.find('input.mini-param').val( jQuery(this).val() );
			});
			el.find('.clear-selected').on( 'click', el, function(e){
				e.data.find('select option:selected').removeAttr('selected');
				e.data.find('input.mini-param').val('');
				e.preventDefault();
			});
		}
	#>
<?php
}

function mini_param_type_checkbox(){
?>

	<# if( data.options ){
		var vals = data.value.split(',');
		for( var n in data.options ){
			#><span class="nowrap"><input type="checkbox" class="mini-param" name="{{data.name}}" <#
				if( vals.indexOf( n ) > -1 ){ #> checked<# }
			#> value="{{n}}" /> {{data.options[n]}}</span>
		<# }
	} #><input type="checkbox" checked class="mini-param" value="" name="{{data.name}}" style="display:none;" />
<?php
}

function mini_param_type_radio(){
?>
	<div mini-multiple-field-wrp>
		<# if( data.options ){
			for( var n in data.options ){
				#><span class="nowrap"><input type="radio" class="mini-param" name="{{data.name}}" <#
					if( n == data.value ){ #> checked<# }
				#> value="{{n}}" /> {{data.options[n]}}</span>
			<# } #>
			<a href="#" class="clear-selected">
				<i class="sl-close"></i> <?php _e('Remove Selection', 'mini_composer'); ?>
			</a>
		<# } #><input type="radio" class="mini-param empty-value" value="" name="{{data.name}}" style="display:none;" />
	</div>
	<#
		data.callback = function( el ){
			el.find('.clear-selected').on( 'click', el, function(e){
				e.data.find('input.mini-param.empty-value').attr({'checked':true});
				e.preventDefault();
			});
		}
	#>
<?php
}

function mini_param_type_attach_image(){
?>

	<div class="mini-attach-field-wrp">
		<input name="{{data.name}}" class="mini-param" value="{{data.value}}" type="hidden" />
		<# if( data.value != '' ){ #>
		<div class="img-wrp">
			<img src="{{site_url}}/wp-admin/admin-ajax.php?action=mini_get_thumbn&id={{data.value}}" alt="" />
			<i class="sl-close" title="<?php _e('Delete this image', 'mini_composer'); ?>"></i>
		</div>
		<# } #>
		<div class="clear"></div>
		<a class="button media button-primary">
			<i class="sl-cloud-upload"></i> <?php _e('Browse Image', 'mini_composer'); ?>
		</a>
	</div>
	<#
		data.callback = function( el, $ ){

			el.find('.media').on( 'click', { callback: function( atts ){

				var wrp = $(this.el).closest('.mini-attach-field-wrp'), url = atts.url;

				wrp.find('input.mini-param').val(atts.id);
				if( typeof atts.sizes.medium == 'object' )
					var url = atts.sizes.medium.url;

				if( !wrp.find('img').get(0) ){
					wrp.prepend('<div class="img-wrp"><img src="'+url+'" alt="" /><i title="<?php _e('Delete this image', 'mini_composer'); ?>" class="sl-close"></i></div>');
					wrp.find('img').on( 'click', el, function( e ){
						el.find('.media').trigger('click');
					});
					wrp.find('div.img-wrp .sl-close').on( 'click', el, function( e ){
						e.data.find('input.mini-param').val('');
						$(this).closest('div.img-wrp').remove();
					});
				}else wrp.find('img').attr({src : url});

			}, atts : { frame: 'select' } }, mini.tools.media.open );

			el.find('div.img-wrp .sl-close').on( 'click', el, function( e ){
				e.data.find('input.mini-param').val('');
				$(this).closest('div.img-wrp').remove();
			});

			el.find('div.img-wrp img').on( 'click', el, function( e ){
				el.find('.media').trigger('click');
			});



		}
	#>
<?php
}

function mini_param_type_attach_image_url(){
?>

	<div class="mini-attach-field-wrp">
		<input name="{{data.name}}" class="mini-param" value="{{data.value}}" type="hidden" />
		<# if( data.value != '' ){ #>
		<div class="img-wrp">
			<img src="{{data.value}}" alt="" />
			<i class="sl-close" title="<?php _e('Delete this image', 'mini_composer'); ?>"></i>
			<div class="img-sizes"></div>
		</div>
		<# } #>
		<div class="clear"></div>
		<a class="button media button-primary">
			<i class="sl-cloud-upload"></i> <?php _e('Select Image', 'mini_composer'); ?>
		</a>
	</div>
	<#
		data.callback = function( el ){

			var $ = jQuery;

			el.find('.media').on( 'click', { callback : function( atts ){

				var wrp = $(this.el).closest('.mini-attach-field-wrp'), url = atts.url;

				if( atts.size != undefined && atts.size != null && atts.sizes[atts.size] != undefined ){
					var url = atts.sizes[atts.size].url;
				}else if( typeof atts.sizes.medium == 'object' ){
					var url = atts.sizes.medium.url;
				}

				if( url != undefined && url != '' ){
					wrp.find('input.mini-param').val(url);
				}

				if( !wrp.find('img').get(0) ){
					wrp.prepend('<div class="img-wrp"><img src="'+url+'" alt="" /><i title="<?php _e('Delete this image', 'mini_composer'); ?>" class="sl-close"></i><div class="img-sizes"></div></div>');
					el.find('div.img-wrp img').on( 'click', el, function( e ){
						el.find('.media').trigger('click');
					});
					el.find('div.img-wrp .sl-close').on( 'click', el, function( e ){
						$(this).closest('div.img-wrp').remove();
						e.data.find('input.mini-param').val('');
					});
				}else{
					wrp.find('img').attr({src : url});
					wrp.find('.img-sizes').html('');
				}

				var btn, wrpsizes = wrp.find('.img-sizes');
				for( var si in atts.sizes ){
					btn = $('<button data-url="'+atts.sizes[si].url+
								'" class="button">'+atts.sizes[si].width+'x'+
								atts.sizes[si].height+'</button>'
							);

					if( atts.size != undefined && atts.size ){

						if( atts.size == si )
							btn.addClass('button-primary');

					}else if( si == 'medium' )
						btn.addClass('button-primary');

					btn.on( 'click', function(e){

						var wrp = $(this).closest('.mini-attach-field-wrp'), url = $(this).data('url');

						$(this).parent().find('button').removeClass('button-primary');
						$(this).addClass('button-primary');

						wrp.find('img').attr({ src : url });
						wrp.find('input.mini-param').val( url );

						e.preventDefault();
						return false;

					});
					wrpsizes.append( btn );
				}

			}, atts : {frame:'post'} }, mini.tools.media.open );

			el.find('div.img-wrp .sl-close').on( 'click', el, function( e ){
				$(this).closest('div.img-wrp').remove();
				e.data.find('input.mini-param').val('');
			});

			el.find('div.img-wrp img').on( 'click', el, function( e ){
				el.find('.media').trigger('click');
			});

		}
	#>
<?php
}


function mini_param_type_attach_images(){
?>
	<div class="mini-attach-field-wrp">
		<input name="{{data.name}}" class="mini-param" value="{{data.value}}" type="hidden" />
		<#
			if( data.value != '' ){
				data.value = data.value.split(',');
				for( var n in data.value ){
					#><div data-id="{{data.value[n]}}" class="img-wrp"><img title="<?php _e('Drag image to sort', 'mini_composer'); ?>" src="{{site_url}}/wp-admin/admin-ajax.php?action=mini_get_thumbn&id={{data.value[n]}}&size=thumbnail" alt="" /><i class="sl-close"></i></div><#
				}
		 #>
		<# } #>
		<div class="clear"></div>
		<a class="button media button-primary">
			<i title="<?php _e('Delete this image', 'mini_composer'); ?>" class="sl-cloud-upload"></i> <?php _e('Browse Images', 'mini_composer'); ?>
		</a>
	</div>

	<#
		data.callback = function( el ){

			el.find('.media').on( 'click', function( atts ){

				var wrp = jQuery(this.els).closest('.mini-attach-field-wrp'), url = atts.url;

				wrp.find('input.mini-param').val(atts.id);
				if( typeof atts.sizes.thumbnail == 'object' )
					var url = atts.sizes.thumbnail.url;

				wrp.prepend('<div data-id="'+atts.id+'" class="img-wrp"><img title="<?php _e('Drag image to sort', 'mini_composer'); ?>" src="'+url+'" alt="" /><i title="<?php _e('Delete this image', 'mini_composer'); ?>" class="sl-close"></i></div>');
				helper( wrp );

			}, mini.tools.media.opens );

			function helper( el ){

				mini.ui.sortable({

					items : 'div.mini-attach-field-wrp>div.img-wrp',
					helper : ['mini-ui-handle-image', 25, 25 ],
					connecting : false,
					vertical : false,
					end : function( e, el ){
						refresh( jQuery(el).closest('.mini-attach-field-wrp') );
					}

				});


				el.find('div.img-wrp i.sl-close').off('click').on( 'click', el, function( e ){
					jQuery(this).closest('div.img-wrp').remove();
					refresh( e.data );
				});

				refresh( el );

			}

			function refresh( el ){
				var val = [];
				el.find('div.img-wrp').each(function(){
					val[ val.length ] = jQuery(this).data('id');
				});
				if( val.length <= 4 ){
					el.removeClass('img-wrp-medium').removeClass('img-wrp-large');
				}else if( val.length > 4 && val.length < 9 ){
					el.addClass('img-wrp-medium').removeClass('img-wrp-large');
				}else if( val.length >= 9 ){
					el.removeClass('img-wrp-medium').addClass('img-wrp-large');
				}

				el.find('input.mini-param').val( val.join(',') );

				el.find('div.img-wrp img').on( 'click', el, function( e ){
					el.find('.media').trigger('click');
				});
			}

			helper( el.find('.mini-attach-field-wrp') );

		}
	#>

<?php
}

function mini_param_type_color_picker(){
?>
	<input name="{{data.name}}" value="{{data.value}}" placeholder="Select color" class="mini-param" type="search" />
	<#
		data.callback = function( el ){
			el.find('input').each(function(){
				this.color = new jscolor.color(this, {});
			});
	    }
	#>
<?php
}

function mini_param_type_icon_picker(){

?>	<# if( data.value == undefined || data.value == '' )data.value='fa-leaf'; #>
	<div class="icons-preview">
		<i class="{{data.value}}"></i>
	</div>
	<input name="{{data.name}}" value="{{data.value}}" placeholder="Click to select icon" class="mini-param mini-param-icons" type="text" />
	<#
		data.callback = function( el, $ ){

			el.find('input.mini-param').on('focus', function(){

				$('.mini-icons-picker-popup').remove();

				var listObj = jQuery( '<div class="icons-list noneuser">'+mini.tools.get_icons()+'</div>' );

				var atts = { title: 'Select Icons', width: 600, class: 'no-footer mini-icons-picker-popup', keepCurrentPopups: true };
				var pop = mini.tools.popup.render( this, atts );
				pop.data({ target: this, scrolltop: jQuery(window).scrollTop() });

				pop.find('.m-p-body').off('mousedown').on('mousedown',function(e){
					e.preventDefault();
					return false;
				});

				$(this).off( 'keyup' ).on( 'keyup', listObj, function( e ){

					clearTimeout( this.timer );
					this.timer = setTimeout( function( el, list ){

						if( list.find('.seach-results').length == 0 ){

							var sr = $('<div class="seach-results"></div>');
							list.prepend( sr );

						}else sr = list.find('.seach-results');

						var found = ['<span class="label">Search Results:</span>'];
						list.find('>i').each(function(){

							if( this.className.indexOf( el.value.trim() ) > -1
								&& found.length < 16
								&& $.inArray( this.className, found )
							)found.push( '<span data-icon="'+this.className+'"><i class="'+this.className+'"></i>'+this.className+'</span>' );

						});
						if( found.length > 1 ){
							sr.html( found.join('') );
							sr.find('span').on('mousedown', function(){

								if( $(this).data('icon') === undefined )
								{
									e.preventDefault();
									return false;
								}
								var tar = mini.get.popup(this).data('target');
								tar.value = $(this).data('icon');
								$(tar).trigger('change');
								setTimeout( function(el){el.trigger('blur');}, 100, $(tar) );
							});
						}
						else sr.html( '<span class="label">The key you entered was not found.</span>' );

					}, 150, this, e.data );

				});

				listObj.find('i').on('mousedown', function( e ){

					var tar = mini.get.popup(this).data('target');
					tar.value = this.className;

					$(tar).trigger('change');
					setTimeout( function(el){el.trigger('blur');}, 100, $(tar) );

				});

				setTimeout(function( el, list ){
					el.append( list );
				}, 10, pop.find('.m-p-body'), listObj );

			}).on('change',function(){
				jQuery(this).parent().find('.icons-preview i').attr({class: this.value});
			}).on('blur', function(){
				$('.mini-icons-picker-popup').remove();
			});

	    }
	#>
<?php
}

function mini_param_type_date_picker(){
?>

	<input name="{{data.name}}" class="mini-param" value="{{data.value}}" type="text" />
	<#
		data.callback = function( wrp, $ ){
			new Pikaday(
		    {
		        field: wrp.find('.mini-param').get(0),
		        firstDay: 1,
				format: 'yyyy/mm/dd',
		        minDate: new Date(2000, 0, 1),
		        maxDate: new Date(2020, 12, 31),
		        yearRange: [2000,2020]
		    });
		}
	#>

<?php
}

function mini_param_type_mini_box(){

?>

	<textarea name="data" class="mini-param mini-box-area forceHide">{{data.value}}</textarea>
	<button class="button html-code" data-action="html-code">
		<i class="sl-doc"></i> <?php _e('HTML Code', 'mini_composer'); ?>
	</button>
	<button class="button css-code" data-action="css-code">
		<i class="sl-settings"></i> <?php _e('CSS Code', 'mini_composer'); ?>
	</button>
	<button class="button align-center add-top" data-action="add" data-pos="top">
		<i class="sl-plus"></i>
	</button>
	<div class="mini-box-render"></div>
	<button class="button align-center add-bottom" data-action="add" data-pos="bottom">
		<i class="sl-plus"></i>
	</button>
	<div class="mini-box-trash">
		<a href="#" class="button forceHide" data-action="undo">
			<i class="sl-action-undo"></i> Undo Delete(0)
		</a>
	</div>
<#

	data.callback = function( wrp, $ ){

		try{
			var data_obj = JSON.parse( mini.tools.base64.decode( data.value ) );
		}catch(e){
			var data_obj = [{tag:'div',children:[{tag:'text', content:'There was an error with content structure.'}]}];
		}

		wrp.find('.mini-box-render').eq(0).append( mini.template( 'box-design', data_obj ) );

		mini.get.popup( wrp ).data({ before_callback : mini.ui.miniBox.renderBack }).addClass('preventCancel');

		mini.ui.miniBox.sort();

		wrp.on( 'click', function( e ){

			if( e.target.tagName == 'I' )
				var el = $( e.target.parentNode );
			else var el = $( e.target );

			mini.ui.miniBox.actions( el, e );

		} );

	}

#>
<?php
}


function mini_param_type_wp_widget(){

?><#

	try{
		var obj = JSON.parse( mini.tools.base64.decode( data.value ) );
	}catch(e){
		return '<center><?php _e('There was an error with content structure.', 'mini_composer'); ?></center>';
	}
	var html = '';

	for( var n in obj ){

		mini.widgets.find('input[name="id_base"]').each(function(){

			if( this.value == n ){

				html = jQuery(this).closest('div.widget').find('.widget-content').html();
				html = '<div class="mini-widgets-container" data-name="'+n+'">'
					   +html.replace(/name="([^"]*)"/g,function(r,v){

							v = v.split('][');
							v = ( v[1] != undefined ) ? v[1] : v[0];
							v = v.replace(/\]/g,'').trim();
							var str = 'name="'+v+'"';

							if( obj[n][v] != undefined )
								str += ' data-value="'+mini.tools.esc(obj[n][v])+'"';

							return str;

						})+'</div>';
			}
		});
	}

	#>{{{html}}}<#

	data.callback = function( wrp, $ ){

		wrp.find('*[data-value]').each(function(){
			switch( this.tagName ){
				case 'INPUT' :
					if( this.type == 'radio' || this.type == 'checkbox' )
						this.checked = true;
					else this.value = jQuery(this).data('value');
				break;
				case 'TEXTAREA' :
					this.value = jQuery(this).data('value');
				break;
				case 'SELECT' :
					var vls = jQuery(this).data('value');
					if( vls )vls = vls.toString().split(',');
					else vls = [''];

					if( vls.length > 1 )
						this.multiple = 'multiple';
					jQuery(this).find('option').each(function(){
						if( vls.indexOf( this.value ) > -1 )
							this.selected = true;
						else this.selected = false;
					});
				break;
			}
		});

		var pop = mini.get.popup( wrp );

		pop.data({ before_callback : function( wrp ){

			var name = wrp.find('.mini-widgets-container').data('name'),
				fields = wrp.find('form.fields-edit-form').serializeArray(),
				data = {};

			data[ name ] = {};

			fields.forEach(function(n){
				if( data[ name ][n.name] == undefined )
					data[ name ][n.name] = n.value;
				else data[ name ][n.name] += ','+n.value;
			});

			var string = mini.tools.base64.encode( JSON.stringify( data ) );

			wrp.find('.m-p-r-content').append('<textarea name="data" class="mini-param mini-widget-area forceHide">'+string+'</textarea>');

		}});

		pop.data({ _after_callback : pop.data( 'after_callback' ), after_callback : function( wrp ){
			wrp.find('.m-p-r-content .mini-param').remove();
			wrp.data('_after_callback')( wrp );
		}});

	}

#>
<?php
}


function mini_param_type_css_box_tbtl(){
?>
	<#
		var imp = data.value.indexOf('!important');
		if( imp > -1 )
			imp = '!important';
		else imp = '';
		var val = data.value.replace('!important','').split(' ');
	#>
	<ul class="multi-fields-ul">
		<li>
			<input class="mini-param" name="{{data.name}}-top" class="m-f-u-first" value="{{val[0]}}" type="text" /><br /> <strong>Top</strong>
		</li>
		<li>
			<input class="mini-param" name="{{data.name}}-bottom" type="text" value="{{val[2]}}" /><br /> Bottom
		</li>
		<li>
			<input class="mini-param" name="{{data.name}}-left" type="text" value="{{val[3]}}" /><br /> Left
		</li>
		<li>
			<input class="mini-param" name="{{data.name}}-right" class="m-f-u-last" type="text" value="{{val[1]}}" /><br /> Right
		</li>
		<li class="m-f-u-li-link">
			<span><input <# if( val[0] == val[1] && val[1] == val[2] && val[2] == val[3] ){ #>checked<#} #> type="checkbox" /></span><br /> <i class="sl-link"></i>
		</li>
		<input type="hidden" class="mini-param" name="{{data.name}}-important" value="{{imp}}" />
	</ul>
	<#
		data.callback = function( el ){
			el.find('input[type=text]').on( 'keyup', el, function( e ){
				if( e.data.find('input[type=checkbox]').get(0).checked == true ){
					var cur = this;
					e.data.find('input[type=text]').each(function(){
						if( this != cur )
							this.value = cur.value;
					});
				}
			});
			el.find('input[type=checkbox]').on( 'change', el, function( e ){
				if( this.checked == true ){
					e.data.find('input[type=text]').val( e.data.find('input[type=text]').get(0).value );
				}
			});
		}
	#>
<?php
}
function mini_param_type_css_box_border(){
?>
	<#
		var imp = data.value.indexOf('!important');
		if( imp > -1 )
			imp = '!important';
		else imp = '';
		var val = data.value.replace('!important','').split(' ');
	#>
	<ul class="multi-fields-ul">
		<li>
			<input name="border-width" class="m-f-u-first mini-param" value="{{val[0]}}" type="text" /><br /> Width
		</li>
		<li>
			<span class="m-f-u-li-splect">
				<select name="border-style" class="mini-param">
					<option value="none">none</option>
					<option <# if(val[1]== 'hidden'){ #>selected<# } #> value="hidden">hidden</option>
					<option <# if(val[1]== 'dotted'){ #>selected<# } #> value="dotted">dotted</option>
					<option <# if(val[1]== 'dashed'){ #>selected<# } #> value="dashed">dashed</option>
					<option <# if(val[1]== 'solid'){ #>selected<# } #> value="solid">solid</option>
					<option <# if(val[1]== 'double'){ #>selected<# } #> value="double">double</option>
					<option <# if(val[1]== 'groove'){ #>selected<# } #> value="groove">groove</option>
					<option <# if(val[1]== 'ridge'){ #>selected<# } #> value="ridge">ridge</option>
					<option <# if(val[1]== 'inset'){ #>selected<# } #> value="inset">inset</option>
					<option <# if(val[1]== 'outset'){ #>selected<# } #> value="outset">outset</option>
					<option <# if(val[1]== 'initial'){ #>selected<# } #> value="initial">initial</option>
					<option <# if(val[1]== 'inherit'){ #>selected<# } #> value="inherit">inherit</option>
				</select>
			</span>
			<br /> Style
		</li>
		<li>
			<input type="text" name="border-color" value="{{val[2]}}" width="80" class="m-f-bb-color mini-param" /><br /> Color
		</li>
		<input type="hidden" name="border-important" class="mini-param" value="{{imp}}" />
	</ul>
	<#
		data.callback = function( el ){
			el.find('input.m-f-bb-color').each(function(){
				this.color = new jscolor.color(this, {});
			});
	    }
	#>
<?php
}
function mini_param_type_group(){
?>
<div class="mini-group-rows"></div>
<#
	try{
		data.value = JSON.parse( mini.tools.base64.decode( data.value ) );
		var values = {};
		for( var i in data.value ){
			if( i.indexOf( data.name+'[' ) == -1 ){
				values[ data.name+'['+i+']' ] = {};
				if( typeof data.value[i] == 'object' ){
					for( var j in data.value[i] ){
						values[ data.name+'['+i+']['+j+']' ] = data.value[i][j];
					}
				}else values[ data.name+'['+i+']' ] = data.value[i];
			}
			else values[ i ] = data.value[i];
		}
	}catch(e){
		data.value = {'g0':{}};
		var values = {};
	}

	data.callback = function( wrp, $, data ){

		wrp.data({ 'name' : data.name, 'params': data.params });

		for( var n in data.value ){

			var params = mini.params.fields.group.set_index( data.params, data.name, n );

			var grow = $( mini.template( 'param-group' ) );
			wrp.find('.mini-group-rows').append( grow );

			mini.params.fields.render( grow.find('.mini-group-body'), params, values );

		}

		wrp.find('.mini-group-rows').append( '<div class="mini-group-controls mini-add-group"><i class="sl-plus"></i> <?php _e('Add new Group', 'mini_composer'); ?></div>' );

		mini.params.fields.group.callback( wrp );

	}

#>
<?php
}

function mini_param_type_googlemap(){
?>
<#
	if ( data.value != '' ) {
		var latlg = data.value.split('|'),
			c_lat = Number(latlg[0]),
			c_lng = Number(latlg[1]),
			zoom = Number(latlg[2]);
	} else {
		var c_lat = 21.034856055581216,
			c_lng = 105.78365346708983,
			zoom = 8,
			value = c_lat+'|'+c_lng+'|'+zoom;
	}

#>

<div class="mini-map-param-location">
	<input id="mini-map-pac-{{data.name}}" onkeydown="if(window.event && window.event.keyCode == 13) {event.preventDefault();return false;}" class="mini-map-param-search" type="text" placeholder="<?php _e( 'Search your location', 'mini_composer' ); ?>" style="top: 12px;">
	<input type="hidden" name="{{data.name}}" class="mini-param" value="{{data.value}}" id="mini-map-latlng-{{data.name}}" />
	<div id="mini-param-map-{{data.name}}" class="mini-map-param-container">Loading maps...</div>
</div>

<#
	data.callback = function( wrp, $){

		mini.params.fields.gmaps.init({ name: data.name, c_lat: c_lat, c_lng: c_lng, zoom: zoom  });

	}
#>
<?php
}

function mini_param_type_link(){
?>
<#
	if( typeof data.value != 'undefined' && data.value != '' )
		var value = data.value.split('|');
	else value = ['','','','',''];
#>
	<input name="{{data.name}}" class="mini-param" value="{{data.value}}" type="hidden" />
	<a class="button link button-primary">
		<i class="sl-link"></i> <?php _e( 'Add your link', 'mini_composer' ); ?>
	</a>
	<br />
	<span class="link-preview">
		<# if( value[0] !== undefined && value[0] != '' ){ #><strong>Link:</strong> {{value[0]}}<br /><# } #>
		<# if( value[1] !== undefined && value[1] != '' ){ #><strong>Title:</strong> {{value[1]}}<br /><# } #>
		<# if( value[2] !== undefined && value[2] != '' ){ #><strong>Target:</strong> {{value[2]}}<br /><# } #>
	</span>

<#

	data.callback = function( wrp, $ ){
		wrp.find('.button.link').on( 'click', wrp, function(e) {

            wpLink.open();

            var value = e.data.find('.mini-param').val();
            if( value != '' )
				value = value.split('|');
			else value = ['','','','',''];

            $('#wp-link-url').val( value[0] );
	        $('#wp-link-text').val( value[1] );
	        if( value[2] == '_blank' )
	        	$('#wp-link-target').attr({checked: true});

            if( $('#wp-link-update #mini-link-submit').length == 0 ){
            	$('#wp-link-update').append('<input type="submit" value="Add Link to Mini" class="button button-primary" id="mini-link-submit" name="wp-link-submit" style="display: none">');
				$('#wp-link-cancel, #wp-link-close').on( 'click', function(e) {
					$('#wp-link-submit').css({display: 'block'});
					$('#mini-link-submit').css({display: 'none'});
			        wpLink.close();
			        e.preventDefault ? e.preventDefault() : e.returnValue = false;
			        e.stopPropagation();
			        return false;
			    });
            }

            $('#wp-link-submit').css({display: 'none'});

            $('#wp-link-update #mini-link-submit').css({display: 'block'}).off('click').on( 'click', e.data, function(e) {

	            var url = $('#wp-link-url').val(),
	            	text = $('#wp-link-text').val(),
	            	target = $('#wp-link-target').get(0).checked?'_blank':'';

				e.data.find('.mini-param').val(url+'|'+text+'|'+target);

				var preview = '';
				if( url != '' )
					preview += '<strong>Link:</strong> '+url+'<br />';
				if( text != '' )
					preview += '<strong>Title:</strong> '+text+'<br />';
				if( target != '' )
					preview += '<strong>Target:</strong> '+target+'<br />';

				e.data.find('.link-preview').html( preview );

				$('#wp-link-close').trigger('click');

	            wpLink.close();
	            e.preventDefault
	            return false;
	        });
            return false;
        });
	}

#>

<?php
}

function mini_param_type_post_taxonomy(){

	$post_types = get_post_types( array(
			'public'   => true,
			'_builtin' => false
		),
		'names'
	);

	$post_types = array_merge( array( 'post' => 'post'), $post_types );

	foreach($post_types as $post_type){
		$taxonomy_objects = get_object_taxonomies( $post_type, 'objects' );
		$taxonomy = key( $taxonomy_objects );
		$args[ $post_type ] = mini_get_terms( $taxonomy, 'slug' );
	}

	echo '<label>'.__( 'Select Content Type', 'mini_composer' ).': </label>';
	echo '<br />';
	echo '<select class="mini-content-type">';
	foreach( $args as $k => $v ){
		echo '<option value="'.esc_attr($k).'">'.ucwords( str_replace(array('-','_'), array(' ', ' '), $k ) ).'</option>';
	}
	echo '</select>';
	echo '<div class="mini-select-wrp">';
		echo '<select style="height: 150px" multiple class="mini-taxonomies-select">';

		foreach( $args as $type => $arg ){

			echo '<option class="'.esc_attr($type).'-st" value="'.esc_attr($type).'" style="display:none;">'.esc_html($type).'</option>';

			foreach( $arg as $k => $v ){

				$k = $type.':'.str_replace( ':', '&#58;', $k );

				echo '<option class="'.esc_attr($type).' '.esc_attr($k).'" value="'.esc_attr($k).'" style="display:none;">'.esc_html($v).'</option>';

			}
		}

		echo '</select>';
		echo '<button class="button unselected" style="margin-top: 10px;">Remove selection</button>';
	echo '</div>';

?>
<#

	data.callback = function( wrp, $ ){

		// Action for changing content type
		wrp.find('.mini-content-type').on( 'change', wrp, function( e ){

			var type = this.value;

			e.data.find('.mini-taxonomies-select option').each(function(){

				this.selected = false;

				if( $(this).hasClass( type ) )
					this.style.display = '';
				else this.style.display = 'none';

				if( this.value == type ){
					this.checked = true;
					e.data.find('input.mini-param').val( type );
				}
			});

		});
		// Action for changing taxonomies
		wrp.find('.mini-taxonomies-select').on( 'change', wrp, function( e ){

			var value = [];
			$(this).find('option:selected').each(function(){
				value.push( this.value );
			});

			e.data.find('input.mini-param').val( value.join(',') );

		});
		// Action remove selection
		wrp.find('.unselected').on( 'click', wrp, function( e ){

			e.data.find( '.mini-taxonomies-select option:selected' ).attr({ selected: false });
			e.preventDefault();

		});

		var values = data.value.split(','),
		valuez = data.value+',';

		// Active selected taxonomies
		if( values.length > 0 ){

			selected = values[0].split( ':' )[0];

			// Active selected content type
			if( selected != '' )
				wrp.find('.mini-content-type option[value='+selected+']').attr('selected','selected').trigger('change');
			else wrp.find('.mini-content-type').trigger('change');

			wrp.find('.mini-taxonomies-select option').each(function(){
				if( valuez.indexOf( this.value+',' ) > -1 ){
					this.selected = true;
				}else this.selected = false;
			});
		}

		wrp.find('.mini-select-wrp')
			.append('<input class="mini-param" name="'+data.name+'" type="hidden" value="'+data.value+'" />');

	}

#>


<?php
}



function mini_param_type_number_slider(){
	?>
	<#
		var type, show_input;
		show_input = (typeof data.options['show_input'] == 'undefined' )? false: data.options['show_input'];

		if( show_input === true){
			type = 'text';
		}else{
			type = 'hidden';
		}
	#>

    <div id="mini_{{data.name}}" class="mini_percent_slider"></div>
	<input type="{{type}}" class="mini-param number_slider_field" name="{{data.name}}" value="{{data.value}}" />

	<#
	//console.log(data.options);

	data.callback = function( el, $ ){

        var mini_number_slider = function( set_val ){
			var _step,
				show_input = (typeof data.options['show_input'] == 'undefined' )? false: data.options['show_input'];

			if(show_input === true ){
				_step = 1;
			}
			else{
				_step = data.options['step'];
			}

			$("#mini_"+data.name).freshslider({
				step	: _step,
				min		: data.options['min'],
				max		: data.options['max'],
				unit	: data.options['unit'],
				value	: set_val,
				enabled : data.options['enabled'],

				onchange: function(value){
					$("#mini_"+data.name).next('input').val(value);
					if(show_input === true ) el.find('.fscaret').text('');
				}
			});


		};

		mini_number_slider( parseInt(data.value) );

		$("#mini_"+data.name).next('input').on('keyup', el, function(e){
			var _value = $(this).val();

			if(/^\d+$/.test(_value) && _value !== ''){
				$(this).val( parseInt(_value) );

				if( _value > data.options['max'] ) _value = data.options['max'];

				mini_number_slider( _value );
			}else{
				$("#mini_"+data.name).next('input').val('');
			}

		});
    }

	#>
	<?php
}


function mini_param_type_random(){
?>
	<#
		var new_random = parseInt(Math.random()*1000000);
	#>
	<input name="{{data.name}}" class="mini-param" value="{{new_random}}" type="text" />

<?php
}
