<?php
/**
*
*	Mini Composer
*	(c) MiniComposer.com
*
*/

if(!defined('ABSPATH')) {
	header('HTTP/1.0 403 Forbidden');
	exit;
}

class mini_front{

	public $mini_url;
	private $allows = null;
	private $scripts = array();
	private $styles = array();
	private $css = '';
	private $js = '';
	private $pattern_filter = '';

	public function __construct(){

		$this->mini_url = trailingslashit( MINI_URL ).'assets/frontend/';

		add_action( 'wp_enqueue_scripts', array( &$this, 'before_header' ), 9999 );
		add_action( 'wp_head', array( &$this, 'mini_front_head' ), 999 );

		add_filter('body_class', array( &$this, 'body_classes' ) );

		$icl_array = array(
			'helper.functions.php' =>  MINI_PATH.'/includes/frontend/helpers/',
			'shortcodes.filters.php' =>  MINI_PATH.'/includes/frontend/helpers/'
		);

		foreach( $icl_array as $file => $dir ) {

			if( file_exists( trailingslashit($dir).$file ) )
				include trailingslashit($dir).$file;

		}

		$this->mini_add_filters();

	}

	public function mini_add_filters(){

		foreach(
			array(
				'row',
				'box',
				'tab',
				'google_maps',
				'twitter_feed',
				'flip_box',
				'pie_chart',
				'button',
				'counter_box',
				'carousel_images',
				'carousel_post',
				'image_gallery',
				'coundown_timer'
			) as $k => $v ){

			add_filter( 'shortcode_mini_'.$v, 'mini_'.$v.'_filter' );

		}

	}

	public function before_header(){

		// Get access of curent page
		// Return to $this->allows

		if( $this->allowed_access() ){

			global $post, $shortcode_tags, $mini;

			$this->add_register_styles();
			$this->load_scripts();

			if( empty( $post->post_content ) )
				return false;
			// Find all registered tag names in $content.
			
			preg_match_all( '@\[([^<>&/\[\]\x00-\x20]++)@', $post->post_content, $matches );

			$tagnames = array_intersect( array_keys( $shortcode_tags ), $matches[1] );
			 
			if ( empty( $tagnames ) )
		        return false;

			$this->pattern_filter = get_shortcode_regex( $tagnames );
			$post->post_content = $this->do_filter_shortcode( $post->post_content );

		}
	}

	public function do_filter_shortcode( $content ){

		return preg_replace_callback( "/$this->pattern_filter/", array( &$this, 'do_shortcode_tag' ), $content );

	}

	public function do_shortcode_tag( $m ){

		global $mini;

		if ( $m[1] == '[' && $m[6] == ']' )
	        return substr($m[0], 1, -1);

	    $tag =  $m[2];

		$atts = shortcode_parse_atts( $m[3] );
		
		$closed = substr( $m[0], strlen( $m[0] ) - strlen( $tag ) - 3 );
		
		// If this shortcode has been disabled
		if( isset( $atts['disabled'] ) && $atts['disabled'] == 'on' )
			return '';

		// Move all custom css to header css
		if( isset( $atts['css'] ) ){

			$css = explode( '|', $atts['css'] );

			$atts['css'] = $css[0];

			if( isset( $css[1] ) && !empty( $css[1] ) && strpos( $this->css, '.'.$css[0].'{'.$css[1].'}' ) === false )
			{
				$this->css .= '.'.$css[0].'{'.$css[1].'}';
			}

		}

		if( is_array( $atts ) ){
			foreach( $atts as $k => $v ){
				
				if( is_string( $v ) ){
					if( $k == '__empty__' )
						$atts[$k] = '';
					else $atts[$k] = $mini->unesc( $v );
				}
				
			}
		}

		$atts['__name'] = $tag;

		if( strpos( $m[0], $tag.' #' ) !== false && isset( $atts[0] ) && strpos( $atts[0], '#' ) !== false ){
			// if multiple conteiner
			$atts['__name'] .= $atts[0];
		}

		if( $closed == '[/'.esc_attr( $tag ).']' ){
			
			if ( isset( $m[5] ) && !empty( $m[5] ) ) {
	
				// enclosing tag - extra parameter
				$atts['__content'] = $this->do_filter_shortcode( str_replace( array( '['.$tag.'#', '[/'.$tag.'#' ), array( '['.$tag.' #',  '[/'.$tag ), $m[5] ) );
	
			}else $atts['__content'] = '';
			
		}

		$new_atts = '';

		$new_atts = apply_filters( 'shortcode_'.$tag, $atts );

		if( !is_array( $new_atts ) )
			$new_atts = $atts;

		return $m[1] . $this->filter_return( $new_atts ) .$m[6];

	}

	public function filter_return( $atts ){

		$full = '['.$atts['__name'];

		foreach( $atts as $k => $v ){
			if( $k != '__name' && $k != '__content' )
				$full .= ' '.$k.'="'.esc_attr($v).'"';
		}

		$full .= ']';

		if( isset( $atts['__content'] ) ){

			$full .= $atts['__content'].'[/'.$atts['__name'].']';
		}

		return $full;

	}

	public function mini_front_head(){

		if( $this->allows ){

			?><script type="text/javascript">function mini_viewport(st){if(document.compatMode==='BackCompat'){if(st=='height')return document.body.clientHeight;else return document.body.clientWidth}else{if(st=='height')return document.documentElement.clientHeight;else return document.documentElement.clientWidth}}function mini_row_full(){[].forEach.call(document.querySelectorAll('div[data-mini-fullwidth]'),function(el){if(el.offsetWidth!=mini_viewport('width')){var elw=el.nextElementSibling,rect=elw.getBoundingClientRect(),width=mini_viewport('width'),css={'left':(-rect.left)+'px','width':width+'px'};for(var n in css)el.style[n]=css[n];if(el.getAttribute('data-mini-fullwidth')!='content'&&rect.left>0){el.style.paddingLeft=rect.left+'px';el.style.paddingRight=width-(rect.left+rect.width)+'px'}}});[].forEach.call(document.querySelectorAll('div[data-mini-fullheight]'),function(el){if(parseInt(el.style.minHeight,0)!=mini_viewport('height')){el.style.minHeight=mini_viewport('height')+'px'}})}<?php

			$this->render_dynamic_js();

			?></script><?php

			$this->render_dynamic_css();

		}
	}


	public function get_styles(){

		global $mini;
		$settings = $mini->settings();

		$styles = array(
			'mini-composer-general' => array(
				'src'     => str_replace( array( 'http:', 'https:' ), '', $this->mini_url ) . 'css/MiniComposer.css',
				'deps'    => '',
				'version' => MINI_VERSION,
				'media'   => 'all'
			),
			'mini-composer-shortcodes' => array(
				'src'     => str_replace( array( 'http:', 'https:' ), '', $this->mini_url ) . 'css/shortcodes.css',
				'deps'    => '',
				'version' => MINI_VERSION,
				'media'   => 'all'
			)
		);

		if( $settings['load_icon'] != 'no' )
		{
			$styles['mini-list-icons'] = array(
				'src'     => str_replace( array( 'http:', 'https:' ), '', $this->mini_url ) . '../css/icons.css',
				'deps'    => '',
				'version' => MINI_VERSION,
				'media'   => 'all'
			);
		}

		return apply_filters( 'mpb_enqueue_styles', $styles );

	}


	public function add_register_styles(){

		$this->register_style('mini-prettyPhoto', $this->vendor_script_url('prettyPhoto/css','prettyPhoto.css'));
		$this->register_style('mini-owl-theme', $this->vendor_script_url('owl-carousel','owl.theme.css'));
		$this->register_style('mini-owl-carousel', $this->vendor_script_url('owl-carousel','owl.carousel.css'));

	}

	public function load_scripts() {

		#Register vonder scripts

		$this->register_script('mini-owl-carousel', $this->vendor_script_url('owl-carousel','owl.carousel.min.js'));

		$this->register_script('mini-countdown-timer', $this->vendor_script_url('countdown','jquery.countdown.min.js'));

		$this->register_script('mini-viewportchecker', $this->vendor_script_url('viewportchecker','viewportchecker.js'));
		$this->register_script('mini-progress-bars', $this->mini_url. 'js/progress-bar.js');

		$this->register_script('mini-easypiechart', $this->mini_url. 'js/jquery.easypiechart.js');

		$this->register_script('mini-waypoints-min', $this->vendor_script_url('waypoints','waypoints.min.js'));
		$this->register_script('mini-counter-up', $this->mini_url. 'js/jquery.counterup.js');

		$this->register_script('mini-masonry-min', $this->vendor_script_url('masonry','jquery.masonry.min.js'));

		$this->register_script('mini-google-maps', 'https://maps.googleapis.com/maps/api/js?key=AIzaSyBCm5ryr0PKWzmwDoXlzGeMXvmgfJd8ARs&libraries=places');
		$this->register_script('mini-youtube-api', 'https://www.youtube.com/iframe_api');
		$this->register_script('mini-vimeo-api', 'https://f.vimeocdn.com/js/froogaloop2.min.js');
		$this->register_script('mini-video-play', $this->mini_url . 'js/mini-video-play.js');

		//lightbox script have to add latest
		$this->register_script('mini-prettyPhoto', $this->vendor_script_url('prettyPhoto/js','jquery.prettyPhoto.js') );

		$this->enqueue_script( 'mini-page-builder', $this->mini_url . 'js/MiniComposer.js' );

		if ( $enqueue_styles = $this->get_styles() )
		{
			foreach ( $enqueue_styles as $handle => $args ) {
				wp_enqueue_style( $handle, $args['src'], $args['deps'], $args['version'], $args['media'] );
			}
		}

	}

	public function body_classes( $classes ) {

		global $post;

		if( !empty( $post->ID ) )
		{
			$post_data = get_post_meta( $post->ID , 'mini_data', true );

			if( !empty( $post_data['classes'] ) )
				$classes[] = $post_data['classes'];
		}
        return $classes;

	}

	public function vendor_script_url($vendor_dir, $srcipt_file){
		return trailingslashit(MINI_URL).'includes/frontend/vendors/'.$vendor_dir.'/'.$srcipt_file;
	}

	private function register_script( $handle, $path, $deps = array( 'jquery' ), $version = MINI_VERSION, $in_footer = true ) {
		$this->scripts[] = $handle;
		wp_register_script( $handle, $path, $deps, $version, $in_footer );
	}

	private function register_style( $handle, $path, $deps = array(), $version = MINI_VERSION, $media = 'all' ) {
		$this->styles[] = $handle;
		wp_register_style( $handle, $path, $deps, $version, $media );
	}

	private function enqueue_script( $handle, $path = '', $deps = array( 'jquery' ), $version = MINI_VERSION, $in_footer = true ) {
		if ( ! in_array( $handle, $this->scripts ) && $path ) {
			$this->register_script( $handle, $path, $deps, $version, $in_footer );
		}
		wp_enqueue_script( $handle );
	}

	private function allowed_access(){

		global $mini;

		$settings = $mini->settings();


		if( !isset( $settings['content_types'] ) )
			$settings['content_types'] = array();

		$content_types = array_merge( (array)$settings['content_types'], (array)$mini->get_required_content_types() );

		$this->allows = is_singular( $content_types );

		return $this->allows;

	}

	private function render_dynamic_js(){
		if( !empty( $this->js ) )
			printf( $this->js );
	}

	public function add_header_js( $js = '' ){
		if( !empty( $js ) )
			$this->js .= $js;
	}

	public function add_header_css( $css = '' ){
		if( !empty( $css ) )
			$this->css .= $css;
	}

	private function render_dynamic_css(){

		global $post;

		$post_data = get_post_meta( $post->ID , 'mini_data', true );

		if( !empty( $post_data['css'] ) )
		{
			$this->css .= $post_data['css'];
		}

		// We dont need to filter css, because it has been done via shortcodes filter
		//$post->post_content = preg_replace_callback( '/ css="([^"]*)"/', array( &$this, 'preg_match_css' ) , $post->post_content );

		$this->css = str_replace(
						array( "\n","  ","	", ": ", " {", ">", "<" ),
						array( '', '', '', ':', '{', '', '' ),
						$this->css
					);

		$css = explode( '}', $this->css );
		$css_array = array();

		for( $i=0; $i < count( $css ) - 1 ; $i++ )
		{
			$css[$i] = $css[$i].'}';
			if( !in_array( $css[$i], $css_array ) )
			{
				array_push( $css_array, $css[$i] );
			}
		}

		$this->css = implode( '', $css_array );

		$this->css = preg_replace("/.mini-css-/", "body.mini_composer .mini-css-", $this->css);

		echo '<style type="text/css" id="mini-css-render">'.$this->css.'</style>';


	}

	public function preg_match_css( $matches ){

		if( !empty( $matches[1] ) ){

			if( strpos( $matches[1], '|' ) !== false ){

				$class = substr( $matches[1], 0, strpos( $matches[1], '|' ) );
				if( strpos( $this->css, '.'.$class.'{' ) === false )
				{
					$this->css .= '.'.$class.'{'.substr( $matches[1], strpos( $matches[1], '|' ) + 1 ).'}';
				}
				return ' css="'.$class.'"';
			}
			else
			{
				$this->css .= $matches[1];
				return '';
			}
		}
		else return $matches[0];

	}

}

/*
*-------------------------------
*/

global $mini_front;
$mini_front = new mini_front();
