<?php
/**
*
*	Mini Composer
*	(c) MiniComposer.com
*
*/
if(!defined('MINI_FILE')) {
	header('HTTP/1.0 403 Forbidden');
	exit;
}



/*
*	admin init
*/



add_action('admin_init', 'mini_admin_init');
function mini_admin_init() {

	if (get_option('mini_do_activation_redirect', false)) {

	    delete_option('mini_do_activation_redirect');

	    if( !isset($_GET['activate-multi']) )
	    	wp_redirect("admin.php?page=mini_composer");
	}
	/* register mini options */
	register_setting( 'mini_group', 'mini', 'mini_validate_options' );
	
	$roles = array( 'administrator', 'admin', 'editor' );

	foreach ( $roles as $role ) {
		if( ! $role = get_role( $role ) ) 
			continue;
		$role->add_cap( 'access_minicomposer'  );
	}
		

}


register_activation_hook( MINI_FILE, 'mini_plugin_activate' );
function mini_plugin_activate() {
	add_option('mini_do_activation_redirect', true);
}



/*
*	Load languages
*/



add_action('plugins_loaded', 'mini_load_lang');
function mini_load_lang() {
	load_plugin_textdomain( 'mini_composer', false, MINI_SLUG . '/locales/' );
}



/*
*	Register assets ( js, css, font icons )
*/


add_action('admin_enqueue_scripts', 'mini_assets', 1 );
function mini_assets(){

	wp_enqueue_style('mini-global', MINI_URL.'/assets/css/mini.global.css', false, MINI_VERSION );

	// Stop loading assets from admin if not in allows content type
	if( is_admin() && !mini_admin_enable() )
		return;

	wp_enqueue_style('mini-builder', MINI_URL.'/assets/css/mini.builder.css', false, MINI_VERSION );
	wp_enqueue_style('mini-params', MINI_URL.'/assets/css/mini.params.css', false, MINI_VERSION );
	wp_enqueue_style('mini-icons', MINI_URL.'/assets/css/icons.css', false, MINI_VERSION );

	wp_register_script( 'mini-builder-js', MINI_URL.'/assets/js/mini.builder.js', array('jquery'), MINI_VERSION, true );
	wp_enqueue_script( 'mini-builder-js' );

	foreach( array( 'tools', 'views', 'params', 'vendors/jscolor', 'vendors/pikaday', 'vendors/freshslider.min') as $key ){
		wp_register_script( 'mini-'.$key, MINI_URL.'/assets/js/mini.'.$key.'.js', null, MINI_VERSION, true );
		wp_enqueue_script( 'mini-'.$key );
	}

	wp_enqueue_media();
	wp_enqueue_style( 'wp-pointer' );

}



/**
*	Register filter for menu title
*/


function mini_filter_admin_menu_title( $menu_title ){

	$current = get_site_transient( 'update_plugins' );

    if ( ! isset( $current->response[ MINI_BASE ] ) )
		return $menu_title;

	return $menu_title . '&nbsp;<span class="update-plugins"><span class="plugin-count">1</span></span>';
}

add_filter( 'mini_admin_menu_title', 'mini_filter_admin_menu_title');


/*
*	Register settings page
*/


add_action('admin_menu', 'mini_settings_menu');
function mini_settings_menu() {
	
	$capability = apply_filters( 'access_minicomposer_capability', 'access_minicomposer' );
	$icon = MINI_URL.'/assets/images/icon_100x100.png';
	$menu_title = apply_filters( 'mini_admin_menu_title', __( 'Mini Composer' , 'mini_composer' ) );

	add_menu_page(
		 __( 'Mini Composer WP' , 'mini_composer' ),
		$menu_title,
		$capability,
		'mini_composer',
		'mini_main_page',
		$icon
	);

	remove_submenu_page( 'mini_composer', 'mini_composer' );

	add_submenu_page(
		'mini_composer',
		esc_html__('Mini Composer WP', 'mini_composer'),
		esc_html__('Mini Settings', 'mini_composer'),
		$capability,
		'mini_composer',
		'mini_main_page'
	);

	add_submenu_page(
		'mini_composer',
		esc_html__('Sections Manager - Mini Composer', 'mini_composer'),
		esc_html__('Sections Manager', 'mini_composer'),
		$capability,
		'mini-sections-manager',
		'mini_sections_manager'
	);

}



add_action( 'admin_head', 'mini_admin_header' );
add_action( 'edit_form_before_permalink', 'mini_edit_form_before_permalink' );
add_action( 'edit_form_after_editor', 'mini_after_editor' );
add_action( 'admin_footer', 'mini_admin_footer' );



/*
*	Header init
*/



function mini_admin_header(){

	if( is_admin() && !mini_admin_enable() )
		return;

	global $mini;
?>
<script type="text/javascript">

	var site_url = '<?php echo site_url(); ?>',
		plugin_url = '<?php echo MINI_URL; ?>',
		shortcode_tags = '<?php

			global $shortcode_tags;

			$arrg = array();
			$maps = $mini->get_maps();

			foreach( $maps as $key => $val ){
				array_push( $arrg, $key );
			}

			foreach( $shortcode_tags as $key => $val ){
				if( !in_array( $key, $arrg ) )
					array_push( $arrg, $key );
			}

			echo implode( '|', $arrg );

		?>',
		mini_ajax_url = "<?php echo site_url('/wp-admin/admin-ajax.php'); ?>",
		mini_profiles = <?php echo $mini->get_profiles_db( false ); ?>;
		mini_profiles_external = <?php echo json_encode( $mini->get_profile_sections(), true ); ?>;

</script>
<?php
}


/*
*	If editor actived for Mini, we will set default html mode
*/



function mini_edit_form_before_permalink( $post ) {

	if( !is_admin() || !mini_admin_enable() )
		return;

	if( !empty($_GET['post']) )
		$data = get_post_meta( $_GET['post'] , 'mini_data', true );

	if( isset( $data ) && isset( $data['mode'] ) && $data['mode'] == 'mini' )
		add_filter( 'wp_default_editor', function(){ return 'html'; } );

}


/*
*	Put post settings forms after editor
*/


function mini_after_editor( $post ) {

	if( !is_admin() || !mini_admin_enable() )
		return;
		
	?>
	<div style="display:none;" id="mini-post-settings">
		<?php
			
			$data = array( "mode" => "", "classes" => "", "css" => "" );
			
			if( isset( $post ) && isset( $post->ID ) && !empty( $post->ID ) ){
				$data = get_post_meta( $post->ID , 'mini_data', true );
				if( empty( $data ) ){
					$data = array( "mode" => "", "classes" => "", "css" => "" );
				}
			}

		?>
		<input type="hidden" name="mini[mode]" id="mini-post-mode" value="<?php echo esc_attr( $data['mode'] ); ?>" />
		<input type="hidden" name="mini[classes]" id="mini-page-body-classes" value="<?php echo esc_attr( $data['classes'] ); ?>" />
		<textarea id="mini-page-css-code" name="mini[css]" ><?php echo esc_attr( $data['css'] ); ?></textarea>
		<?php if( $data['mode'] == 'mini' ){ ?><style type="text/css">#postdivrich{display: none;}</style> <?php } ?>
		<script tyle="text/javascript">
			jQuery('#wp-content-editor-tools .wp-editor-tabs').append( '<button type="button" id="mini-switch-builder" class="wp-switch-editor">'+'<img src="'+plugin_url+'/assets/images/icon.png" width="20" /> Mini Composer</button>' );
		</script>
	</div>
	<?php

}



/*
*	Load builder template at footer
*/

function mini_admin_footer(){

	if( is_admin() && !mini_admin_enable() )
		return;

	do_action('mini_before_footer');
	require_once MINI_PATH.'/includes/mini.templates.php';
	require_once MINI_PATH.'/includes/mini.js_languages.php';
	do_action('mini_after_footer');
}


/*
*	Save post settings
*/


add_action( 'save_post', 'mini_process_save', 10, 2 );
function mini_process_save( $post_id, $post ) {

	if( !empty( $_POST['mini'] ) ){
		if( !add_post_meta( $post->ID , 'mini_data' , $_POST['mini'], true ) ){
			update_post_meta( $post->ID , 'mini_data' , $_POST['mini'] );
		}
	}else if( !isset( $_POST['action'] ) || ( isset( $_POST['action'] ) && $_POST['action'] != 'mini_instant_save' ) ){
		//delete_post_meta( $post->ID , 'mini_data' );
	}

}

/*
*	Include admin pages' file
*/


function mini_main_page() {

	require_once MINI_PATH.MDS.'includes'.MDS.'mini.settings.php';

}

function mini_sections_manager() {

	require_once MINI_PATH.MDS.'includes'.MDS.'mini.sections.php';

}
