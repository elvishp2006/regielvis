<?php

/*
 * Remove __empty__ code value
 */
function mini_remove_empty_code( $atts ){

	$atts_tmp = array();

	foreach( $atts as $key => $value ){
		if('__empty__' === $value){
			$atts_tmp[$key] = '';
		}else{
			$atts_tmp[$key] = $value;
		}
	}

	return $atts_tmp;
}


//Row filter
function mini_row_filter( $atts ){

	// Do your code here
	global $mini_front;

	if( isset( $atts['video_bg'] ) && $atts['video_bg'] == 'yes' ){
		wp_register_script('mini-youtube-iframe-api', 'https://www.youtube.com/iframe_api', null, MINI_VERSION, true );
		wp_enqueue_script('mini-youtube-iframe-api');
	}

	return $atts;

}

//Tab filter
function mini_tab_filter( $atts = array() ){

	// Do your code here
	global $mini_front, $mini_tab_id;

	if( empty($mini_tab_id) )
		$mini_tab_id = array();

	$i = 1; $_title = sanitize_title( !empty( $title ) ? $title : 'mini-tab' );
	while( in_array( $_title, $mini_tab_id ) )
	{
		$i++;
		$_title = sanitize_title( !empty( $title ) ? $title : 'mini-tab' ).$i;
	}

	array_push( $mini_tab_id, $_title );

	$atts['tab_id'] = $_title;

	return $atts;

}

/*
 * Mini Box shortcode custom css
 */
function mini_box_filter(  $atts = array() ){

	global $mini_front;
	$css = '';

	$atts = mini_remove_empty_code( $atts );
	extract( $atts );

	if(!empty($css)){
		$mini_front->add_header_css($css);
	}

	return $atts;
}


/*
 * Google maps shortcode custom css
 */
function mini_google_maps_filter( $atts = array() ){

	global $mini_front;

	$atts 					= mini_remove_empty_code( $atts );
	extract( $atts );

	$contact_area_bg 		= ( !empty( $contact_area_bg ) )? $contact_area_bg : 'rgba(42,42,48,0.95)';
	$contact_form_color 	= ( !empty($contact_form_color ) )? $contact_form_color : '#FFFFFF';
	$submit_button_color 		= ( !empty( $submit_button_color ) )? $submit_button_color : '#393939';
	$submit_button_hover_color 		= ( !empty( $submit_button_hover_color ) )? $submit_button_hover_color : '#575757';
	$submit_button_text_color 		= ( !empty( $submit_button_text_color ) )? $submit_button_text_color : '#FFFFFF';
	$submit_button_text_hover_color 		= ( !empty( $submit_button_text_hover_color ) )? $submit_button_text_hover_color : '#FFFFFF';

	$custom_class 			= 'map_' . mini_random_string( 10 );
	$atts[ 'custom_class' ] = $custom_class;
	$contact_area_width 	= ( !empty($contact_area_width) )? $contact_area_width : '40%';

	//if is not rgba color, convert it with default 0.85 for opacity
	if( strpos( $contact_area_bg, 'rgba' ) === false )
	{
		$contact_area_bg = mini_hex2rgba( $contact_area_bg, 0.85 );
	}

	//custom CSS
	$custom_style = "
		.$custom_class .map_popup_contact_form{
			background	: $contact_area_bg;
			color		: $contact_form_color;
			width		: $contact_area_width;
		}
		.$custom_class .show_contact_form{
			background	: $contact_area_bg;
			color		: #fff;
		}
		.$custom_class .map_popup_contact_form .wpcf7-submit{
			background	: $submit_button_color;
		    border		: 1px solid $submit_button_color;
			color		: $submit_button_text_color;
		}
		.$custom_class .map_popup_contact_form .wpcf7-submit:hover{
			background	: $submit_button_hover_color;
		    border		: 1px solid $submit_button_hover_color;
			color		: $submit_button_text_hover_color;
		}

	";

	$mini_front->add_header_css($custom_style);

	return $atts;

}


/*
 * Pie chart shortcode custom css
 */
function mini_pie_chart_filter( $atts = array() ){

	global $mini_front;

	$atts = mini_remove_empty_code( $atts );
	extract( $atts );

	$custom_class = 'piechart_'.mini_random_string(10);
	$atts['custom_class'] = $custom_class;

	$label_color = !empty($label_color)? $label_color : '#FF5252';
	$label_font_size = !empty($label_font_size)? intval($label_font_size) : 20;

	$custom_style = "
		.$custom_class span.percent{
			font-size	: {$label_font_size}px;
			color		: {$label_color};
		}
	";

	$mini_front->add_header_css($custom_style);

	return $atts;
}


/*
 * Progress bar shortcode custom css
 */
function mini_progress_bars_filter( $atts = array() ){

	global $mini_front;

	$atts = mini_remove_empty_code( $atts );
	extract( $atts );

	$custom_class = 'button_'.mini_random_string(10);
	$atts['custom_class'] = $custom_class;

	$custom_style = "";

	$mini_front->add_header_css($custom_style);

	return $atts;
}


/*
 * Image gallery shortcode custom css
 */
function mini_image_gallery( $atts = array() ){

	global $mini_front;

	$atts = mini_remove_empty_code( $atts );
	extract( $atts );

	$custom_class = 'button_'.mini_random_string(10);
	$atts['custom_class'] = $custom_class;

	$custom_style = "";

	$mini_front->add_header_css($custom_style);

	return $atts;
}


/*
 * Button shortcode custom css
 */
function mini_button_filter( $atts = array() ){

	global $mini_front;

	$atts = mini_remove_empty_code( $atts );
	extract( $atts );

	$custom_class = 'button_'.mini_random_string(10);
	$atts['custom_class'] = $custom_class;

	$bg_color = isset($bg_color)?$bg_color:'#393939';
	$text_color = isset($text_color)?$text_color:'#FFFFFF';
	$border_radius = isset($border_radius)?$border_radius:3;

	$bg_color_hover = isset($bg_color_hover)?$bg_color_hover:'#FFFFFF';
	$text_color_hover = isset($text_color_hover)?$text_color_hover:'#393939';

	$custom_style = "
	body .$custom_class{
		background-color: $bg_color;
		color			: $text_color;
		border-radius	: ". intval($border_radius) ."px;
		Border			: 1px solid $bg_color;
	}

	body .$custom_class:hover{
		background-color: $bg_color_hover;
		color			: $text_color_hover;
		Border			: 1px solid $text_color_hover;
	}
	";

	$mini_front->add_header_css($custom_style);

	return $atts;
}


/*
 * Flipbox shortcode custom css
 */
function mini_flip_box_filter( $atts = array() ){

	global $mini_front;

	$atts = mini_remove_empty_code( $atts );
	extract( $atts );

	$bg_backside 				= !empty($bg_backside)? $bg_backside: '#86c724';
	$text_color 				= !empty($text_color)? $text_color: '#FFFFFF';
	$button_bg_color 			= !empty($button_bg_color)? $button_bg_color: 'transparent';
	$text_button_color 			= !empty($text_button_color)? $text_button_color: '#FFFFFF';
	$button_bg_hover_color 		= !empty($button_bg_hover_color)? $button_bg_hover_color: '#FFFFFF';
	$text_button_color_hover 	= !empty($text_button_color_hover)? $text_button_color_hover: '#86c724';
	$text_align 				= !empty($text_align)?$text_align:'center';

	$custom_class = 'flipbox_'.mini_random_string(10);
	$atts['custom_class'] = $custom_class;

	$custom_style = "
		.$custom_class .back{
			background-color: $bg_backside;
			color			: $text_color;
			text-align		: $text_align;
		}
	";

	if('transparent' === $button_bg_color){
		$custom_style .="
			.$custom_class .des a.button{
				background-color: $button_bg_color;
				color			: $text_button_color;
				border			: 2px solid $text_button_color;
			}
		";
	}else{
		$custom_style .="
			.$custom_class .des a.button{
				background-color: $button_bg_color;
				color			: $text_button_color;
				border			: 2px solid $button_bg_color;
			}
		";
	}

	$custom_style .="
		.$custom_class .des a.button:hover{
			background-color: $button_bg_hover_color;
			color			: $text_button_color_hover;
			border			: 2px solid $button_bg_hover_color;
		}
	";

	$mini_front->add_header_css($custom_style);

	return $atts;
}


/*
 * Twitter feed shortcode custom css
 */
function mini_twitter_feed_filter( $atts = array() ){

	global $mini_front;

	$atts = mini_remove_empty_code( $atts );
	extract( $atts );

	$custom_class = 'twitter_'.mini_random_string(10);
	$atts['custom_class'] = $custom_class;

	$color_icon = !empty($color_icon)?$color_icon:'#2686cc';
	$link_color = !empty($link_color)?$link_color:'';
	$link_color_hover = !empty($link_color_hover)?$link_color_hover:'';

	if( isset( $display_style ) && '2' === $display_style ){
		wp_enqueue_script( 'mini-owl-carousel' );
		wp_enqueue_style( 'mini-owl-theme' );
		wp_enqueue_style( 'mini-owl-carousel' );
	}

	$custom_style = "
		.$custom_class a{
			color: $link_color;
		}

		.$custom_class a:hover{
			color: $link_color_hover;
		}

		.$custom_class .mini_tweet_icon i{
			color: $color_icon;
		}
	";

	$mini_front->add_header_css($custom_style);

	return $atts;
}


function mini_counter_box_filter( $atts = array() ){

	global $mini_front;

	//Set default color
	$number_color = $label_color = $icon_color = '#393939';
	$box_bg_color = 'transparent';

	$atts = mini_remove_empty_code( $atts );
	extract( $atts ); //Convert all attributes param to variable value from attributes shortcode

	if( empty($box_bg_color) && '2' === $style){
		$box_bg_color = '#d9d9d9';
	}

	if('transparent' != $box_bg_color && strpos($box_bg_color, 'rgba') === false){
		$box_bg_color = mini_hex2rgba($box_bg_color, 0.85);
	}

	$custom_class = 'counter_box_'.mini_random_string(10);
	$atts['custom_class'] = $custom_class;

	$custom_style = "
		.$custom_class{
			background: $box_bg_color;
		}

		.$custom_class span.counterup{
			color: $number_color;
		}

		.$custom_class h4{
			color: $label_color;
		}

		.$custom_class i{
			color: $icon_color;
		}
	";

	$mini_front->add_header_css($custom_style);

	return $atts;
}


function mini_video_play_filter( $atts = array() ){

	$atts = mini_remove_empty_code( $atts );
	extract( $atts );

	return $atts;
}


function mini_carousel_post_filter( $atts = array() ){

	$atts = mini_remove_empty_code( $atts );
	extract( $atts );

	wp_enqueue_script( 'mini-owl-carousel' );
	wp_enqueue_style( 'mini-owl-theme' );
	wp_enqueue_style( 'mini-owl-carousel' );

	return $atts;
}


function mini_carousel_images_filter( $atts = array() ){

	$atts = mini_remove_empty_code( $atts );
	extract( $atts );

	wp_enqueue_script( 'mini-owl-carousel' );
	wp_enqueue_style( 'mini-owl-theme' );
	wp_enqueue_style( 'mini-owl-carousel' );

	if( isset( $onclick ) && $onclick == 'lightbox' ){
		wp_enqueue_script( 'mini-prettyPhoto' );
		wp_enqueue_style( 'mini-prettyPhoto' );
	}

	return $atts;
}


function mini_image_gallery_filter( $atts = array() ){

	$atts = mini_remove_empty_code( $atts );
	extract( $atts );

	if( !isset( $type ) || empty( $type ) )
		$type = 'grid';

	switch( $type ){

		case 'slider' :

			wp_enqueue_script( 'mini-owl-carousel' );
			wp_enqueue_style( 'mini-owl-theme' );
			wp_enqueue_style( 'mini-owl-carousel' );

			break;

		default :

			if( isset( $image_masonry ) && $image_masonry == 'yes' ){
				wp_enqueue_script( 'mini-masonry-min' );
			}

			if( isset( $click_action ) && 'lightbox' === $click_action ){
				wp_enqueue_script( 'mini-prettyPhoto' );
				wp_enqueue_style( 'mini-prettyPhoto' );
			}

			break;
	}

	return $atts;
}
