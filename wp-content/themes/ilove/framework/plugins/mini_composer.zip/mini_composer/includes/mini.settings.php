<?php
/**
*
*	Mini Composer
*	(c) MiniComposer.com
*
*/

if(!defined('ABSPATH')) {
	header('HTTP/1.0 403 Forbidden');
	exit;
}

	global $mini;
	$settings = $mini->settings();
	$plugin_info = get_plugin_data( MINI_FILE );
	
?>
<style type="text/css">
	#mini-settings  div.group input[type="text"],
	#mini-settings  div.group input[type="password"]{
		height: 35px;
		box-shadow: none;
		display: block;
		margin-bottom: 5px;
		padding-left: 10px;
	}
	#mini-settings div.mini-badge{
		background-image: url('<?php echo MINI_URL; ?>/assets/images/logo_white.png');
		color: #dedede;
	}
	#mini-settings div.p{
		padding-left: 10px; 
		padding-top:15px;
		display: block;
	}
	#mini-settings .button-large{
		height: 35px;
		line-height: 35px;
		padding-left: 20px;
		padding-right: 20px;
		font-weight: bold;
	}	
	#mini-settings p.radio{
		cursor: pointer;
	}
	.mini-notice{
	    background: rgb(253, 255, 196);
	    display: inline-block;
	    width: 100%;
	    border-radius: 2px;
	    margin: 20px 0;
	    box-shadow: 0 0 1px 0 rgba(0,0,0,0.2);
	}
	.mini-notice p{
		padding: 10px 20px;
		margin: 0px;
	}	
</style>
<div id="mini-settings" class="wrap about-wrap">
	<h1><?php _e('Welcome to', 'mini_composer'); ?> MiniComposer <?php echo esc_attr( $plugin_info['Version'] ); ?></h1>
	<div class="about-text">
		<?php _e('We don\'t know somehow you are here, We just want to say Thank You so much!', 'mini_composer'); ?>
	</div>
	<div class="wp-badge mini-badge">
		<?php _e('Version', 'mini_composer'); ?> <?php echo esc_attr( $plugin_info['Version'] ); ?>
	</div>
	<h2 class="nav-tab-wrapper">
		<a href="#mini_general_setting" class="nav-tab nav-tab-active" id="mini_general_setting-tab">
			<?php _e('General Settings', 'mini_composer'); ?>
		</a>
		<a href="#mini_product_license" class="nav-tab" id="mini_product_license-tab">
			<?php _e('Plugin Update', 'mini_composer'); ?>
		</a>
		<!--a href="<?php echo admin_url(); ?>/admin.php?page=mini-sections-manager" class="nav-tab">
			<?php _e('Sections Manager', 'mini_composer'); ?>
		</a-->
		<!--a href="#mini_about_us" class="nav-tab" id="mini_about_us-tab">
			<?php _e('About Us', 'mini_composer'); ?>
		</a-->
	</h2>
	<form method="post" action="options.php" enctype="multipart/form-data" id="mini-settings-form">
		<?php settings_fields( 'mini_group' ); ?>
		<div id="mini_general_setting" class="group p">
			<?php
				
				$update_plugin = get_site_transient( 'update_plugins' );

			    if ( isset( $update_plugin->response[ MINI_BASE ] ) )
				{
			?>
			<div class="mini-notice">
				<p>
					<i class="dashicons dashicons-warning"></i> 
					<?php
						printf( __('There is a new version of MiniComposer available, please go to %s to update', 'mini_composer'),	
							'<a href="'.admin_url('/plugins.php').'">Plugins</a>'
						); ?>.
				</p>
			</div>
			<?php			
				}
			?>
			<table class="form-table">
				<tbody>
					<tr>
						<th scope="row">
							<?php _e('Support Content Types', 'mini_composer'); ?>:
						</th>
						<td>
							<?php
								
								$post_types = get_post_types( array( 'public' => true ) );
								$ignored_types = array('attachment');
								$settings_types = $mini->get_content_types();
								$required_types = $mini->get_required_content_types();
			
								foreach( $post_types as $type ){
									if( !in_array( $type, $ignored_types ) ){
										echo '<p class="radio"><input ';
										if( in_array( $type, $settings_types ) )
											echo 'checked ';
										if( in_array( $type, $required_types ) )
											echo 'disabled ';	
										echo'type="checkbox" name="mini[content_types][]" value="'.esc_attr($type).'"> ';
										echo esc_html( $type );
										if( in_array( $type, $required_types ) )
											echo ' <i>(required)</i>';
										echo '</p>';
									}
								}
								
							?>
							
							<br />
							<span class="description">
								<p>
									- <?php _e('Which content types will available with Mini Composer', 'mini_composer'); ?>. 
								</p>
								<p>
									- <strong>"Custom Post-Type"</strong> 
									<?php _e('does not show here? Please make sure the', 'mini_composer'); ?> 
									<strong>"custom post-type"</strong> 
									<?php _e('has been registered with', 'mini_composer'); ?> 
									<strong>"public = true"</strong>
								</p>
								<p>
									- <?php _e('Put this code on action "init" to force support', 'mini_composer'); ?>:  
									<strong>global $mini; $mini->add_content_type( 'your-post-type-name' );</strong>
								</p>
							</span>
						</td>
					</tr>

					<tr>
						<th scope="row">
							<?php _e('Load Icons on Front-End', 'mini_composer'); ?>:
						</th>
						<td>
							<input type="radio" name="mini[load_icon]" <?php if($settings['load_icon']!='no')echo 'checked'; ?>  value="yes" /> 
							<?php _e('Yes, Please!', 'mini_composer'); ?>
							&nbsp; &nbsp; <input type="radio" name="mini[load_icon]" <?php if($settings['load_icon']=='no')echo 'checked'; ?>   value="no" /> 
							<?php _e('No, Thanks!', 'mini_composer'); ?>
							<span class="description">
								<p>
									<br />
									<?php _e('We use 3 icons package', 'mini_composer'); ?>:
								</p>	
								<ol>
									<li>
										<a href="http://fortawesome.github.io/Font-Awesome/icons/" target=_blank>
											Font Awesome Icons
										</a>
										 <?php _e('Useage', 'mini_composer'); ?> : 
										 <strong>&lt;i class="fa-search"&gt;&lt;/i&gt;</strong> 
									</li>
									<li>
										<a href="http://rhythm.nikadevs.com/content/icons-et-line" target=_blank>
											ET Line Icons
										</a>
										 <?php _e('Useage', 'mini_composer'); ?> : 
										 <strong>&lt;i class="et-search"&gt;&lt;/i&gt;</strong> 
									</li>
									<li>
										<a href="http://thesabbir.github.io/simple-line-icons/" target=_blank>
											Simple Line Icons
										</a>
										 <?php _e('Useage', 'mini_composer'); ?> :  
										 <strong>&lt;i class="sl-search"&gt;&lt;/i&gt;</strong>
									</li>
								</ol>
								<p>
									<?php _e('Please note: If you disable icons, All icon elements on front-end will not display', 'mini_composer'); ?>.
								</p>
							</span>
						</td>
					</tr>
					
					<tr>
						<th scope="row">
							<?php _e('Css Code', 'mini_composer'); ?>:
						</th>
						<td>
							<textarea name="mini[css_code]" cols="100" rows="15"><?php 
								echo esc_html( $settings['css_code'] ); 
							?></textarea>
							<span class="description">
								<p>
									<?php _e('Add your custom CSS code to work on Front-End', 'mini_composer'); ?>. 
								</p>
							</span>
						</td>
					</tr>
				</tbody>
			</table>
			<br />
			<p class="submit">
				<input type="submit" class="button button-large button-primary" value="<?php _e('Save Change', 'mini_composer'); ?>" />
    		</p>		
		</div>
		<div id="mini_product_license" class="group p" style="display:none">
			<?php
			    if ( isset( $update_plugin->response[ MINI_BASE ] ) )
				{
			?>
			<div class="mini-notice">
				<p>
					<i class="dashicons dashicons-warning"></i> 
					<?php
						printf( __('After submitting license informations, please go to %s to update', 'mini_composer'),	
							'<a href="'.admin_url('/plugins.php').'">Plugins</a>'
						); ?>.
				</p>
			</div>
			<?php			
				}	
			?>
			<table class="form-table">
				<tbody>
					<tr>
						<th scope="row">
							<?php _e('Envato Username', 'mini_composer'); ?>:
						</th>
						<td>
							<input type="text" class="regular-text" name="mini[envato_username]" value="<?php echo esc_attr( $settings['envato_username'] ); ?>" />
							<span class="description">
							<p>
								<?php _e('Enter your Envato username.', 'mini_composer'); ?>
							</p>		
						</td>
					</tr>
					<tr>
						<th scope="row">
							<?php _e('Secret API Key', 'mini_composer'); ?>:
						</th>
						<td>
							<input type="password" class="regular-text" name="mini[api_key]" value="<?php echo esc_attr( $settings['api_key'] ); ?>" />
							<span class="description">
							<p>
								<?php _e('Enter your Secret API Key', 'mini_composer'); ?>. 
								<a href="http://minicomposer.com/documentation/how-to-get-api-key/" target=_blank>
									<?php _e('How to find API Key', 'mini_composer'); ?>?
								</a>
							</p>	
						</td>
					</tr>
					<tr>
						<th scope="row">
							<?php _e('MiniComposer License Key', 'mini_composer'); ?>:
						</th>
						<td>
							<input onchange="document.getElementById('mini-stt-theme-key').value=''" id="mini-stt-plugin-key" type="text" class="regular-text" name="mini[license_key]" value="<?php echo esc_attr( $settings['license_key'] ); ?>" />
							<span class="description">
							<p>
								<?php _e('Enter Mini Composer license key from CodeCanyon', 'mini_composer'); ?>. 
								<a href="http://minicomposer.com/documentation/how-to-find-purchase-code/" target=_blank>
									<?php _e('How to find Purchase Code', 'mini_composer'); ?>?
								</a>
							</p>
							<br />
						</td>
					</tr>
					<tr style="border: 1px dashed #aaa;">
						<th scope="row">
							<br />
							&nbsp; &nbsp; &nbsp; 
							<?php _e('Theme Purchase Code', 'mini_composer'); ?>:
						</th>
						<td>
							<br />
							<input onchange="document.getElementById('mini-stt-plugin-key').value=''" id="mini-stt-theme-key" type="text" class="regular-text" name="mini[theme_key]" value="<?php echo esc_attr( $settings['theme_key'] ); ?>" />
							<span class="description">
							<p>
								<?php _e('If you\'ve bought a theme which was included MiniComposer, You can use the Purchase Code of the theme to update MiniComposer', 'mini_composer'); ?>. <br />
								<a href="http://minicomposer.com/documentation/how-to-find-theme-purchase-code/" target=_blank>
									<?php _e('How to find Theme Purchase Code', 'mini_composer'); ?>?
								</a>
							</p>
							<br />	
						</td>
					</tr>
				</tbody>
			</table>
			<br />
			<p class="submit">
				<input type="submit" class="button button-large button-primary" value="<?php _e('Save Change', 'mini_composer'); ?>" />
    		</p>			
		</div>
		<div id="mini_about_us" class="group p" style="display:none">
			About Us
		</div>	
		
	</form>
</div>

<script>
    jQuery(document).ready(function($) {
        $('.nav-tab-wrapper a').on( 'click', function(e) {
	        var clicked = $(this).attr('href');
	        if( clicked.indexOf('#') == -1 )
	        	return true;
            $('.nav-tab-wrapper a').removeClass('nav-tab-active');
            $(this).addClass('nav-tab-active').blur();
            $('.group').hide();
            $(clicked).fadeIn();
            if (typeof(localStorage) != 'undefined' ) {
                localStorage.setItem('activeTab', clicked );
            }
            e.preventDefault();
        });
        $('p.radio').on('click',function(e){
	        if( e.target.tagName != 'INPUT' ){
	        	var inp = $(this).find('input').get(0);
	        	if( inp.disabled == true )
		        	e.preventDefault();
				else if( inp.checked == true )
	        		inp.checked = false;
	        	else inp.checked = true;	
	        }	
        });
        if (typeof(localStorage) != 'undefined' ) {
            activeTab = localStorage.getItem('activeTab');
            if( activeTab != undefined ){
	            $('.nav-tab-wrapper a[href='+activeTab+']').trigger('click');
            }
        }
        if(window.location.href.indexOf('#')>-1)
        	$('.nav-tab-wrapper a[href=#'+window.location.href.split('#')[1]+']').trigger('click');
    });
</script>