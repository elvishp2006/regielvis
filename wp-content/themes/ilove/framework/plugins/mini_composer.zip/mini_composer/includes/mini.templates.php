<?php
/**
*
*	Mini Composer
*	(c) MiniComposer.com
*
*/
if(!defined('MINI_FILE')) {
	header('HTTP/1.0 403 Forbidden');
	exit;
}
	
global $mini;
	
?>
<script type="text/html" id="tmpl-mini-container-template">
	<div id="mini-container" <# if( mini.cfg.showTips == 0 ){ #>class="hideTips"<# } #>>
		<div id="minicontrols">
			<button class="button button-large red classic-mode">
				<i class="sl-action-undo"></i> 
				<?php _e('Classic Mode', 'mini_composer'); ?>
			</button>
			<button class="button button-large alignright post-settings">
				<i class="sl-settings"></i> <?php _e('Content Settings', 'mini_composer'); ?>
			</button>
			<span class="alignright inss" <# if( mini.cfg.instantSave == 0 ){ #>style="display: none;"<# } #>>
				<?php _e('Press Ctrl + S to quick save', 'mini_composer'); ?>
			</span>
		</div>
		
		<div id="mini-rows"></div>
		
		<div id="minifooters">
			<ul>
				<li class="basic-add">
					<span class="m-a-tips"><?php _e('Browse all elements', 'mini_composer'); ?></span>
				</li>
				<li class="one-column quickadd" data-content='[mini_row use_container="yes"][/mini_row]'>
					<span class="grp-column"></span>
					<span class="m-a-tips"><?php _e('Add an 1-column row', 'mini_composer'); ?></span>
				</li>
				<li class="two-columns quickadd" data-content='[mini_row use_container="yes"][mini_column width="6/12"][/mini_column][mini_column width="6/12"][/mini_column][/mini_row]'>
					<span class="grp-column"></span>
					<span class="grp-column"></span>
					<span class="m-a-tips"><?php _e('Add a 2-column row', 'mini_composer'); ?></span>
				</li>
				<li class="three-columns quickadd" data-content='[mini_row use_container="yes"][mini_column width="4/12"][/mini_column][mini_column width="4/12"][/mini_column][mini_column width="4/12"][/mini_column][/mini_row]'>
					<span class="grp-column"></span>
					<span class="grp-column"></span>
					<span class="grp-column"></span>
					<span class="m-a-tips"><?php _e('Add a 3-column row', 'mini_composer'); ?></span>
				</li>
				<li class="four-columns quickadd" data-content='[mini_row use_container="yes"][mini_column width="3/12"][/mini_column][mini_column width="3/12"][/mini_column][mini_column width="3/12"][/mini_column][mini_column width="3/12"][/mini_column][/mini_row]'>
					<span class="grp-column"></span>
					<span class="grp-column"></span>
					<span class="grp-column"></span>
					<span class="grp-column"></span>
					<span class="m-a-tips"><?php _e('Add a 4-column row', 'mini_composer'); ?></span>
				</li>
				<li class="column-text quickadd" data-content="custom">
					<i class="et-document"></i>
					<span class="m-a-tips"><?php _e('Push customized content and shortcodes', 'mini_composer'); ?></span>
				</li>
				<li class="title quickadd" data-content='paste'>
					<i class="et-clipboard"></i>
					<span class="m-a-tips"><?php _e('Paste copied element', 'mini_composer'); ?></span>
				</li>
				<li class="mini-add-sections">
					<i class="et-lightbulb"></i> 
					<?php _e('Sections Manager', 'mini_composer'); ?>
					<span class="m-a-tips"><?php _e('Installation of sections which were added', 'mini_composer'); ?></span>
				</li>
			</ul>
		</div>
		
	</div>	
</script>
<script type="text/html" id="tmpl-mini-components-template">
	<div id="mini-components">
		<ul class="mini-components-categories">
			<li data-category="all" class="all active"><?php _e('All Elements', 'mini_composer'); ?></li>
			<?php
				
				$maps = $mini->get_maps();
				$categories = array();
				
				foreach( $maps as $key => $map )
				{
					$category = isset( $map['category'] ) ? $map['category'] : '';
					if( !in_array( $category, $categories ) && $category != '' )
					{
						array_push( $categories, $category );
						echo '<li data-category="'.sanitize_title($category).'" class="'.sanitize_title($category).'">';
						echo esc_html($category);
						echo '</li>';
					}
				}
			?>
			<li data-category="mini-wp-widgets" class="mini-wp-widgets mcl-wp-widgets">
				<i class="fa-wordpress"></i> <?php _e('Widgets', 'mini_composer'); ?>
			</li>
			<li data-category="mini-clipboard" class="mini-clipboard mcl-clipboard">
				<i class="et-layers"></i> <?php _e('Clipboard', 'mini_composer'); ?>
			</li>
		</ul>
		<ul class="mini-components-list-main mini-components-list">
			<?php
				foreach( $maps as $key => $map )
				{
					if( !isset( $map['system_only'] ) )
					{
						$category = isset( $map['category'] ) ? $map['category'] : '';
						$name = isset( $map['name'] ) ? $map['name'] : '';
						$icon = isset( $map['icon'] ) ? $map['icon'] : '';
					?>
						<li <?php
								if( isset( $map['description'] ) && !empty( $map['description'] ) ){
									echo 'title="'."\n ".esc_attr( $map['description'] )." \n".'"';
								}
							?> data-category="<?php echo sanitize_title($category); ?>" data-name="<?php echo esc_attr( $key ); ?>" class="mcpn-<?php echo sanitize_title($category); ?>">
							<div>
								<span class="cpicon <?php echo esc_attr( $icon ); ?>"></span>
								<span class="cpdes">
									<strong><?php echo esc_html( $name ); ?></strong>
								</span>
							</div>
						</li>
					<?php
					}	
				}	
			?>
		</ul>
	</div>
</script>
<script type="text/html" id="tmpl-mini-clipboard-template">
	<div id="mini-clipboard">
		<ul class="ms-funcs">
			<li class="delete button delete left">
				<?php _e('Delete selected items', 'mini_composer'); ?> <i class="sl-close"></i>
			</li>
			<li class="select button left">
				<?php _e('Select all items', 'mini_composer'); ?> <i class="sl-check"></i>
			</li>
			<li class="unselect button left ">
				<?php _e('Unselect all items', 'mini_composer'); ?> <i class="sl-close"></i>
			</li>
			<li class="latest button prime">
				<?php _e('Paste latest item', 'mini_composer'); ?> <i class="sl-clock"></i>
			</li>
			<li class="paste button">
				<?php _e('Paste selected items', 'mini_composer'); ?> <i class="sl-check"></i>
			</li>
			<li class="pasteall button">
				<?php _e('Paste all items', 'mini_composer'); ?> <i class="sl-list"></i>
			</li>
		</ul>
		<#
		try{
			var clipboards = mini.backbone.stack.get( 'miniClipBoard' ), 
				outer = '<div style="text-align:center;margin:20px auto;"><?php _e('The ClipBoard is empty, Please copy elements to clipboard', 'mini_composer'); ?>.</div>';
			
			if( clipboards.length > 0 ){
				
				var stack, map, li = '';
					
				for( var n in clipboards ){
					if( clipboards[n] != null && clipboards[n] != undefined ){
						
						stack = clipboards[n];
						map = mini.maps[stack.title];
						
						li += '<li data-sid="'+n+'" title="Copy from page: '+stack.page+'">';
						if( map != undefined ){
							if( map['icon'] != undefined )
								li += '<span class="ms-icon cpicon '+map['icon']+'"></span>';
						}
						li += '<span class="ms-title">'+stack.title.replace(/\_/g,' ').replace(/\-/g,' ')+'</span>';
						li += '<span class="ms-des">'+mini.tools.unesc(stack.des)+'</span>';
						li += '</li>';
						
					}
				}
				
			}
		}catch(e){console.log(e);}	
		#>
		<ul class="ms-list">{{{li}}}</ul>
		<br />
		<span class="ms-tips">
			<strong><?php _e('Tips', 'mini_composer'); ?>:</strong> 
			<?php _e('Drag and drop to arrange items, click to select an item. Read more', 'mini_composer'); ?> 
			<a href="<?php echo esc_url('http://minicomposer.com/documentation/copy-cut-double-paste-for-element-column-row/?source=client_installed'); ?>" target="_blank"><?php _e('Document', 'mini_composer'); ?></a>
		</span>
	</div>
	<# 
		data.callback = mini.ui.clipboard;
	#>
</script>
<script type="text/html" id="tmpl-mini-post-settings-template">
	<div id="mini-page-settings">
		<h1 class="mgs-t02">
			<?php _e('Page Settings', 'mini_composer'); ?>
		</h1>
		<button class="button pop-btn save-post-settings"><?php _e('Save', 'mini_composer'); ?></button>
		<div class="m-settings-row">
			<div class="msr-left">
				<label><?php _e('Body Class', 'mini_composer'); ?></label>
				<span><?php _e('The class will be added to body tag on the front-end', 'mini_composer'); ?> </span>
			</div>
			<div class="msr-right">
				<div class="msr-content">
					<input class="mini-post-classes-inp" type="text" placeholder="Body classes" value="{{data.classes}}" />
				</div>
			</div>
		</div>
		<div class="m-settings-row">
			<div class="msr-left msr-single">
				<label><?php _e('Css Code', 'mini_composer'); ?></label>
				<button class="button button-larger css-beautifier float-right">
					<i class="sl-energy"></i> <?php _e('Beautifier', 'mini_composer'); ?>
				</button>
				<textarea class="rt03 mini-post-css-inp">{{data.css}}</textarea>
				<i><?php _e('Notice: CSS must contain selectors', 'mini_composer'); ?></i>
			</div>
		</div>
		
		<div class="m-settings-row">
			<div class="msr-left">
				<label><?php _e('Scroll Assistant', 'mini_composer'); ?></label>
				<span>
					<?php _e('Keep the viewport in a reasonable place while a popup is opened', 'mini_composer'); ?>.
				</span>
			</div>
			<div class="msr-right">
				<div class="msr-content">
					<div class="mini-el-ui meu-boolen" data-cfg="scrollAssistive" data-type="radio" onclick="mini.ui.elms(event,this)">
						<ul>
							<li<# if(mini.cfg.scrollAssistive==1){ #> class="active"<# } #>>
								<input type="radio" name="m-c-layout" value="1" />
							</li>
							<li<# if(mini.cfg.scrollAssistive!=1){ #> class="active"<# } #>>
								<input type="radio" name="m-c-layout" value="0" />
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		
		<div class="m-settings-row">
			<div class="msr-left">
				<label><?php _e('Scroll Prevention', 'mini_composer'); ?></label>
				<span>
					<?php _e('Keep the web page unmoved while scrolling a popup', 'mini_composer'); ?>.
				</span>
			</div>
			<div class="msr-right">
				<div class="msr-content">
					<div class="mini-el-ui meu-boolen" data-cfg="preventScrollPopup" data-type="radio" onclick="mini.ui.elms(event,this)">
						<ul>
							<li<# if(mini.cfg.preventScrollPopup==1){ #> class="active"<# } #>>
								<input type="radio" name="m-c-layout" value="1" />
							</li>
							<li<# if(mini.cfg.preventScrollPopup!=1){ #> class="active"<# } #>>
								<input type="radio" name="m-c-layout" value="0" />
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		
		<div class="m-settings-row">
			<div class="msr-left">
				<label><?php _e('Tooltips display', 'mini_composer'); ?></label>
				<span>
					<?php _e('A brief description will appear when you hover the function icon', 'mini_composer'); ?>.
				</span>
			</div>
			<div class="msr-right">
				<div class="msr-content">
					<div class="mini-el-ui meu-boolen showTipsCfg" data-cfg="showTips" data-type="radio">
						<ul>
							<li<# if(mini.cfg.showTips==1){ #> class="active"<# } #>>
								<input type="radio" name="m-c-layout" value="1" />
							</li>
							<li<# if(mini.cfg.showTips!=1){ #> class="active"<# } #>>
								<input type="radio" name="m-c-layout" value="0" />
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		
		<div class="m-settings-row">
			<div class="msr-left">
				<label><?php _e('Instant Save', 'mini_composer'); ?></label>
				<span>
					<?php _e('Press Ctrl + S to save changes immediately without reloading the builder', 'mini_composer'); ?>.
					<br />
					<?php _e('Even When you are editting an element, do not need to close editing popup', 'mini_composer'); ?>.
					<br />
					<?php _e('Notice: This function isn’t activated when you are typing in an input box or textarea', 'mini_composer'); ?>.
				</span>
			</div>
			<div class="msr-right">
				<div class="msr-content">
					<div class="mini-el-ui meu-boolen instantSaveCfg" data-cfg="instantSave" data-type="radio">
						<ul>
							<li<# if(mini.cfg.instantSave==1){ #> class="active"<# } #>>
								<input type="radio" name="m-c-layout" value="1" />
							</li>
							<li<# if(mini.cfg.instantSave!=1){ #> class="active"<# } #>>
								<input type="radio" name="m-c-layout" value="0" />
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		
	</div>
	<#
		data.callback = function( wrp, $ ){
			
			wrp.find('.save-post-settings').on( 'click', wrp, function(e){
				
				$('#mini-page-body-classes').val( e.data.find('input.mini-post-classes-inp').val() );
				$('#mini-page-css-code').val( e.data.find('textarea.mini-post-css-inp').val() );
				
				mini.get.popup( this, 'close' ).trigger('click');
				
			});
			
			wrp.find('.css-beautifier').on( 'click', function(){
				var txta = $(this).parent().find('textarea');
				txta.val( mini.tools.decode_css( txta.val() ) );
			});
			
			wrp.find('.showTipsCfg').on( 'click', function(event){
				mini.ui.elms( event, this );
				if( mini.cfg.showTips == 1 )
					$('#mini-container').removeClass('hideTips');
				else $('#mini-container').addClass('hideTips');
			});
			
			wrp.find('.instantSaveCfg').on( 'click', function(event){
				mini.ui.elms( event, this );
				if( mini.cfg.instantSave == 1 )
					$('#minicontrols .inss').show();
				else $('#minicontrols .inss').hide();
			});
		}
	#>
</script>
<script type="text/html" id="tmpl-mini-global-sections-template">
<#

	var stg = data.stg, from = data.from, to = data.to, label = data.label, html = '';

	if( stg.length > 0 )
	{
		
		if( from >= to )
			from = 0;
	
		if( stg.length < to )
			to = stg.length;
		
		var n = 0;
		
		for( var i=from; i<to; i++ ){
			
			if( stg[i] != null )
			{
				n++;
				if( stg[i].screenshot == '' )
					stg[i].screenshot = mini.cfg.defaultImg;
				
				stg[i].sid = i;
				stg[i].label = label;
				stg[i].n = n;
				html += mini.template( 'global-section', stg[i] );
			}
		}		
		
		if( to < stg.length)
		{
			html += '<button class="button load-more" data-label="'+label+'" data-from="'+to+
					'" data-to="'+(mini.cfg.sectionsPerpage+to)+'">'+
					'<?php _e('Load More', 'mini_composer'); ?> <i class="fa fa-caret-down"></i></button>'
		}
		#>{{{html}}}<#
	}
	else
	{
		#>
			<div class="msg-emptylist">
				<?php _e('Currently no sections in this profile', 'mini_composer'); ?> <strong>{{mini.cfg.profile}}</strong>
				<br />
				<?php 
					printf( __('Please add New Section or %s', 'mini_composer'),
					'<a href="#" onclick="mini.ui.gsections.showDownload(this)">select another profile</a>'
				); ?>.
				<br />
				<br />
				<p>
					<img src="<?php echo MINI_URL; ?>/assets/images/new_section.png" width="473" />
				</p>
			</div>
		<#	   
	}	
	
#>
</script>
<script type="text/html" id="tmpl-mini-global-section-template">
<div class="mgs-scale-min mgs-section-item<#
	if( data.category !== undefined ){
		var cats = data.category.split(',');
		for( var i in cats ){
			#> category-{{mini.tools.esc_slug(cats[i].trim())}}<#
		}
	}
#> mgs-section-{{data.id}}">
	<a href="#mini-install" class="mgs-si-sceenshot">
		<img data-sid="{{data.id}}" src="{{{data.screenshot}}}" alt="" class="mgs-sel-sceenshot" />
		<span data-sid="{{data.id}}" class="mgs-sel-sceenshot">
			{{data.label}}
		</span>
	</a>
	<div class="mgs-si-info">
		<span>{{data.title}}</span><i>{{data.category}}</i>
		<div class="mgs-si-funcs">
			<a class="edit-section" href="<?php echo admin_url('admin.php?page=mini-sections-manager'); ?>&id={{data.id}}" target="_blank">
				<i title="<?php _e('Edit this section', 'mini_composer'); ?>" class="sl-pencil edit-section"></i>
			</a>
			<a href="#delete" data-sid="{{data.id}}" class="mgs-delete" title="<?php _e('Delete this section', 'mini_composer'); ?>"></a>
		</div>
	</div>
</div>
</script>
<script type="text/html" id="tmpl-mini-add-global-sections-template">
	<div id="mini-global-sections" class="mini-add-sections">
		<div class="mgs-select-section">
			<h1 class="mgs-t01"><?php _e('Add to an available section', 'mini_composer'); ?></h1>
			<select class="filter-by-category">
				<option value=""> -- <?php _e('Filter by Category', 'mini_composer'); ?> -- </option>
				<#
					var cats = mini.ui.gsections.get_cats();
					for( var i in cats ){
						if( i !== undefined && i.trim() != '' ){
							#><option value="{{i}}">{{i}} ({{cats[i]}})</option><#
						}
					}
				#>
			</select>
			<div class="mgs-select-wrp">
				{{{mini.ui.gsections.load( '<?php _e('Add to this section', 'mini_composer'); ?>', 0, mini.cfg.sectionsPerpage )}}}
			</div>
		</div>
		<div class="mgs-create-new">
			<div class="mgs-cn-row">
				<h1><?php _e('Create a new section', 'mini_composer'); ?></h1>
				<input class="mgs-title" type="text" placeholder="<?php _e('Enter title', 'mini_composer'); ?>" value="" spellcheck="true" autocomplete="off" />
			</div>
			<div class="mgs-cn-row mgs-category">
				<input  class="mgs-category" type="text" placeholder="<?php _e('Enter category name', 'mini_composer'); ?>" value="" spellcheck="true" autocomplete="off" />
				<div class="mgs-tips">
					<ul>
						<#
							var cats = mini.ui.gsections.get_cats();
							if( Object.keys(cats).length > 0 ){
								for( var i in cats ){
									if( typeof( i ) != 'undefined' && i != '' ){
										#><li data-name="{{i}}"><i class="fa fa-caret-right"></i> {{i}} ({{cats[i]}})</li><#
									}
								}
							}else{
								#><li data-name="first category"><i class="fa fa-caret-right"></i> First Category</li><li></li><#
							}
						#>
					</ul>
				</div>	
			</div>
			<div class="mgc-cn-screenshot"></div>
			<button class="create-section">
				<?php _e('Create Now', 'mini_composer'); ?> 
				<i class="sl-check"></i>
			</button>
		</div>
		<div class="mgs-confirmation">
			<div class="mgs-c-status">
				<i class="et-caution"></i>
				<i class="et-happy"></i>
				<i class="et-sad"></i>
			</div>
			<br />
			<h1 class="mgs-t02"></h1>
			<h2></h2>
			<ul class="btns">
				<li>
					<button class="button button-large back">
						<i class="sl-action-undo"></i> <?php _e('Go Back', 'mini_composer'); ?>
					</button>
					<button class="button button-large button-primary apply">
						<i class="sl-check"></i> <?php _e('Apply Now', 'mini_composer'); ?>
					</button>
					<button class="button button-large button-primary close">
						<i class="sl-close"></i> <?php _e('Close Popup', 'mini_composer'); ?>
					</button>
				</li>
			</ul>
		</div>
	</div>
	<# 
		data.callback = mini.ui.gsections.add_actions;
	#>
</script>
<script type="text/html" id="tmpl-mini-install-global-sections-template">
	<div id="mini-global-sections" class="mini-install-sections">
		<div class="mgs-menus">
			<ul>
				<li class="mgs-menu-download mtips mtips-right <# if(data.list=='no'){ #> active<# } #>" data-active="mgs-download-section">
					<i class="et-notebook"></i>
					<span class="mt-mes"><?php _e('List profiles', 'mini_composer'); ?></span>
				</li>
				<# if(data.list!='no'){ #>
				<li class="mgs-menu-list mtips mtips-right active" data-active="mgs-select-section">
					<i class="et-document"></i>
					<span class="mt-mes"><?php _e('List sections of activated profile', 'mini_composer'); ?></span>
				</li>
				<# } #>
				<li class="mgs-menu-upload mtips mtips-right" data-active="mgs-upload-section">
					<i class="et-upload"></i>
					<span class="mt-mes"><?php _e('Upload profile or create new profile', 'mini_composer'); ?></span>
				</li>
				<li class="mgs-menu-settings mtips mtips-right" data-active="mgs-settings-section">
					<i class="et-gears"></i>
					<span class="mt-mes"><?php _e('Settings', 'mini_composer'); ?></span>
				</li>
			</ul>
		</div>
		<div class="mgs-download-section"<# if(data.list=='no'){ #> style="display:block;"<# } #>>
			<h1 class="mgs-t01"><?php _e('Profiles', 'mini_composer'); ?></h1>
			<a href="#" class="mgs-add-prof"><?php _e('Add new Profile', 'mini_composer'); ?></a>
			<span class="mgs-4rs2"><?php _e('You are using profile: ', 'mini_composer'); ?><span class="msg-profile-label-display">{{mini.cfg.profile}}</span></span>
			<div class="mgs-download-main mini-scroll">
				<ul>
				<#
					for( var i in mini_profiles ){
				#>
					<li<# if(i==mini.cfg.profile_slug){ #> class="active"<# } #>>
						<span>{{mini_profiles[i]}}</span>
						<span data-path="{{i}}" class="msg-download-action" title="{{mini_profiles[i]}}">
							<?php _e('Use this profile', 'mini_composer'); ?>
						</span>
						<a href="#" data-slug="{{i}}" title="<?php _e('Delete this profile', 'mini_composer'); ?>" class="mgs-delete-profile"></a>
						<a href="#" data-name="{{i}}" title="<?php _e('Refresh profile', 'mini_composer'); ?>" class="mgs-refresh-profile"><i class="sl-refresh"></i></a>
						<a href="#" data-slug="{{i}}"  data-name="{{mini_profiles[i]}}" title="<?php _e('Rename this profile', 'mini_composer'); ?>" class="mgs-edit-profile">
							<i class="et-pencil"></i>
						</a>
						<a download="{{i}}.mini" href="<?php echo admin_url('admin-ajax.php?action=mini_download_profile&name=') ?>{{i}}" title="<?php _e('Download this profile', 'mini_composer'); ?>" class="mgs-download-direct"></a>
						</li>
				<#
					}
				#>
				
				<#
					for( var i in mini_profiles_external ){
						
						var path = mini_profiles_external[i],
							base = mini.tools.basename( path );
				#>
					<li<# if( i == mini.cfg.profile_slug || base == mini.cfg.profile_slug ){ #> class="active"<# } #>>
						<span>{{base.replace(/\-/g,' ')}}</span>
						<span data-path="{{i}}" class="msg-download-action" title="{{base.replace(/\-/g,' ')}}">
							<?php _e('Use this profile', 'mini_composer'); ?>
						</span>
						<i class="msg-external"><?php _e('External','mini_composer'); ?></i>
						<a download="{{i}}.mini" href="<?php echo site_url('/'); ?>{{path}}" title="<?php _e('Download this profile', 'mini_composer'); ?>" class="mgs-download-direct"></a>
						</li>
				<#
					}
				#>

				</ul>
				<br />
				<?php _e('What is external profile?', 'mini_composer'); ?>
				<a href="http://minicomposer.com/documentation/locate-your-sections-profile/" target="_blank"><?php _e('Check Document', 'mini_composer'); ?></a>
			</div>
			<div class="mgs-sub-confirmation">
				<h2><?php _e('Are you sure?', 'mini_composer'); ?></h2>
				<button class="button back">
					<i class="sl-action-undo"></i> <?php _e('Cancel', 'mini_composer'); ?>
				</button> 
				<button class="button button-primary apply">
					<i class="sl-arrow-down-circle"></i> <?php _e('Yes, do it please!', 'mini_composer'); ?> 
				</button>
			</div>
		</div>
		<# if(data.list!='no'){ #>
		<div class="mgs-select-section">
			<h1 class="mgs-t01">
				<?php _e('Sections', 'mini_composer'); ?>
			</h1>
			<select class="filter-by-category">
				<option value=""> -- <?php _e('Filter by Category', 'mini_composer'); ?> -- </option>
				<#
					var cats = mini.ui.gsections.get_cats();
					for( var i in cats ){
						if( i !== undefined && i.trim() != '' ){
							#><option value="{{i}}">{{i}} ({{cats[i]}})</option><#
						}
					}
				#>
			</select>
			<input type="search" class="filter-by-name" placeholder="<?php _e('Search by name', 'mini_composer'); ?>" />
			<div class="mgs-layout-btns">
				<i data-layout="list" class="sl-list<# if(mini.cfg.sectionsLayout=='list'){ #> active<# } #>"></i>
				<i data-layout="grid" class="sl-grid<# if(mini.cfg.sectionsLayout=='grid'){ #> active<# } #>"></i>
			</div>
			<div data-label="<?php _e('Install this section', 'mini_composer'); ?>" class="mgs-select-wrp layout-{{mini.cfg.sectionsLayout}}">
				{{{mini.ui.gsections.load( '<?php _e('Install this section', 'mini_composer'); ?>', 0, mini.cfg.sectionsPerpage )}}}
			</div>
		</div>
		<# } #>
		<div class="mgs-confirmation">
			<div class="mgs-c-status">
				<i class="et-caution"></i>
				<i class="et-happy"></i>
				<i class="et-sad"></i>
			</div>
			<br />
			<h1 class="mgs-t02"></h1>
			<h2></h2>
			<ul class="btns">
				<li>
					<button class="button button-large back">
						<i class="sl-action-undo"></i> <?php _e('Go Back', 'mini_composer'); ?>
					</button>
					<button class="button button-large button-primary apply">
						<i class="sl-check"></i> <?php _e('Apply Now', 'mini_composer'); ?>
					</button>
					<button class="button button-large button-primary close">
						<i class="sl-close"></i> <?php _e('Close Popup', 'mini_composer'); ?>
					</button>
				</li>
			</ul>
		</div>
		<div class="mgs-upload-section">
			<div class="mgs-upload-main">
				<div class="mgs-left-side">
					<h1 class="mgs-t02"><?php _e('Upload profile', 'mini_composer'); ?></h1>
					<br />
					<p>
						<input type="file" class="msg-upload-profile-input" />
					</p>
					<button class="button button-primary uploadNow"><?php _e('Upload Now', 'mini_composer'); ?></button>
				</div>
				<div class="mgs-right-side">
					<h1 class="mgs-t02"><?php _e('New profile', 'mini_composer'); ?></h1>
					<br />
					<p>
						<input class="msg-new-profile-input" type="text" placeholder="Enter profile name" />
					</p>
					<button class="button button-primary createNew"><?php _e('Create Now', 'mini_composer'); ?></button>
				</div>
			</div>
		</div>
		<div class="mgs-settings-section mini-scroll">
			<h1 class="mgs-t02 alignleft">
				<?php _e('Quick Settings Builder', 'mini_composer'); ?>
				<span><?php _e('Settings will be applied instantly when you change parameter value', 'mini_composer'); ?></span>
			</h1>
			<div class="m-settings-row">
				<div class="msr-left">
					<label><?php _e('Layout Display', 'mini_composer'); ?></label>
					<span><?php _e('Set default layout for sections', 'mini_composer'); ?></span>
				</div>
				<div class="msr-right">
					<div class="msr-content">
						<div class="mini-el-ui meu-radio" data-cfg="sectionsLayout" data-type="radio" onclick="mini.ui.elms(event,this)">
							<ul>
								<li<# if(mini.cfg.sectionsLayout=='grid'){ #> class="active"<# } #>>
									<?php _e('Grid', 'mini_composer'); ?>
									<input type="radio" name="m-c-layout" value="grid" />
								</li>
								<li<# if(mini.cfg.sectionsLayout=='list'){ #> class="active"<# } #>>
									<?php _e('List', 'mini_composer'); ?>
									<input type="radio" name="m-c-layout" value="list" />
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			
			<div class="m-settings-row">
				<div class="msr-left">
					<label><?php _e('Number of sections', 'mini_composer'); ?></label>
					<span>
						<?php _e('will be shown in a page, each load-more scrolling down', 'mini_composer'); ?>
					</span>
				</div>
				<div class="msr-right">
					<div class="msr-content">
						<div class="mini-el-ui meu-select">
							<select data-cfg="sectionsPerpage" data-type="select" onchange="mini.ui.elms(event,this)">
								<option<# if(mini.cfg.sectionsPerpage==5){ #> selected<# } #> value="5">5</option>
								<option<# if(mini.cfg.sectionsPerpage==10){ #> selected<# } #> value="10">10</option>
								<option<# if(mini.cfg.sectionsPerpage==15){ #> selected<# } #> value="15">15</option>
								<option<# if(mini.cfg.sectionsPerpage==30){ #> selected<# } #> value="30">30</option>
							</select>
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</div>
	<div class="mini-popup-loading"><i class="fa fa-spinner fa-spin fa-3x fa-fw"></i></div>
	<# 
		data.callback = mini.ui.gsections.install_actions;
	#>
</script>

<script type="text/html" id="tmpl-mini-row-template">
<#
 
var fEr3 = '', Hrdw = '', sEtd4 = '';

if( data[0] !== undefined && data[0] != '__empty__' )
	sEtd4 = '#'+data[0];

if( data[1] !== undefined && data[1] == 'on' ){
	fEr3 = ' collapse',
	Hrdw = ' disabled';
}

#>
	<div class="mini-row m-r-sortdable{{fEr3}}">
		<ul class="mini-row-control row-container-control">
			<li class="right close mtips">
				<i class="sl-close"></i>
				<span class="mt-mes"><?php _e('Delete this row', 'mini_composer'); ?></span>
			</li>
			<li class="right settings mtips">
				<i class="sl-note"></i>
				<span class="mt-mes"><?php _e('Row settings', 'mini_composer'); ?></span>
			</li>
			<li class="right copy mtips">
				<i class="sl-doc"></i>
				<span class="mt-mes"><?php _e('Copy this row', 'mini_composer'); ?></span>
			</li>
			<li class="right double mtips">
				<i class="sl-docs"></i>
				<span class="mt-mes"><?php _e('Double this row', 'mini_composer'); ?></span>
			</li>
			<li class="right move mtips">
				<i class="sl-cursor-move"></i>
				<span class="mt-mes"><?php _e('Drag and drop to arrange this row', 'mini_composer'); ?></span>
			</li>
		</ul>
		<div class="mini-row-admin-view">{{sEtd4}}</div>
		<ul class="mini-row-control row-container-control pos-left">
			<li class="right collapse mtips">
				<i class="sl-arrow-down"></i>
				<span class="mt-mes"><?php _e('Expand / Collapse this row', 'mini_composer'); ?></span>
			</li>
			<li class="right columns mtips">
				<i class="sl-list"></i>
				<span class="mt-mes"><?php _e('Set number of columns for this row', 'mini_composer'); ?></span>
			</li>
			<li class="right addToSections mtips">
				<i class="sl-share-alt"></i>
				<span class="mt-mes"><?php _e('Storage this row in profile', 'mini_composer'); ?></span>
			</li>
			<li class="rowStatus{{Hrdw}} mtips">
				<i></i>
				<span class="mt-mes"><?php _e('Publish / Unpublish this row', 'mini_composer'); ?></span>
			</li>
		</ul>	
		<div class="mini-row-wrap"></div>
	</div>
</script>
<script type="text/html" id="tmpl-mini-row-inner-template">
	<div class="mini-row-inner">
		<ul class="mini-row-control mini-row-inner-control">
			<li class="right delete mtips">
				<i class="sl-close"></i>
				<span class="mt-mes"><?php _e('Delete this row', 'mini_composer'); ?></span>
			</li>
			<li class="right settings mtips">
				<i class="sl-note"></i>
				<span class="mt-mes"><?php _e('Open row settings', 'mini_composer'); ?></span>
			</li>
			<li class="right double mtips">
				<i class="sl-docs"></i>
				<span class="mt-mes"><?php _e('Double this row', 'mini_composer'); ?></span>
			</li>
			<li class="right move mtips">
				<i class="sl-cursor-move"></i>
				<span class="mt-mes"><?php _e('Drag and drop to arrange this row', 'mini_composer'); ?></span>
			</li>
		</ul>
		<ul class="mini-row-control pos-left mini-row-inner-control">
			<li class="right collapse mtips">
				<i class="sl-arrow-down"></i>
				<span class="mt-mes"><?php _e('Expand / Collapse this row', 'mini_composer'); ?></span>
			</li>
			<li class="right columns mtips">
				<i class="sl-list"></i>
				<span class="mt-mes"><?php _e('Set number of columns for this row', 'mini_composer'); ?></span>
			</li>
			<li class="right copyRowInner mtips">
				<i class="sl-doc"></i>
				<span class="mt-mes"><?php _e('Copy this row', 'mini_composer'); ?></span>
			</li>
		</ul>	
		<div class="mini-row-wrap"></div>
	</div>	
</script>
<script type="text/html" id="tmpl-mini-column-template">
	<div class="mini-column" style="width: {{data.width}}">
		<ul class="mini-column-control column-container-control">
			<li class="arrow-left mini-column-toleft mtips">
				<i class="sl-arrow-left"></i>
				<span class="mt-mes"><?php _e('Increasing the width of this column to the left', 'mini_composer'); ?></span>
			</li>
			<li class="mini-column-settings mtips">
				<i class="sl-note"></i>
				<span class="mt-mes"><?php _e('Open column settings', 'mini_composer'); ?></span>
			</li>
			<li class="mini-column-add mtips">
				<i class="sl-plus"></i>
				<span class="mt-mes"><?php _e('Add elements to top of this column', 'mini_composer'); ?></span>
			</li>
			<li class="close mtips">
				<i class="sl-trash"></i>
				<span class="mt-mes"><?php _e('Delete this column', 'mini_composer'); ?></span>
			</li>
			<li class="right arrow-right mini-column-toright mtips">
				<i class="sl-arrow-right"></i>
				<span class="mt-mes"><?php _e('Increasing the width of this column to the right', 'mini_composer'); ?></span>
			</li>
		</ul>
		<div class="mini-column-wrap">
			<div class="mini-element drag-helper">
				<a href="javascript:void(0)" class="mini-add-elements-inner">
					<i class="sl-plus"></i> <?php _e('Add Element', 'mini_composer'); ?>
				</a>
			</div>
		</div>
		<ul class="mini-column-control pos-bottom">
			<li class="mini-column-add mtips">
				<i class="sl-plus"></i>
				<span class="mt-mes"><?php _e('Add elements to bottom of this column', 'mini_composer'); ?></span>
			</li>
		</ul>
		<div class="column-resize cr-left"></div>
		<div class="column-resize cr-right"></div>
	</div>
</script>
<script type="text/html" id="tmpl-mini-column-inner-template">
	<div class="mini-column-inner" style="width: {{data.width}}">
		<ul class="mini-column-control column-inner-control">
			<li class="arrow-left mini-column-toleft mtips">
				<i class="sl-arrow-left"></i>
				<span class="mt-mes"><?php _e('Increasing the width of this column to the left', 'mini_composer'); ?></span>
			</li>
			<li class="mini-column-settings mtips">
				<i class="sl-note"></i>
				<span class="mt-mes"><?php _e('Open column settings', 'mini_composer'); ?></span>
			</li>
			<li class="mini-column-add mtips">
				<i class="sl-plus"></i>
				<span class="mt-mes"><?php _e('Add elements to top of this column', 'mini_composer'); ?></span>
			</li>
			<li class="close mtips">
				<i class="sl-trash"></i>
				<span class="mt-mes"><?php _e('Delete this column', 'mini_composer'); ?></span>
			</li>
			<li class="right arrow-right mini-column-toright mtips">
				<i class="sl-arrow-right"></i>
				<span class="mt-mes"><?php _e('Increasing the width of this column to the right', 'mini_composer'); ?></span>
			</li>
		</ul>
		<div class="mini-column-wrap">
			<div class="mini-element drag-helper">
				<a href="javascript:void(0)" class="mini-add-elements-inner">
					<i class="sl-plus"></i> <?php _e('Add Elements', 'mini_composer'); ?>
				</a>
			</div>
		</div>
		<ul class="mini-column-control pos-bottom">
			<li class="mini-column-add mtips">
				<i class="sl-plus"></i>
				<span class="mt-mes"><?php _e('Add elements to bottom of this column', 'mini_composer'); ?></span>
			</li>
		</ul>
		<div class="column-resize cr-left"></div>
		<div class="column-resize cr-right"></div>
	</div>
</script>
<script type="text/html" id="tmpl-mini-views-sections-template">
	<#
		try{
			var sct = mini.maps[data.name].views.sections;
			if( mini.maps[data.name].views.display == 'vertical' )
				var vertical = ' mini-views-vertical';
		}catch(e){
			var sct = 'mini_tab', vertical = 'mini-views-horizontal';
		}	
	#>
	<div class="mini-views-sections mini-views-{{data.name}}{{vertical}}">
		<ul class="mini-views-sections-control mini-controls">
			<li class="right move mtips">
				<i class="sl-cursor-move"></i> {{mini.maps[data.name].name}}
				<span class="mt-mes"><?php _e('Drag and drop to arrange this section', 'mini_composer'); ?></span>
			</li>
			<li class="right edit mtips">
				<i class="sl-note"></i>
				<span class="mt-mes"><?php _e('Open settings', 'mini_composer'); ?></span>
			</li>
			<li class="double mtips">
				<i class="sl-docs"></i>
				<span class="mt-mes"><?php _e('Double this sections', 'mini_composer'); ?></span>
			</li>
			<li class="more mtips" title="<?php _e('More Actions', 'mini_composer'); ?>">
				<i class="fa fa-caret-right"></i>
				<div class="mme-more-actions">
					<ul>
						<li class="copy" title="<?php _e('Copy this element', 'mini_composer'); ?>">
							<i class="fa fa-copy"></i> <?php _e('Copy', 'mini_composer'); ?>
						</li>
						<li class="cut" title="<?php _e('Cut this element', 'mini_composer'); ?>">
							<i class="fa fa-cut"></i> <?php _e('Cut', 'mini_composer'); ?>
						</li>
						<li class="delete" title="<?php _e('Delete this element', 'mini_composer'); ?>">
							<i class="fa fa-trash-o"></i> <?php _e('Delete', 'mini_composer'); ?>
						</li>
					</ul>
				</div>
				<span class="mt-mes"><?php _e('More actions', 'mini_composer'); ?></span>
			</li>
		</ul>
		<div class="mini-views-sections-wrap">
			<div class="mini-views-sections-label">
				<div class="add-section">
					<i class="sl-plus"></i> <span> <?php _e('Add', 'mini_composer'); ?> {{mini.maps[sct].name}}</span>
				</div>
			</div>	
		</div>
	</div>
</script>
<script type="text/html" id="tmpl-mini-views-section-template">
	<#
		var icon = '';
		if( data.args.icon != undefined )
			icon = '<i class="'+data.args.icon+'"></i> ';
	#>
	<div class="mini-views-section<# if(data.first==true){ #> mini-section-active<# } #>">
		<h3 class="mini-vertical-label sl-arrow-down">{{{icon}}}{{data.args.title}}</h3>
		<ul class="mini-controls-2 mini-vs-control">
			<li class="right add mtips">
				<i class="sl-plus"></i>
				<span class="mt-mes"><?php _e('Add Elements', 'mini_composer'); ?></span>
			</li>
			<li class="right double mtips">
				<i class="sl-docs"></i>
				<span class="mt-mes"><?php _e('Double this section', 'mini_composer'); ?></span>
			</li>
			<li class="right settings mtips">
				<i class="sl-note"></i>
				<span class="mt-mes"><?php _e('Open settings', 'mini_composer'); ?></span>
			</li>
			<li class="right delete mtips" title="<?php _e('Remove', 'mini_composer'); ?>">
				<i class="sl-close"></i>
				<span class="mt-mes"><?php _e('Remove this section', 'mini_composer'); ?></span>
			</li>
		</ul>
		<div class="mini-views-section-wrap mini-column-wrap">
			<div class="mini-element drag-helper">
				<a href="javascript:void(0)" class="mini-add-elements-inner">
					<i class="sl-plus"></i> <?php _e('Add Element', 'mini_composer'); ?>
				</a>
			</div>
		</div>
	</div>
</script>
<script type="text/html" id="tmpl-mini-element-template">
	 <div class="mini-element {{data.params.name}}<# if(data.map.preview_editable == true){ #> viewEditable<# } #>">
		<div class="mini-element-icon"><span class="cpicon {{data.map.icon}}"></span></div>
		<span class="mini-element-label">{{data.map.name}}</span>
		<div class="mini-element-control" title="<?php _e('Drag to move this element', 'mini_composer'); ?>">
			<ul class="mini-controls">
				<!--li class="move" title="<?php _e('Move', 'mini_composer'); ?>">
					<i class="sl-cursor-move"></i>
				</li-->
				<li class="edit mtips" title="">
					<i class="sl-note"></i>
					<span class="mt-mes"><?php _e('Edit this element', 'mini_composer'); ?></span>
				</li>
				<li class="double mtips" title="">
					<i class="sl-docs"></i>
					<span class="mt-mes"><?php _e('Double this element', 'mini_composer'); ?></span>
				</li>
				<li class="more mtips" title="">
					<i class="fa fa-caret-right"></i>
					<div class="mme-more-actions">
						<ul>
							<li class="copy" title="<?php _e('Copy this element', 'mini_composer'); ?>">
								<i class="fa fa-copy"></i> <?php _e('Copy', 'mini_composer'); ?>
							</li>
							<li class="cut" title="<?php _e('Cut this element', 'mini_composer'); ?>">
								<i class="fa fa-cut"></i> <?php _e('Cut', 'mini_composer'); ?>
							</li>
							<li class="delete" title="<?php _e('Delete this element', 'mini_composer'); ?>">
								<i class="fa fa-trash-o"></i> <?php _e('Delete', 'mini_composer'); ?>
							</li>
						</ul>
					</div>
					<span class="mt-mes"><?php _e('More Actions', 'mini_composer'); ?></span>
				</li>
			</ul>
		</div>
		<br />
	</div>
</script>
<script type="text/html" id="tmpl-mini-undefined-template">
	 <div class="mini-undefined mini-element {{data.params.name}}">
		<div class="admin-view content">{{data.params.args.content}}</div>
		<div class="mini-element-control">
			<ul class="mini-controls">
				<li class="move" title="<?php _e('Move', 'mini_composer'); ?>">
					<i class="sl-cursor-move"></i>
				</li>
				<li class="double" title="<?php _e('Double', 'mini_composer'); ?>">
					<i class="sl-docs"></i>
				</li>
				<li class="edit" title="<?php _e('Edit', 'mini_composer'); ?>">
					<i class="sl-note"></i>
				</li>
				<li class="delete" title="<?php _e('Delete', 'mini_composer'); ?>">
					<i class="sl-close"></i>
				</li>
			</ul>
		</div>		
	</div>
</script>
<script type="text/html" id="tmpl-mini-popup-template">
	<div class="mini-params-popup wp-pointer-top {{data.class}}<# if(data.bottom!=0){ #> posbottom<# } #>" style="<# if(data.bottom!=0){ #>bottom:{{data.bottom}}px;top:auto;<# }else{ #>top:{{data.top}}px;<# } #>left:{{data.left}}px;<#
			if( data.width != undefined ){ #>width:{{data.width}}px<# } 
		#>">
		<div class="m-p-wrap wp-pointer-content">
			<h3 class="m-p-header">
				{{data.title}}
				<# if( data.help != '' ){ #>
				<a href="{{data.help}}" target="_blank" title="<?php _e('Help', 'mini_composer'); ?>" class="sl-help sl-func">
					&nbsp;
				</a>
				<# } #>
				<i title="<?php _e('Cancel & close popup', 'mini_composer'); ?>" class="sl-close sl-func"></i>
				<i title="<?php _e('Save & close popup', 'mini_composer'); ?>" class="sl-check sl-func"></i></h3>
			<div class="m-p-body">
				{{{data.content}}}
			</div>
			<# if( data.footer === true ){ #>
			<div class="m-p-footer">
				<ul class="m-p-controls">
					<li>
						<button class="button save button-large">
							<i class="sl-check"></i> {{data.save_text}}
						</button>
					</li>
					<li>
						<button class="button cancel button-large">
							<i class="sl-close"></i> {{data.cancel_text}}
						</button>
					</li>
					<li class="pop-tips"><i>{{data.footer_text}}</i></li>
				</ul>
			</div>
			<# } #>
		</div>
		<div class="wp-pointer-arrow"<#
				if( data.pos != undefined ){
					var css = '';
					if( data.pos == 'center' ){
						css += 'left:50%;margin-left:-13px;';
					}else if( data.pos == 'right' ){
						css += 'left:auto;right:50px;';
					}
					if( css != '' ){
						#> style="{{css}}"<#
					}
				}
			#>>
			<div class="wp-pointer-arrow-inner"></div>
		</div>
	</div>
</script>
<script type="text/html" id="tmpl-mini-field-template">
	<div class="mini-param-row field-{{data.name}} field-base-{{data.base}}" <# 
			if( data.relation != undefined ){
				#>style="display:none;"<# 
			} 
		#>>
		<# if( data.label != undefined && data.label != '' ){ #>
		<div class="m-p-r-label">
			<label>{{data.label}}:</label>
		</div>
		<div class="m-p-r-content">
		<# }else{ #>
		<div class="m-p-r-content full-width">
		<# } #>	
			{{{data.content}}}
			<# if( data.des != undefined && data.des != '' ){ #>
				<div class="m-p-r-des">{{data.des}}</div>
			<# } #>
		</div>
	</div>
</script>

<script type="text/html" id="tmpl-mini-row-columns-template">
	<div class="mini-row-columns">
		&nbsp; <input type="checkbox" data-name="columnDoubleContent" id="m-r-c-double-content" {{mini.cfg.columnDoubleContent}} /> 
		<?php _e('Double content', 'mini_composer'); ?> <a href="javascript:alert('<?php _e('Copy content in the last column to the newly-created column. This option is available when you choose to set the column amount greater than the current column amount', 'mini_composer'); ?>.\n\n<?php _e('For example: Currently there is 1 column and you are going to set 2 columns', 'mini_composer'); ?>')"> <i class="sl-question"></i> </a> &nbsp; &nbsp; 
		<input type="checkbox" data-name="columnKeepContent" id="m-r-c-keep-content" {{mini.cfg.columnKeepContent}} /> 
		<?php _e('Keep content', 'mini_composer'); ?> <a href="javascript:alert('<?php _e('Keep content of the removed column and transfer it to the last existing column', 'mini_composer'); ?>.\n\n<?php _e('This option is available when you choose to set the column amount smaller than the current column amount', 'mini_composer'); ?>.\n\n<?php _e('For example: Currently there are 2 columns and you are going to set 1 column', 'mini_composer'); ?>.')"> <i class="sl-question"></i> </a>
		<p></p>
		<button class="button button-large<#
			if( data.current == 1 ){
				#> active<#
			}	  
			#>" data-column="1">1 <?php _e('Column', 'mini_composer'); ?> &nbsp;</button>
		<# for( var i=2; i<7; i++ ){ #>
			<button class="button button-large<#
			if( data.current == i ){
				#> active<#
			}
			#>" data-column="{{i}}">{{i}} <?php _e('Columns', 'mini_composer'); ?></button>
		<# } #>
	</div>
</script>

<script type="text/html" id="tmpl-mini-box-design-template">
<#
	if( typeof data == 'object' && data.length > 0 ){
		
		data.forEach( function( item ){
			
	        if( typeof item.attributes != 'object' )
	        	item.attributes = {};
	        if( item.tag == 'a' && item.attributes.href == undefined )
	        	item.attributes.href = '';
	        
	        var classes = '';	
	        if( item.tag == 'icon' || item.tag == 'text' || item.tag == 'image' ){
	        	classes += ' mini-box-elm';
			}else if( item.tag == 'clumn' ){
				var ncl = 'one-one';
				if( item.attributes.class !== undefined ){
					['one-one','one-second','one-third','two-third'].forEach(function(cl){
						if( item.attributes.class.indexOf( cl ) > -1 )
							ncl = cl;
					});
				}
				classes += ' mini-column-'+ncl;
			}
			
			
	        if( item.attributes.cols != undefined )
	        	classes += ' mini-column-'+item.attributes.cols;
	        	
#>
			<div class="mini-box mini-box-{{item.tag}}{{classes}}" data-tag="{{item.tag}}" data-attributes='{{JSON.stringify(item.attributes)}}'>
		        <ul class="mb-header">
			        <li class="mb-toggle" data-action="toggle"><i class="mb-toggle fa-caret-down"></i></li>
			        <li class="mb-tag">{{item.tag}}</li>
			        <# if( item.attributes.id != undefined && item.attributes.id != '' ){ #>
			        	<li class="mb-id">Id: <span>{{item.attributes.id}}</span></li>
			        <# } if( item.attributes.class != undefined && item.attributes.class != '' ){ #>
			        	<li class="mb-class">
			        		Class: <span title="{{item.attributes.class}}">{{item.attributes.class.substr(0,30)}}..</span>
			        	</li>
			        <# } if( item.attributes.href != '' && item.attributes.href != undefined ){ #>
			        	<li class="mb-href">
			        		Href: <span title="{{item.attributes.href}}">{{item.attributes.href.substr(0,30)}}..</span>
			        	</li>
			        <# } #>
			        <li class="mb-funcs">
			        	<ul>
					        <li title="<?php _e('Remove', 'mini_composer'); ?>" class="mb-remove mb-func" data-action="remove">
					        	<i class="sl-close"></i>
					        </li>
					        <# if( item.tag == 'text' ){ #>
					        <li  title="<?php _e('Edit with Editor', 'mini_composer'); ?>"class="mb-edit mb-func" data-action="editor">
					        	<i class="sl-pencil"></i>
					        </li>
					        <# }else{ #>
					        <li  title="<?php _e('Settings', 'mini_composer'); ?>"class="mb-edit mb-func" data-action="settings">
					        	<i class="sl-settings"></i>
					        </li>
					        <# } #>
					        <li title="<?php _e('Double', 'mini_composer'); ?>" class="mb-double mb-func" data-action="double">
					        	<i class="sl-docs"></i>
					        </li>
					        <# if( item.tag != 'div' ){ #>
					        <li title="<?php _e('Add Node', 'mini_composer'); ?>" class="mb-add mb-func" data-action="add" data-pos="inner"><i class="sl-plus"></i></li>
					        <# }else{ #>
					        <li title="<?php _e('Columns', 'mini_composer'); ?>" class="mb-columns mb-func" data-action="columns"><i class="sl-list"></i></li>    
							<# } #>
						</ul>
				    </li>
		        </ul>
		        <div class="mini-box-body"><# 
			        
			        var empcol = false;
			        
		        	if( item.tag == 'div' ){
			        	if( item.children == undefined )
				        		empcol = true;
			        	else if( item.children.length == 0 )
				        		empcol = true;
				        else if( item.children[0].tag != 'column' )
				        	empcol = true;
			        }
			        
			        if( empcol == true ){
				        
				       #>{{{mini.template( 'box-design', [{ tag: 'column', attributes: { cols:'one-one' }, children: item.children }]
				       	)}}}<# 
				        
			        }else{
			        
			        	
				        if( empcol == true ){
					        #><div data-cols="one-one" class="mini-box-column one-one"><#
				        }	


				        if( item.tag == 'text' ){
					        if( item.content == undefined )
					        	item.content = 'Sample Text';
					        #>
								<div class="mini-box-inner-text" contenteditable="true">{{{item.content}}}</div>
						    <#
					    }else if( item.tag == 'image' ){
						    if( item.attributes.src == undefined )
						    	item.attributes.src = plugin_url+'/assets/images/get_start.jpg';
					        #>
								<img data-action="select-image" src="{{item.attributes.src}}" />
						    <#
					    }else if( item.tag == 'icon' ){
						    if( item.attributes.class == undefined )
						    	item.attributes.class = 'fa-leaf';
					        #>
							<span data-action="icon-picker"><i class="{{item.attributes.class}}"></i></span>
						    <#
					    }else{
				        
					       					        	
					        #>{{{mini.template( 'box-design', item.children )}}}<#
				        
				        }
				        
				        #><div class="mini-box mb-helper">
					        <a href="#" data-action="add" data-pos="inner">
						        <i class="sl-plus"></i> 
						        <?php _e('Add Node', 'mini_composer'); ?>
						    </a>
					    </div>
				    
				    <# }/*EndIf*/ #>
				    
		        </div>
		    </div>
		    
		<#
		
		});
	}	
#>
</script>

<script type="text/html" id="tmpl-mini-param-group-template">

	<div class="mini-group-row">
		<div class="mini-group-controls">
			<ul>
				<li class="collapse" data-action="collapse" title="<?php _e('expand / collapse', 'mini_composer' ); ?>">
					<i class="sl-arrow-down" data-action="collapse"></i>
				</li>
				<li class="counter"> #1 </li>
				<li class="delete" data-action="delete" title="<?php _e('Delete this group', 'mini_composer' ); ?>">
					<i data-action="delete" class="sl-close"></i>
				</li>

				<li class="double" data-action="double" title="<?php _e('Double this group', 'mini_composer' ); ?>">
					<i class="sl-docs" data-action="double"></i>
				</li>			
			</ul>
		</div>
		<div class="mini-group-body"></div>
	</div>

</script>

<script type="text/html" id="tmpl-mini-wp-widgets-element-template">
<ul class="mini-wp-widgets-ul mini-components-list" id="mini-wp-widgets-pop"><#
	mini.widgets.find('>div.widget').each(function(){
		var tit = jQuery(this).find('.widget-title').text(),
			des = jQuery(this).find('.widget-description').html(),
			base = '{"'+jQuery(this).find('input[name="id_base"]').val()+'":{}}';
			
#>	
		<li data-data="{{mini.tools.base64.encode(base)}}" data-category="wp_widgets" data-name="mini_wp_widget" title="{{des}}">
			<div>
				<span class="cpicon mini-icon-wordpress"></span>
				<span class="cpdes">
					<strong>{{tit}}</strong>
					<i>{{des}}</i>
				</span>
			</div>
		</li>
<#	
	});
#>
</ul>
<#
	data.callback = function( wrp, e ){
		wrp.find( 'li' ).on( 'click', e.data.items );
	}
#>
</script>
<script type="text/html" id="tmpl-mini-wp-widgets-template">
<div id="mini-wp-list-widgets"><?php 
	
	ob_start();
		@wp_list_widgets(); 
		$content = str_replace( array( '<script', '</script>' ), array( '&lt;script', '&lt;/script&gt;' ), ob_get_contents() );
	ob_end_clean();
	
	echo $content;
	
?></div>
</script>

<div style="display:none;" id="mini-storage-prepare">
	<div id="mini-css-box-test"></div>
</div>
<img width="50" src="<?php echo MINI_URL; ?>/assets/images/drag.png" id="mini-ui-handle-image" />
<img width="50" src="<?php echo MINI_URL; ?>/assets/images/drag-copy.png" id="mini-ui-handle-image-copy" />
<div id="mini-undo-deleted-element">
	<a href="javascript:void(0)" class="do-action">
		<i class="sl-action-undo"></i> <?php _e('Restore deleted items', 'mini_composer'); ?>
		<span class="amount">0</span>
	</a>	
	<div id="drop-to-delete"><span></span></div>
	<i class="sl-close"></i>	
</div>
