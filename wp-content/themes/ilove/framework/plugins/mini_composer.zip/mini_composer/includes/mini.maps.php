<?php
/**
*
*	Mini Composer
*	(c) MiniComposer.com
*
*/
if(!defined('MINI_FILE')){
	header('HTTP/1.0 403 Forbidden');
	exit;
}

global $mini;

$mini->add_map(

	array(

		'_value' => array(
			'name' => 'Mini Element',
			'description' => 'Mini Element',
			'icon' => 'sl-info',	   /* Class name of icon show on "Add Elements" */
			'category' => '',	  /* Category to group elements when "Add Elements" */
			'is_container' => false, /* Container has begin + end [name]...[/name] -  Single has only [name param=""] */
			'pop_width' => 580,		/* width of the popup will be open when clicking on the edit  */
			'system_only' => true, /* Use for system only and dont show up to Add Elements */
			'params' => array()
		),

		'mini_undefined' => array(
			'name' => 'Undefined Element',
			'icon' => 'sl-flag',
			'category' => 'Content',
			'is_container' => true,
			'pop_width' => 750,
			'system_only' => true,
			'params' => array(
				array(
					'name' => 'content',
					'label' => 'Content',
					'type' => 'textarea_html',
					'value' => 'Sample Text',
					'admin_label' => true,
				)
			)
		),

		'mini_wp_widget' => array(
			'name' => 'Wordpress Widget',
			'icon' => 'mini-icon-wordpress',
			'category' => 'Content',
			'pop_width' => 450,
			'system_only' => true,
			'params' => array(
				array(
					'name' => 'data',
					'label' => 'Data',
					'type' => 'wp_widget',
					'admin_label' => true,
				)
			)
		),

		'mini_css_box' => array(

			'name' => 'CSS Box',
			'system_only' => true,
			'params' => array(

				array(
					'name' => 'margin',
					'label' => 'Margin',
					'type' => 'css_box_tbtl'
				),
				array(
					'name' => 'padding',
					'label' => 'Padding',
					'type' => 'css_box_tbtl',
				),
				array(
					'name' => 'border',
					'label' => 'Border',
					'type' => 'css_box_border',
				),
				array(
					'name' => 'color',
					'label' => 'Text Color',
					'type' => 'color_picker',
					'description' => 'Set color for text'
				),
				array(
					'name' => 'background-color',
					'label' => 'BG Color',
					'type' => 'color_picker',
					'description' => 'Set background color'
				),
				array(
					'name' => 'background-image-option',
					'label' => 'BG Image?',
					'type' => 'checkbox',
					'description' => 'Do you want to use background image?',
					'options' => array( 'yes' => 'Yes, Please!' )
				),
				array(
					'name' => 'background-image',
					'label' => 'Upload Image',
					'type' => 'attach_image_url',
					'relation' => array(
						'parent' => 'background-image-option',
						'show_when' => 'yes'
					)
				),
				array(
					'name' => 'background-repeat',
					'label' => 'BG Repeat',
					'type' => 'select',
					'options' => array(
						'' => 'Yes',
						'no-repeat' => 'No Repeat',
						'repeat-x' => 'Repeat Horizontal',
						'repeat-y' => 'Repeat Vertical'
					),
					'relation' => array(
						'parent' => 'background-image-option',
						'show_when' => 'yes'
					)
				),
				array(
					'name' => 'background-position',
					'label' => 'BG Position',
					'type' => 'text',
					'description' => 'center center | 0px 0px | 50% 50%',
					'relation' => array(
						'parent' => 'background-image-option',
						'show_when' => 'yes'
					)
				),
				array(
					'name' => 'background-attachment',
					'label' => 'BG Attachment',
					'type' => 'text',
					'description' => 'scroll | fixed | local | initial | inherit',
					'relation' => array(
						'parent' => 'background-image-option',
						'show_when' => 'yes'
					)
				),
				array(
					'name' => 'background-size',
					'label' => 'BG Size',
					'type' => 'text',
					'description' => 'auto | length | cover | contain | initial | inherit',
					'relation' => array(
						'parent' => 'background-image-option',
						'show_when' => 'yes'
					)
				),
			)

		),

		'mini_row' => array(
			'name' => 'Row',
			'description' => __( 'Place content elements inside the row', 'mini_composer' ),
			'category' => '',
			'title' => 'Row Settings',
			'is_container' => true,
			'css_box' => true,
			'system_only' => true,
			'params' => array(
					
				array(
					'name' => 'row_id',
					'label' => 'Row ID',
					'type' => 'text',
					'description' => __('The unique identifier of the row', 'mini_composer'),
				),
				array(
					'name' => 'full_width_option',
					'label' => 'Full Width?',
					'type' => 'checkbox',
					'description' => __('This option helps to make stretching this row and content.', 'mini_composer'),
					'options' => array(
						'yes' => 'Yes, Please!'
					),
				),
				array(
					'name' => 'full_width',
					'label' => 'Stretch Option',
					'type' => 'radio',
					'value' => 'stretch_row',
					'description' => __('Please select stretch options.', 'mini_composer'),
					'options' => array(
						'stretch_row' => 'Only Row',
						'stretch_row_content' => 'Row & Content'
					),
					'relation' => array(
						'parent' => 'full_width_option',
						'show_when' => 'yes'
					),
				),
				array(
					'name' => 'full_height',
					'label' => __( 'Full height?', 'mini_composer' ),
					'type' => 'checkbox',
					'description' => __( 'If checked, this row will be set to full height.', 'mini_composer' ),
					'options' => array(
						'yes' => __( 'Yes', 'mini_composer' )
					)
				),
				array(
					'name' => 'content_placement',
					'label' => __( 'Content position', 'mini_composer' ),
					'type' => 'select',
					'options' => array(
						'middle' => __( 'Middle', 'mini_composer' ),
						'top' => __( 'Top', 'mini_composer' ),
					),
					'description' => __( 'Select content position within row when full-height.', 'mini_composer' ),
					'relation' => array(
						'parent' => 'full_height',
						'show_when' => 'yes'
					),
				),
				array(
					'name' => 'video_bg',
					'label' => __( 'Use video background?', 'mini_composer' ),
					'type' => 'checkbox',
					'description' => __( 'If checked, video will be used as row background.', 'mini_composer' ),
					'options' => array( 'yes' => __( 'Yes', 'mini_composer' ) )
				),
				array(
					'name' => 'video_bg_url',
					'label' => __( 'YouTube link', 'mini_composer' ),
					'type' => 'text',
					'value' => 'https://www.youtube.com/watch?v=dOWFVKb2JqM',
					'description' => __( 'Add YouTube link.', 'mini_composer' ),
					'relation' => array(
						'parent' => 'video_bg',
						'show_when' => 'yes'
					),
				),
				array(
					'name' => 'parallax',
					'label' => __( 'Parallax', 'mini_composer' ),
					'type' => 'select',
					'options' => array(
						'' => __( 'None', 'mini_composer' ),
						'yes' => __( 'Use Background Image', 'mini_composer' ),
						'yes-new' => __( 'Upload New Image', 'mini_composer' ),
					),
					'description' => __( 'Add parallax type background for row (Note: If no image is specified, parallax will use background image from Design Options).', 'mini_composer' ),
					'relation' => array(
						'parent' => 'video_bg',
						'hide_when' => 'yes',
					),
				),
				array(
					'name' => 'parallax_image',
					'label' => __( 'Image', 'mini_composer' ),
					'type' => 'attach_images',
					'value' => '',
					'description' => __( 'Select image from media library.', 'mini_composer' ),
					'relation' => array(
						'parent' => 'parallax',
						'show_when' => 'yes-new',
					),
				),
				array(
					'name' => 'parallax_speed',
					'label' => __( 'Parallax Speed', 'mini_composer' ),
					'type' => 'select',
					'description' => __( 'Set speed of parallax when scroll.', 'mini_composer' ),
					'options' => array(
						'1' => '1',
						'0.7' => '0.7',
						'0.4' => '0.4',
						'0.1' => '0.1',
					),
					'value' => '1',
					'relation' => array(
						'parent' => 'parallax',
						'show_when' => 'yes,yes-new',
					),
				),
				array(
					'name' => 'parallax_background_size',
					'label' => __( 'Full background?', 'mini_composer' ),
					'type' => 'checkbox',
					'description' => __( 'Make background size full width & height and prevent repeat', 'mini_composer' ),
					'options' => array(
						'yes' => __( 'Yes, Please!', 'mini_composer' ),
					),
					'value' => 'yes',
					'relation' => array(
						'parent' => 'parallax',
						'show_when' => 'yes,yes-new',
					),
				),
				array(
					'name' => 'container_class',
					'label' => __( 'Container class name', 'mini_composer' ),
					'type' => 'text',
					'description' => __( 'Add classes custom for Container.', 'mini_composer' )
				),
				array(
					'name' => 'row_class',
					'label' => __( 'Row extra class name', 'mini_composer' ),
					'type' => 'text',
					'description' => __( 'Add classes for Row.', 'mini_composer' ),
				)
			)
		),


		'mini_row_inner' => array(
			'name' => 'Row Inner',
			'description' => 'New row to place elements into',
			'icon' => 'mini-icon-row',
			'category' => '',
			'title' => 'Row Inner Settings',
			'is_container' => true,
			'params' => array(
				array(
					'name' => 'row_id',
					'label' => 'Row ID',
					'type' => 'text',
					'value' => __('', 'mini_composer'),
					'description' => 'The unique identifier of the row'
				),
				array(
					'name' => 'row_class',
					'label' => __( 'Extra class name', 'mini_composer' ),
					'type' => 'text',
					'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'mini_composer' ),
				),
				array(
					'name' => 'row_class_container',
					'label' => __( 'Extra container Class', 'mini_composer' ),
					'type' => 'text',
					'description' => __( 'Add class name for container into row.', 'mini_composer' ),
				),
			)
		),

		'mini_column' => array(
			'name' => 'Column',
			'category' => '',
			'title' => 'Column Settings',
			'is_container' => true,
			'system_only' => true,
			'css_box' => true,
			'params' => array(
				array(
					'name' => 'col_container_class',
					'label' => __( 'Container class name', 'mini_composer' ),
					'type' => 'text',
					'description' => __( 'Add class name for container into column.', 'mini_composer' )
				),
				array(
					'name' => 'col_class',
					'label' => __( 'Column class name', 'mini_composer' ),
					'type' => 'text',
					'description' => __( 'Add class name for outer layer of column.', 'mini_composer' )
				)
			)
		),

		'mini_column_inner' => array(
			'name' => 'Column Inner',
			'category' => '',
			'title' => 'Column Inner Settings',
			'is_container' => true,
			'system_only' => true,
			'css_box' => true,
			'params' => array(
				array(
					'name' => 'col_in_class',
					'label' => __( 'Extra class name', 'mini_composer' ),
					'type' => 'text',
					'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'mini_composer' )
				),
				array(
					'name' => 'col_in_class_container',
					'label' => __( 'Extra container Class', 'mini_composer' ),
					'type' => 'text',
					'description' => __( 'Add class name for container into column.', 'mini_composer' ),
				),
			)
		),

		'mini_box' => array(
			'name' => 'Mini Box',
			'category' => '',
			'title' => 'Mini Box Design',
			'icon' => 'mini-icon-box',
			'pop_width' => 900,
			'description' => __( 'Helping design static block', 'mini_composer' ),
			'params' => array(
				array(
					'name' => 'css',
					'type' => 'hidden',
				),
				array(
					'name' => 'data',
					'type' => 'mini_box',
					'admin_label' => true,
					'value' => 'W3sidGFnIjoiZGl2IiwiY2hpbGRyZW4iOlt7InRhZyI6InRleHQiLCJjb250ZW50IjoiU2FtcGxlIFRleHQuIn1dfV0='
					/*This is special element, All will be built in template*/
				),
			)
		),

		'mini_tabs' => array(
			'name' => 'Tabs',
			'description' => __( 'Tabbed content', 'mini_composer' ),
			'category' => '',
			'icon' => 'mini-icon-tabs',
			'title' => 'Tabs Settings',
			'is_container' => true,
			'views' => array(
				'type' => 'views_sections',
				'sections' => 'mini_tab'
			),
			'params' => array(
				array(
					'name' => 'class',
					'label' => 'Extra Class',
					'type' => 'text'
				),
				array(
					'name' => 'type',
					'label' => __('Type', 'mini_composer'),
					'type' => 'select',
					'options' => array(
						'horizontal_tabs' => __('Horizontal Tabs', 'mini_composer'),
						'vertical_tabs' => __('Vertical Tabs', 'mini_composer')
					),
					'description' => __('View tabs with Horizontal or Vertical', 'mini_composer')
				),
				array(
					'name' => 'effect_option',
					'label' => 'Enable fadein effect?',
					'type' => 'checkbox',
					'options' => array(
						'yes' => __('Yes, Please!', 'mini_composer')
					),
					'description' => __('If you want effect fadeIn and fadeOut when click tab', 'mini_composer')
				),
				array(
					'name' => 'vertical_tabs_position',
					'label' => __('Position', 'mini_composer'),
					'type' => 'select',
					'options' => array(
						'left' => __('Left', 'mini_composer'),
						'right' => __('Right', 'mini_composer')
					),
					'relation' => array(
						'parent' => 'type',
						'show_when' => array('vertical_tabs')
					),
					'description' => __('View tabs with at top or bottom', 'mini_composer')
				),
				array(
					'name' => 'open_mouseover',
					'label' => __('Open on mouseover', 'mini_composer'),
					'type' => 'checkbox',
					'options' => array(
						'yes' => __( 'Yes', 'mini_composer' )
					)
				),
				array(
					'name' => 'active_section',
					'label' => __('Active section', 'mini_composer'),
					'type' => 'text',
					'value' => '1',
					'description' => __('Enter active section number.', 'mini_composer')
				)
			),
			'content' => '[mini_tab title="New Tab"][/mini_tab]'
		),

		'mini_tab' => array(
			'name' => 'Tab',
			'category' => 'Content',
			'title' => 'Tab Settings',
			'is_container' => true,
			'system_only' => true,
			'params' => array(
				array(
					'name' => 'title',
					'label' => 'Title',
					'type' => 'text',
				),
				array(
					'name' => 'icon_option',
					'label' => 'Use Icon?',
					'type' => 'checkbox',
					'options' => array(
						'yes' => __('Yes, Please!', 'mini_composer')
					),
					'description' => __('If you want to display an icon beside title, Tick to choose an icon', 'mini_composer')
				),
				array(
					'name' => 'icon',
					'label' => 'Icon Title',
					'type' => 'icon_picker',
					'value' => '',
					'description' => __('Choose an icon to display with title', 'mini_composer'),
					'relation' => array(
						'parent' => 'icon_option',
						'show_when' => 'yes'
					)
				),
				array(
					'name' => 'class',
					'label' => 'Extra Class',
					'type' => 'text'
				)
			)
		),

		'mini_accordion' => array(
			'name' => 'Accordion',
			'description' => __( 'Collapsible content panels', 'mini_composer' ),
			'category' => '',
			'icon' => 'mini-icon-accordion',
			'title' => 'Accordion Settings',
			'is_container' => true,
			'views' => array(
				'type' => 'views_sections',
				'sections' => 'mini_accordion_tab',
				'display' => 'vertical'
			),
			'params' => array(
				array(
					'name' => 'title',
					'label' => 'Title',
					'type' => 'text',
					'description' => __('Enter text used as widget title (Note: located above content element).', 'mini_composer')
				),
				array(
					'name' => 'open_all',
					'label' => 'Collapse all?',
					'type' => 'checkbox',
					'options' => array(
						'yes' => __('Yes, Please!', 'mini_composer')
					),
					'description' => __('Allow all accordion tabs able to open', 'mini_composer')
				),
				array(
					'name' => 'class',
					'label' => 'Extra class name',
					'type' => 'text',
					'description' => __('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'mini_composer')
				)
			),
			'content' => '[mini_accordion_tab title="Accordion Tab"][/mini_accordion_tab]'
		),

		'mini_accordion_tab' => array(
			'name' => 'Accordion Tab',
			'category' => 'Content',
			'title' => 'Accordion Tab Settings',
			'is_container' => true,
			'system_only' => true,
			'params' => array(
				array(
					'name' => 'title',
					'label' => __('Title', 'mini_composer'),
					'type' => 'text'
				),
				array(
					'name' => 'icon_option',
					'label' => 'Use Icon?',
					'type' => 'checkbox',
					'options' => array(
						'yes' => __('Yes, Please!', 'mini_composer')
					),
					'description' => __('If you want to display an icon beside title, Tick to choose an icon', 'mini_composer')
				),
				array(
					'name' => 'icon',
					'label' => 'Icon Title',
					'type' => 'icon_picker',
					'value' => '',
					'description' => __('Choose an icon to display with title', 'mini_composer'),
					'relation' => array(
						'parent' => 'icon_option',
						'show_when' => 'yes'
					)
				),
				array(
					'name' => 'class',
					'label' => 'Extra class name',
					'type' => 'text',
					'description' => __('', 'mini_composer')
				)
			)
		),

		'mini_column_text' => array(
			'name' => 'Text Block',
			'description' => __('A block of text with TINYMCE editor', 'mini_composer'),
			'icon' => 'mini-icon-text',
			'category' => 'Content',
			'is_container' => true,
			'pop_width' => 750,
			'admin_view'	=> 'text',
			'preview_editable' => true,
			'params' => array(
				array(
					'name' => 'content',
					'label' => 'Content',
					'type' => 'textarea_html',
					'value' => 'Sample Text',
				),
				array(
					'name' => 'class',
					'label' => 'Extra Class',
					'type' => 'text',
				)
			)
		),

		'mini_spacing' => array(
			'name' => 'Spacing',
			'description' => __('Custom the spacing between the blocks', 'mini_composer'),
			'icon' => 'mini-icon-spacing',
			'category' => 'Content',
			'params' => array(
				array(
					'name' => 'height',
					'label' => 'Height',
					'type' => 'number_slider',
					'value' => '20',
					'options' => array(
						'min' => 0,
						'max' => 200,
						'unit' => 'px',
						'show_input' => true
					),
					'admin_label' => true,
					'description' => __('Enter the value of spacing height', 'mini_composer'),
				),
				array(
					'name' => 'class',
					'label' => __('Extra Class', 'mini_composer'),
					'type' => 'text',
					'description' => __('Style particular content element differently - add a class name and refer to it in custom CSS.', 'mini_composer')
				)
			)
		),

		'mini_raw_code' => array(
			'name' => 'Raw Code',
			'description' => __('Allow to put code: html, shortcode', 'mini_composer'),
			'icon' => 'mini-icon-code',
			'category' => 'Content',
			'pop_width' => 750,
			'params' => array(
				array(
					'name' => 'code',
					'label' => 'Code',
					'type' => 'textarea',
					'value' => 'U2FtcGxlIENvZGU=',
					'admin_label' => true,
				)
			)
		),

		'mini_single_image' => array(
			'name' => 'Single Image',
			'description' => __('Single image', 'mini_composer'),
			'icon' => 'mini-icon-image',
			'category' => 'Content',
			'admin_view' => 'image',
			'preview_editable' => true,
			'css_box'	=> true,
			'params' => array(

				array(
					'name'    => 'image_source',
					'label'   => __('Image Source', 'mini_composer'),
					'type'    => 'select',
					'options' => array(
						'media_library'  => __('Media library', 'mini_composer'),
						'external_link'  => __('External link', 'mini_composer'),
						'featured_image' => __('Featured Image', 'mini_composer'),
					),
					'description' => __('Select source image.', 'mini_composer')
				),
				array(
					'name'        => 'image',
					'label'       => 'Upload Image',
					'type'        => 'attach_image',
					'admin_label' => true,
					'relation'    => array(
						'parent'    => 'image_source',
						'show_when' => 'media_library'
					)
				),
				array(
					'name'     => 'image_external_link',
					'label'    => 'Image external link',
					'type'     => 'text',
					'relation' => array(
						'parent'    => 'image_source',
						'show_when' => 'external_link'
					),
					'description' => __('Enter external link.', 'mini_composer')
				),
				array(
					'name'          => 'image_size',
					'label'         => 'Image Size',
					'type'          => 'text',
					'value'         => 'thumbnail',
					'relation'      => array(
						'parent'    => 'image_source',
						'show_when' => array('media_library', 'featured_image')
					),
					'description'   => __('Example: "thumbnail", "medium", "large", "full"', 'mini_composer'),
					'value'         => 'full'
				),
				array(
					'name'          => 'image_size_el',
					'label'         => 'Image Size',
					'type'          => 'text',
					'relation'      => array(
						'parent'    => 'image_source',
						'show_when' => 'external_link'
					),
					'description'   => __('Enter image size in pixels. Example: 200x100 (Width x Height).', 'mini_composer')
				),
				array(
					'name'        => 'caption',
					'label'       => 'Caption',
					'type'        => 'text',
					'description' => __('Enter text for image caption.', 'mini_composer')
				),
				array(
					'name'    => 'image_align',
					'label'   => 'Image alignment',
					'type'    => 'select',
					'options' => array(
						'left'   => __('Left', 'mini_composer'),
						'right'  => __('Right', 'mini_composer'),
						'center' => __('Center', 'mini_composer')
					),
					'description' => __('Select image alignment.', 'mini_composer')
				),
				array(
					'name'    => 'on_click_action',
					'label'   => __('On click action', 'mini_composer'),
					'type'    => 'select',
					'options' => array(
						''                 => __('None', 'mini_composer'),
						'op_large_image'   => __('Link to large image', 'mini_composer'),
						'lightbox'         => __('Open Image In Lightbox', 'mini_composer'),
						'open_custom_link' => __('Open Custom Link', 'mini_composer')
					),
					'description' => __('Select action for click action..', 'mini_composer')
				),
				array(
					'name'     => 'custom_link',
					'label'    => __('Custom Link', 'mini_composer'),
					'type'     => 'text',
					'value'    => 'http://',
					'relation' => array(
						'parent'    => 'on_click_action',
						'show_when' => 'open_custom_link'
					),
					'description' => __('Enter URL if you want this image to have a link (Note: parameters like "mailto:" are also accepted).', 'mini_composer')
				),
				array(
					'name'        => 'class',
					'label'       => __('Extra Class', 'mini_composer'),
					'type'        => 'text',
					'description' => __('Style particular content element differently - add a class name and refer to it in custom CSS.', 'mini_composer')
				)
			)
		),

		'mini_icon' => array(
			'name'		  => 'Icon',
			'description' => __('Display single icon', 'mini_composer'),
			'icon'		  => 'mini-icon-icon',
			'category'	  => 'Content',
			'params'	  => array(
				array(
					'name'	      => 'icon',
					'label'	      => 'Select Icon',
					'type'	      => 'icon_picker',
					'admin_label' => true,
				),
				array(
					'name'	      => 'icon_align',
					'label'	      => 'Icon alignment',
					'type'	      => 'dropdown',
					'description' => __('', 'mini_composer'),
					'options'     => array(
						'none'    => __('None', 'mini_composer'),
						'left'    => __('Left', 'mini_composer'),
						'right'   => __('Right', 'mini_composer'),
						'center'  => __('Center', 'mini_composer'),
					)
				),
				array(
					'name'	      => 'icon_size',
					'label'	      => 'Icon Size',
					'type'	      => 'text',
					'admin_label' => true,
					'description' => __('Enter font-size for icon such as: 15px, 1em ..etc..', 'mini_composer')
				),
				array(
					'name'	      => 'icon_color',
					'label'	      => 'Icon Color',
					'type'	      => 'color_picker',
					'admin_label' => true,
					'description' => __('Set color for icon', 'mini_composer')
				),
				array(
					'name'	      => 'class',
					'label'	      => __('Extra Class', 'mini_composer'),
					'type'	      => 'text',
					'admin_label' => true,
					'description' => __('Style particular content element differently - add a class name and refer to it in custom CSS.', 'mini_composer')
				),
				array(
					'name'	      => 'icon_wrap',
					'label'	      => 'Icon Wrapper?',
					'type'	      => 'checkbox',
					'options'	  => array(
						'yes'     => __('Yes, Please!', 'mini_composer')
					),
					'description' => __('Would you like a tag <div> surrounded icon', 'mini_composer')
				),
				array(
					'name'	        => 'icon_wrap_class',
					'label'	        => 'Wrapper class name',
					'type'	        => 'text',
					'description'   => __('Enter class name for wrapper', 'mini_composer'),
					'relation'      => array(
						'parent'    => 'icon_wrap',
						'show_when' => 'yes'
					)
				),
			)
		),

		'mini_title' => array(
			'name'		  => 'Title',
			'description' => __('Heading titles H(n) Tag', 'mini_composer'),
			'icon'		  => 'mini-icon-title',
			'category'	  => 'Content',
			'css_box'	  => true,
			'params'	  => array(
				array(
					'name'	      => 'text',
					'label'       => 'Text',
					'type'	      => 'textarea',
					'admin_label' => true
				),
				array(
					'name'	  => 'type',
					'label'   => 'Type',
					'type'	  => 'select',
					'options' => array(
						'h1'  => 'H1',
						'h2'  => 'H2',
						'h3'  => 'H3',
						'h4'  => 'H4',
						'h5'  => 'H5',
						'h6'  => 'H6'
					)
				),
				array(
					'name'	=> 'class',
					'label' => 'Extra Class',
					'type'	=> 'text'
				),
				array(
					'name'	      => 'title_wrap',
					'label'       => 'Head Wrapper?',
					'type'	      => 'checkbox',
					'options'     => array(
						'yes'     => __('Yes, Please!', 'mini_composer')
					),
					'description' => __('Would you like a tag <div> surrounded head tag?', 'mini_composer')
				),
				array(
					'name'	        => 'title_wrap_class',
					'label'         => 'Wrapper class name',
					'type'	        => 'text',
					'description'   => __('Enter class name for wrapper', 'mini_composer'),
					'relation'      => array(
						'parent'    => 'title_wrap',
						'show_when' => 'yes'
					)
				)
			)
		),

		'mini_google_maps' => array(

			'name'			   => __('Google Maps', 'mini_composer'),
			'description'	   => __('Show google maps with embed', 'mini_composer'),
			'icon'			   => 'mini-icon-map',
			'category'		   => 'Content',
			'pop_width'		   => '650',
			'admin_view'	   => 'gmaps',
			'preview_editable' => true,
			'params'		   => array(
				array(
					'name'        => 'random_id',
					'label'       => '',
					'type'        => 'random',
					'description' => '',
				),
				array(
					'type'			=>  'text',
					'label'			=> __( 'Map Title', 'mini_composer' ),
					'name'			=> 'title',
					'description'	=> __( 'Title of map. leave empty to hidden', 'mini_composer' ),
				),
				array(
					'type'			=> 'google_map',
					'label'			=> __( 'Map Location', 'mini_composer' ),
					'name'			=> 'map_location',
					'value'			=> '21.034856055581216|105.78365346708983|9',
					'description'	=> __( 'Search your location on google map, Drag the spotlight to your location.', 'mini_composer' )
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Disable wheel mouse', 'mini_composer' ),
					'name'			=> 'disable_wheel_mouse',
					'description'	=> __( 'Disable wheel mouse on google maps', 'mini_composer' ),
					'options'			=> array( 'yes' => __( 'Yes', 'mini_composer' ) )
				),
				array(
					'type'			 => 'number_slider',
					'label'			 => __( 'Map Height', 'mini_composer' ),
					'name'			 => 'map_height',
					'description'	 => __( 'Height of map. For example: 350 (px)', 'mini_composer' ),
					'value'			 => '350',
					'options'        => array(
						'min'        => 50,
						'max'        => 1000,
						'unit'       => 'px',
						'show_input' => true
					)
				),
				array(
					'type'			     => 'checkbox',
					'label'			     => __( 'Show overlap contact form', 'mini_composer' ),
					'name'			     => 'show_ocf',
					'description'	     => __( 'Enable contact form above the maps', 'mini_composer' ),
					'options'			 => array( 'yes' => __( 'Yes', 'mini_composer' ) )
				),
				array(
					'type'			     => 'textarea',
					'label'			     => __( 'Contact form shortcode', 'mini_composer' ),
					'name'			     => 'contact_form_sc',
					'description'	     => __( 'Shortcode content which generated by contact form 7', 'mini_composer' ),
					'relation'		     => array(
						'parent'         => 'show_ocf',
						'show_when'      => 'yes'
					)
				),
				array(
					'type'			 => 'text',
					'label'			 => __( 'Contact area width', 'mini_composer' ),
					'name'			 => 'contact_area_width',
					'description'	 => __( 'Width of wrapper form. Ex: 45% or 400px', 'mini_composer' ),
					'relation'		 => array(
						'parent'     => 'show_ocf',
						'show_when'  => 'yes'
					),
					'value'			 => '45%'
				),
				array(
					'type'			 => 'select',
					'label'			 => __( 'Contact area position', 'mini_composer' ),
					'name'			 => 'contact_area_position',
					'options'		 => array(
						'left'  => __( 'Left', 'mini_composer' ),
						'right' => __( 'Right', 'mini_composer' ),
					),
					'description'	=> __( 'Position of contact form box', 'mini_composer' ),
					'relation'		=> array(
						'parent' => 'show_ocf',
						'show_when' => 'yes'
					),
					'value'			=> 'left'
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Contact area background', 'mini_composer' ),
					'name'			=> 'contact_area_bg',
					'description'	=> __( 'Background color of form', 'mini_composer' ),
					'relation'		=> array(
						'parent' => 'show_ocf',
						'show_when' => 'yes'
					),
					'value' 		=> '#a1aee2'
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Contact form color', 'mini_composer' ),
					'name'			=> 'contact_form_color',
					'description'	=> __( 'Global color in contact form', 'mini_composer' ),
					'relation'		=> array(
						'parent' => 'show_ocf',
						'show_when' => 'yes'
					),
					'value' 		=> '#3c3c3c'
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Submit button color', 'mini_composer' ),
					'name'			=> 'submit_button_color',
					'description'	=> __( '', 'mini_composer' ),
					'relation'		=> array(
						'parent' => 'show_ocf',
						'show_when' => 'yes'
					),
					'value' 		=> '#393939'
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Submit button hover color', 'mini_composer' ),
					'name'			=> 'submit_button_hover_color',
					'description'	=> __( '', 'mini_composer' ),
					'relation'		=> array(
						'parent' => 'show_ocf',
						'show_when' => 'yes'
					),
					'value' 		=> '#575757'
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Submit button text color', 'mini_composer' ),
					'name'			=> 'submit_button_text_color',
					'description'	=> __( '', 'mini_composer' ),
					'relation'		=> array(
						'parent' => 'show_ocf',
						'show_when' => 'yes'
					),
					'value' 		=> '#FFFFFF'
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Submit button text hover color', 'mini_composer' ),
					'name'			=> 'submit_button_text_hover_color',
					'description'	=> __( '', 'mini_composer' ),
					'relation'		=> array(
						'parent' => 'show_ocf',
						'show_when' => 'yes'
					),
					'value' 		=> '#FFFFFF'
				),
				array(
					'type'			=>  'text',
					'label'			=> __( 'Wrapper class name', 'mini_composer' ),
					'name'			=> 'wrap_class',
					'description'	=> __( 'Custom class for wrapper of shortcode widget', 'mini_composer' ),
				),
			)
		),

		'mini_twitter_feed' => array(
			'name'			=> __('Twitter Feed', 'mini_composer'),
			'description'	=> __('New tweets from twitter', 'mini_composer'),
			'icon' => 'mini-icon-twitter',
			'category' => 'Content',
			'css_box' => true,
			'params' => array(
				array(
					'type'			=>  'text',
					'label'			=> __( 'Twitter Title', 'mini_composer' ),
					'name'			=> 'title',
					'description'	=> __( 'Title of twitter widget. leave empty to hidden', 'mini_composer' ),
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Username', 'mini_composer' ),
					'name'			=> 'username',
					'value'			=> 'mini_composer',
					'admin_label'	=> true
				),
				array(
					'type'			=> 'dropdown',
					'label'			=> __( 'Display Style', 'mini_composer' ),
					'name'			=> 'display_style',
					'options'			=> array(
						'1' => __( 'List View', 'mini_composer' ),
						'2' => __( 'Slider tweets', 'mini_composer' ),
					),
					'admin_label'	=> true
				),
				array(
					'type'			=> 'number_slider',
					'label'			=> __( 'Box max height', 'mini_composer' ),
					'name'			=> 'max_height',
					'description'	=> __( 'Auto scroll will show when height of twitter list larger then max height, Unit (px). Leave blank for show all. (min:100px, max: 800px).', 'mini_composer' ),
					'value'			=> '350',
					'options'		=> array(
						'min' => 100,
						'max' => 800,
						'unit' => 'px',
						'show_input' => true
					),
					'relation' 		=> array(
						'parent'	=> 'display_style',
						'show_when' => '1'
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show navigation', 'mini_composer' ),
					'name'			=> 'show_navigation',
					'options'		=> array( 'yes' => __( 'Yes, Please!', 'mini_composer' ) ),
					'value'			=> 'yes',
					'relation'		=> array(
						'parent'	=> 'display_style',
						'show_when'	=> '2'
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show pagination', 'mini_composer' ),
					'name'			=> 'show_pagination',
					'options'		=> array( 'yes' => __( 'Yes, Please!', 'mini_composer' ) ),
					'value'			=> 'yes',
					'relation'		=> array(
						'parent'	=> 'display_style',
						'show_when'	=> '2'
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Auto height', 'mini_composer' ),
					'name'			=> 'auto_height',
					'options'		=> array( 'yes' => __( 'Yes, Please!', 'mini_composer' ) ),
					'relation'		=> array(
						'parent'	=> 'display_style',
						'show_when'	=> '2'
					)
				),
				array(
					'type'			=> 'number_slider',
					'label'			=> __( 'Number Tweet', 'mini_composer' ),
					'name'			=> 'number_tweet',
					'admin_label'	=> true,
					'value'			=> '5',
					'options' 		=> array(
						'min' => 1,
						'max' => 20
					)
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Link color', 'mini_composer' ),
					'name'			=> 'link_color',
					'description'	=> __( 'Color for author name', 'mini_composer' ),
					'value'			=> '#f7d377'
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Link color hover', 'mini_composer' ),
					'name'			=> 'link_color_hover',
					'description'	=> __( 'Hover color for author name', 'mini_composer' ),
					'value'			=> '#454545'
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show Time', 'mini_composer' ),
					'name'			=> 'show_time',
					'description'	=> __( 'Show hiden time "30m ago"', 'mini_composer' ),
					'options'		=> array( 'yes' => __( 'Yes', 'mini_composer' ) ),
					'value'			=> 'yes'
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show reply link', 'mini_composer' ),
					'name'			=> 'show_reply',
					'description'	=> __( 'Show/Hide reply link for each tweet', 'mini_composer' ),
					'options'		=> array( 'yes' => __( 'Yes', 'mini_composer' ) ),
					'value'			=> 'yes'
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Allow Retweet', 'mini_composer' ),
					'name'			=> 'show_retweet',
					'description'	=> __( 'Show/Hide retweet link for each tweet', 'mini_composer' ),
					'options'		=> array( 'yes' => __( 'Yes', 'mini_composer' ) ),
					'value'			=> 'yes'
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show twitter avatar', 'mini_composer' ),
					'name'			=> 'show_avatar',
					'description'	=> __( 'Show /Hide avatar beside each tweet', 'mini_composer' ),
					'options'		=> array( 'yes' => __( 'Yes', 'mini_composer' ) ),
					'relation' 		=> array(
						'parent'	=> 'display_style',
						'show_when' => '1'
					),
					'value'			=> 'yes'
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show follow button', 'mini_composer' ),
					'name'			=> 'show_follow_button',
					'options'		=> array( 'yes' => __( 'Yes, Please!', 'mini_composer' ) ),
					'value'			=> 'yes'
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Use Own API Key', 'mini_composer' ),
					'name'			=> 'use_api_key',
					'options'		=> array( 'yes' => __( 'Yes, Please!', 'mini_composer' ) )
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Consumer Key (API Key)', 'mini_composer' ),
					'name'			=> 'consumer_key',
					'value'			=> '',
					'relation'		=> array(
						'parent' => 'use_api_key',
						'show_when' => 'yes'
					)
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Consumer Secret (API Secret)', 'mini_composer' ),
					'name'			=> 'consumer_secret',
					'value'			=> '',
					'relation'		=> array(
						'parent' => 'use_api_key',
						'show_when' => 'yes'
					)
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Access Token', 'mini_composer' ),
					'name'			=> 'access_token',
					'value'			=> '',
					'relation'		=> array(
						'parent' => 'use_api_key',
						'show_when' => 'yes'
					)
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Access Token Secret', 'mini_composer' ),
					'name'			=> 'access_token_secrect',
					'value'			=> '',
					'relation'		=> array(
						'parent' => 'use_api_key',
						'show_when' => 'yes'
					)
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Wrapper class name', 'mini_composer' ),
					'name'			=> 'wrap_class',
					'description'	=> __( 'Custom class for wrapper of shortcode widget', 'mini_composer' ),
					'value'			=> ''
				)
			)
		),

		/* Just for test icon
		---------------------------------------------------------- */

		'mini_instagram_feed' => array(

			'name' => __('Instagram Feed', 'mini_composer'),
			'description' => __('', 'mini_composer'),
			'icon' => 'mini-icon-instagram',
			'category' => 'Content',
			'css_box' => true,
			'params' => array(
				array(
					'type'			=> 'text',
					'label'			=> __( 'Title', 'mini_composer' ),
					'name'			=> 'title',
					'description'	=> __( 'This is text title. Leave blank if no title is needed.', 'mini_composer' ),
					'admin_label'	=> true
				),
				array(
					'type'			=> 'number_slider',
					'label'			=> __( 'Number of photos', 'mini_composer' ),
					'name'			=> 'number_show',
					'description'	=> __( 'The media image how many image will display', 'mini_composer' ),
					'value'			=> '8',
					'options' => array(
						'min' => 1,
						'max' => 16
					),
					'admin_label'	=> true,
				),
				array(
					'type'			=> 'dropdown',
					'label'			=> __( 'Number of Columns', 'mini_composer' ),
					'name'			=> 'columns_style',
					'options'			=> array(
						'1' => __( '1 Columns', 'mini_composer' ),
						'2' => __( '2 Columns', 'mini_composer' ),
						'3' => __( '3 Columns', 'mini_composer' ),
						'4' => __( '4 Columns', 'mini_composer' ),
						'5' => __( '5 Columns', 'mini_composer' ),
						'6' => __( '6 Columns', 'mini_composer' )
					),
					'description'	=> __( 'Note: The width is large enough to display in columns.', 'mini_composer' ),
					'value'			=> '4'
				),
				array(
					'type'			=> 'dropdown',
					'label'			=> __( 'Image Size', 'mini_composer' ),
					'name'			=> 'image_size',
					'description'	=> __( '', 'mini_composer' ),
					'options'		=> array(
						'low_resolution' => 'Low resolution',
						'thumbnail' => 'Thumbnail',
						'standard_resolution' => 'Standard resolution',
					)
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Username', 'mini_composer' ),
					'name'			=> 'username',
					'description'	=> __( 'Username from Instagaram', 'mini_composer' ),
					'admin_label'	=> true
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Access token', 'mini_composer' ),
					'name'			=> 'access_token',
					'description'	=> __( 'It is key, the Instagram API requires authentication, get Access token here http://instagram.pixelunion.net/', 'mini_composer' ),
					'value'			=> ''
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Custom class name', 'mini_composer' ),
					'name'			=> 'wrap_class',
					'description'	=> __( 'Custom class for wrapper of shortcode widget', 'mini_composer' ),
				)
			)

		),

		'mini_fb_recent_post' => array(

			'name' => __('FaceBook Post', 'mini_composer'),
			'description' => __('', 'mini_composer'),
			'icon' => 'mini-icon-facebook',
			'category' => 'Content',
			//'css_box' => true,
			'params' => array(
				array(
					'type'			=> 'text',
					'label'			=> __( 'Title', 'mini_composer' ),
					'name'			=> 'title',
					'description'	=> __( 'This is text title. Leave blank if no title is needed.', 'mini_composer' ),
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Facebook Page slug', 'mini_composer' ),
					'name'			=> 'fb_page_id',
					'description'	=> __( 'Facebook page ID or slug. For example: wordpress', 'mini_composer' ),
					'admin_label'	=> true
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Facebook App ID', 'mini_composer' ),
					'name'			=> 'fb_app_id',
					'description'	=> __( 'Get your App ID from developers.facebook.com/apps.', 'mini_composer' ),
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Facebook App Secret', 'mini_composer' ),
					'name'			=> 'fb_app_secret',
					'description'	=> __( 'Get your App Secret from developers.facebook.com/apps.', 'mini_composer' ),
				),
				array(
					'type'			=> 'number_slider',
					'label'			=> __( 'Box max height', 'mini_composer' ),
					'name'			=> 'max_height',
					'description'	=> __( 'Auto scroll will show when height of facebook post list larger then max height. Unit (px)', 'mini_composer' ),
					'value'			=> '350',
					'options' => array(
						'min' => 50,
						'max' => 1000,
						'unit' => 'px',
						'show_input' => true
					)
				),
				array(
					'type'			=> 'number_slider',
					'label'			=> __( 'Number Post Show', 'mini_composer' ),
					'name'			=> 'number_post_show',
					'description'	=> __( 'The number of post from fan page facebook', 'mini_composer' ),
					'value'			=> '5',
					'admin_label'	=> true,
					'options' => array(
						'min' => 1,
						'max' => 10
					)
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Number word of description Show', 'mini_composer' ),
					'name'			=> 'number_of_des',
					'description'	=> __( 'The number of description from post facebook, Leave this field for full description. Ex 25', 'mini_composer' ),
					'value'			=> '25'
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show Image?', 'mini_composer' ),
					'name'			=> 'show_image',
					'description'	=> __( 'Show image in the post from facebook', 'mini_composer' ),
					'options'		=> array( 'yes' => __( 'Yes, Please!', 'mini_composer' ) ),
					'value'			=> 'yes'
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Button Like Count?', 'mini_composer' ),
					'name'			=> 'show_like_count',
					'description'	=> __( 'Show like count button in the post from facebook', 'mini_composer' ),
					'options'		=> array( 'yes' => __( 'Yes, Please!', 'mini_composer' ) ),
					'value'			=> 'yes'
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Button Comment Count?', 'mini_composer' ),
					'name'			=> 'show_comment_count',
					'description'	=> __( 'Show comment count button in the post from facebook', 'mini_composer' ),
					'options'		=> array( 'yes' => __( 'Yes, Please!', 'mini_composer' ) ),
					'value'			=> 'yes'
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Time', 'mini_composer' ),
					'name'			=> 'show_time',
					'description'	=> __( 'Show time in the post from facebook', 'mini_composer' ),
					'options'		=> array( 'yes' => __( 'Yes, Please!', 'mini_composer' ) ),
					'value'			=> 'yes'
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Open link new window', 'mini_composer' ),
					'name'			=> 'open_link_new_window',
					'description'	=> __( 'Link to post of facebook will open on new window if checked', 'mini_composer' ),
					'options'		=> array( 'yes' => __( 'Yes, Please!', 'mini_composer' ) ),
					'value'			=> 'yes'
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show profile button', 'mini_composer' ),
					'name'			=> 'show_profile_button',
					'description'	=> __( 'Show profile button below facebook list post box', 'mini_composer' ),
					'options'		=> array( 'yes' => __( 'Yes, Please!', 'mini_composer' ) ),
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Custom class name', 'mini_composer' ),
					'name'			=> 'wrap_class',
					'description'	=> __( 'Custom class for wrapper of shortcode widget', 'mini_composer' ),
				)
			)

		),

		'mini_flip_box' => array(
			'name' => __('Flip Box', 'mini_composer'),
			'description' => __('', 'mini_composer'),
			'icon' => 'mini-icon-flip',
			'category' => 'Content',
			'css_box' => true,
			'params' => array(

				array(
					'type'			=> 'attach_image',
					'label'			=> __( 'Front Image', 'mini_composer' ),
					'name'			=> 'image',
					'description'	=> __( 'Upload image for front face image', 'mini_composer' ),
					'admin_label'	=> true
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Image size', 'mini_composer' ),
					'name'			=> 'image_size',
					'description'	=> __( 'Add your image size, For example: thumbnail, medium, large, full)', 'mini_composer' ),
					'admin_label'	=> true,
					'value'			=> 'full'
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Title', 'mini_composer' ),
					'name'			=> 'title',
					'description'	=> __( 'This is text title. Leave blank if no title is needed.', 'mini_composer' ),
					'admin_label'	=> true
				),
				array(
					'type'			=> 'textarea',
					'label'			=> __( 'Description', 'mini_composer' ),
					'name'			=> 'description',
					'description'	=> __( 'Enter content description for back side, support shortcode in this field.', 'mini_composer' ),
				),
				array(
					'type'			=> 'dropdown',
					'label'			=> __( 'Text align', 'mini_composer' ),
					'name'			=> 'text_align',
					'options'		=> array(
						'center' => __( 'Center', 'mini_composer' ),
						'left' => __( 'Left', 'mini_composer' ),
						'right' => __( 'Right', 'mini_composer' ),
						'justtify' => __( 'Justtify', 'mini_composer' ),
					),
					'description'	=> __( 'Options: Center, left, right, justtify', 'mini_composer' ),
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Text Color', 'mini_composer' ),
					'name'			=> 'text_color',
					'description'	=> __( 'Color for text', 'mini_composer' ),
					'value'			=> '#FFFFFF'
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Background Back side', 'mini_composer' ),
					'name'			=> 'bg_backside',
					'description'	=> __( 'Background color for back side', 'mini_composer' ),
					'value'			=> '#393939'
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show button', 'mini_composer' ),
					'name'			=> 'show_button',
					'description'	=> __( 'Display button when checked this', 'mini_composer' ),
					'options'			=> array( 'yes' => __( 'Yes, Please', 'mini_composer' ) ),
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Text on button', 'mini_composer' ),
					'name'			=> 'text_on_button',
					'description'	=> __( 'Show text on the button', 'mini_composer' ),
					'relation'	=> array(
						'parent' => 'show_button',
						'show_when' => 'yes'
					),
					'value'			=> 'Read more'
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Link', 'mini_composer' ),
					'name'			=> 'link',
					'description'	=> __( 'Link for button in Back side', 'mini_composer' ),
					'value'			=> '#',
					'relation'	=> array(
						'parent' => 'show_button',
						'show_when' => 'yes'
					)
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Text button color', 'mini_composer' ),
					'name'			=> 'text_button_color',
					'description'	=> __( 'Text button color', 'mini_composer' ),
					'relation'	=> array(
						'parent' => 'show_button',
						'show_when' => 'yes'
					),
					'value'			=> '#FFFFFF'
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Button background color', 'mini_composer' ),
					'name'			=> 'button_bg_color',
					'description'	=> __( 'Background color for button. (Default: transparent)', 'mini_composer' ),
					'relation'	=> array(
						'parent' => 'show_button',
						'show_when' => 'yes'
					),
					'value'			=> 'transparent'
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Button background color hover', 'mini_composer' ),
					'name'			=> 'button_bg_hover_color',
					'description'	=> __( 'Background color for button when hover', 'mini_composer' ),
					'relation'	=> array(
						'parent' => 'show_button',
						'show_when' => 'yes'
					),
					'value'			=> '#FFFFFF'
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Text button color hover', 'mini_composer' ),
					'name'			=> 'text_button_color_hover',
					'description'	=> __( 'Text button color hover', 'mini_composer' ),
					'relation'	=> array(
						'parent' => 'show_button',
						'show_when' => 'yes'
					),
					'value'			=> '#86c724'
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Wrapper class name', 'mini_composer' ),
					'name'			=> 'wrap_class',
					'description'	=> __( 'Custom class for wrapper of shortcode widget', 'mini_composer' ),
					'value'			=> ''
				)
			)

		),

		'mini_pie_chart' => array(
			'name' => __('Pie Chart', 'mini_composer'),
			'description' => __('', 'mini_composer'),
			'icon' => 'mini-icon-pie',
			'category' => 'Content',
			'params'		=> array(

				array(
					'type'			=> 'number_slider',
					'label'			=> __( 'Percent number', 'mini_composer' ),
					'name'			=> 'percent',
					'description'	=> __( 'Drag slider for select percent number', 'mini_composer' ),
					'admin_label'	=> true,
					'value' 		=> '50',
					'options'		=> array(
						'unit'		=> '%',
						'show_input'=> true
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Rounded corners bar', 'mini_composer' ),
					'name'			=> 'rounded_corners_bar',
					'description'	=> __( 'Show rounded corners bar', 'mini_composer' ),
					'options'		=> array( 'yes' => __( 'Yes, Please!', 'mini_composer' ) ),
				),
				array(
					'type'			=> 'dropdown',
					'label'			=> __( 'Pie Size', 'mini_composer' ),
					'name'			=> 'size',
					'description'	=> __( 'Select size for Pie', 'mini_composer' ),
					'options'			=> array(
						'100' 		=> __('100 px', 'mini_composer'),
						'150' 		=> __('150 px', 'mini_composer'),
						'200' 		=> __('200 px', 'mini_composer'),
						'custom' 	=> __('Custom', 'mini_composer'),
						'auto'		=> __( 'Auto width', 'mini_composer' )
					)
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Custom size', 'mini_composer' ),
					'name'			=> 'custom_size',
					'description'	=> __( 'It is width and height of pie chart, unit (px).', 'mini_composer' ),
					'admin_label'	=> true,
					'relation' 	=> array(
						'parent' 	=> 'size',
						'show_when' => 'custom'
					),
					'value'			=> '120'
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Title', 'mini_composer' ),
					'name'			=> 'title',
					'description'	=> __( 'Label title for Pie', 'mini_composer' ),
					'admin_label'	=> true
				),
				array(
					'type'			=> 'textarea',
					'label'			=> __( 'Description', 'mini_composer' ),
					'name'			=> 'description',
					'description'	=> __( 'Some text for description will show below title', 'mini_composer' ),
				),

				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Bar Color', 'mini_composer' ),
					'name'			=> 'barcolor',
					'description'	=> __( 'Color for bar pie in canvas', 'mini_composer' ),
					'value'			=> '#39c14f'
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Track Color', 'mini_composer' ),
					'name'			=> 'trackcolor',
					'description'	=> __( 'Color for track pie in canvas', 'mini_composer' ),
					'value'			=> '#e4e4e4'
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Label color', 'mini_composer' ),
					'name'			=> 'label_color',
					'description'	=> __( 'Color for percent number color', 'mini_composer' ),
					'value'			=> '#FF5252'
				),
				array(
					'type'			=> 'number_slider',
					'label'			=> __( 'Label front size', 'mini_composer' ),
					'name'			=> 'label_font_size',
					'description'	=> __( 'Label front size, default: 20px', 'mini_composer' ),
					'value'			=> '20',
					'options'		=> array(
						'unit'		=> 'px',
						'show_input'=> true
					)
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Wrapper class name', 'mini_composer' ),
					'name'			=> 'wrap_class',
					'description'	=> __( 'Custom class for wrapper of shortcode widget', 'mini_composer' ),
				)
			)

		),
		'mini_progress_bars' => array(

			'name' => __('Progress Bar', 'mini_composer'),
			'description' => __('', 'mini_composer'),
			'icon' => 'mini-icon-progress',
			'category' => 'Content',
			'params' => array(

				array(
					'type'			=> 'text',
					'label'			=> __( 'Title', 'mini_composer' ),
					'name'			=> 'title',
					'description'	=> __( 'This is text title. Leave blank if no title is needed.', 'mini_composer' ),
					'admin_label'	=> true,
				),
				array(
					'type'			=> 'dropdown',
					'label'			=> __( 'Style', 'mini_composer' ),
					'name'			=> 'style',
					'description'	=> __( 'Select style for progress bars', 'mini_composer' ),
					'options'		=> array(
						'1' => __('Style 1', 'mini_composer'),
						'2' => __('Style 2 (Value in tooltip)', 'mini_composer'),
						'3' => __('Style 3 (Fixed height width 20px)', 'mini_composer'),
						'4' => __('Style 4 (Border radius)', 'mini_composer'),
					),
					'admin_label'	=> true,
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Processbar Animate', 'mini_composer' ),
					'name'			=> 'progress_animate',
					'description'	=> __( 'Animate effect if checked', 'mini_composer' ),
					'options'			=> array( 'yes' => __( 'Yes, Please!', 'mini_composer' ) ),
					'value' 			=> 'yes'
				),
				array(
					'type'			=> 'number_slider',
					'label'			=> __( 'Processbar Weight', 'mini_composer' ),
					'name'			=> 'weight',
					'description'	=> __( 'Height weight of progress bar: Ex 12, unit (px)', 'mini_composer' ),
					'value'			=> '12',
					'options' 		=> array(
						'min'		=> 2,
						'max'		=> 40,
						'unit'		=> 'px',
						'show_input'=> true
					),
					'relation'		=> array(
						'parent'	=> 'style',
						'show_when' => array(1,2)
					)
				),
				array(
					'type'			=> 'group',
					'label'			=> __('Options', 'mini_composer'),
					'name'			=> 'options',
					'description'	=> __( 'Repeat this fields with each item created, Each item corresponding processbar element.', 'mini_composer' ),
					'value' => base64_encode( json_encode(array(
						"1" => array(
							"value" => "90",
							"value_color" => "#999999",
							"label" => "Development",
							"label_color" => "#0d6347",
							"prob_color" => "#1a6c9c",
							"prob_bg_color" => "#dbdbdb"
						),
						"2" => array(
							"value" => "80",
							"value_color" => "#626a0d",
							"label" => "Design",
							"label_color" => "#0d6347",
							"prob_color" => "#1a6c9c",
							"prob_bg_color" => "#dbdbdb"
						),
						"3" => array(
							"value" => "70",
							"value_color" => "#6b1807",
							"label" => "Marketing",
							"label_color" => "#0d6347",
							"prob_color" => "#1a6c9c",
							"prob_bg_color" => "#dbdbdb"
						)
					) ) ),
					'params' => array(
						array(
							'type' => 'text',
							'label' => __( 'Value', 'mini_composer' ),
							'name' => 'value',
							'description' => __( 'Enter value of bar from 1 to 100.', 'mini_composer' ),
							'admin_label' => true,
						),
						array(
							'type' => 'color_picker',
							'label' => __( 'Value Color', 'mini_composer' ),
							'name' => 'value_color',
							'description' => __( 'Value text color', 'mini_composer' ),
						),
						array(
							'type' => 'text',
							'label' => __( 'Label', 'mini_composer' ),
							'name' => 'label',
							'description' => __( 'Enter text used as title of bar.', 'mini_composer' ),
							'admin_label' => true,
						),
						array(
							'type' => 'color_picker',
							'label' => __( 'Label Color', 'mini_composer' ),
							'name' => 'label_color',
							'description' => __( 'Label text color', 'mini_composer' ),
						),
						array(
							'type' => 'color_picker',
							'label' => __( 'Progressbar Color', 'mini_composer' ),
							'name' => 'prob_color',
							'description' => __( 'Custom progress bar color.', 'mini_composer' ),
						),
						array(
							'type' => 'color_picker',
							'label' => __( 'Progressbar Background Color', 'mini_composer' ),
							'name' => 'prob_bg_color',
							'description' => __( 'Custom progress Background bar color.', 'mini_composer' ),
						),
					),
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Wrapper class name', 'mini_composer' ),
					'name'			=> 'wrap_class',
					'description'	=> __( 'Custom class for wrapper of shortcode widget', 'mini_composer' ),
				)
			)

		),

		'mini_button' => array(

			'name' => __('Button', 'mini_composer'),
			'description' => __('', 'mini_composer'),
			'icon' => 'mini-icon-button',
			'category' => 'Content',
			'params' => array(

				array(
					'type'			=> 'text',
					'label'			=> __( 'Title', 'mini_composer' ),
					'name'			=> 'text_title',
					'description'	=> __( 'Text on the button', 'mini_composer' ),
					'value' 			=> 'Text title',
					'admin_label'	=> true
				),
				array(
					'type'			=> 'link',
					'label'			=> __( 'Link', 'mini_composer' ),
					'name'			=> 'link',
					'description'	=> __( 'Link object include link, text and target', 'mini_composer' ),
				),
				array(
					'type'			=> 'number_slider',
					'label'			=> __( 'Border radius', 'mini_composer' ),
					'name'			=> 'border_radius',
					'description'	=> __( 'Border radius button', 'mini_composer' ),
					'value'			=> 3,
					'options' => array(
						'min' => 1,
						'max' => 20,
						'unit' => 'px',
						'show_input' => true,
					)
				),
				array(
					'type'			=> 'dropdown',
					'label'			=> __( 'Button size', 'mini_composer' ),
					'name'			=> 'size',
					'description'	=> __( 'Size of the button', 'mini_composer' ),
					'options'		=> array(
						'small' => __('Small', 'mini_composer'),
						'normal' => __('Normal', 'mini_composer'),
						'large' => __('Large', 'mini_composer'),
						'custom' => __('Custom padding, front-size', 'mini_composer'),
					),
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Padding', 'mini_composer' ),
					'name'			=> 'padding_button',
					'description'	=> __( 'The CSS padding properties are used to generate space around content, (top, right, bottom, and left) . For example: "10px 25px" or "10px 25px 10px 25px"', 'mini_composer' ),
					'relation'	=> array(
						'parent'	=> 'size',
						'show_when'	=> 'custom'
					),
					'value'			=> '10px 25px 10px 25px'
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Front size', 'mini_composer' ),
					'name'			=> 'font_size_button',
					'description'	=> __( 'Font size for text in the button. For example: 14px', 'mini_composer' ),
					'relation'	=> array(
						'parent'	=> 'size',
						'show_when'	=> 'custom'
					),
					'value'			=> '14px'
				),
				array(
					'type' 			=> 'checkbox',
					'label'			=> __( 'Custom style', 'mini_composer' ),
					'name'			=> 'custom_style',
					'description'	=> __('Checked show all depended params', 'mini_composer'),
					'options'			=> array( 'yes' => __( 'Yes, Please!', 'mini_composer' ) )
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Background color', 'mini_composer' ),
					'name'			=> 'bg_color',
					'description'	=> __( 'Button background color', 'mini_composer' ),
					'relation'	=> array(
						'parent'	=> 'custom_style',
						'show_when'	=> 'yes'
					),
					'value'			=> '#393939'
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Background color hover', 'mini_composer' ),
					'name'			=> 'bg_color_hover',
					'description'	=> __( 'Button background color hover', 'mini_composer' ),
					'relation'	=> array(
						'parent'	=> 'custom_style',
						'show_when'	=> 'yes'
					),
					'value'			=> '#FFFFFF'
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Text color', 'mini_composer' ),
					'name'			=> 'text_color',
					'description'	=> __( 'Text color button', 'mini_composer' ),
					'relation'	=> array(
						'parent'	=> 'custom_style',
						'show_when'	=> 'yes'
					),
					'value'			=> '#FFFFFF'
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Text color hover', 'mini_composer' ),
					'name'			=> 'text_color_hover',
					'description'	=> __( 'Text color button when hover', 'mini_composer' ),
					'relation'	=> array(
						'parent'	=> 'custom_style',
						'show_when'	=> 'yes'
					),
					'value'			=> '#393939'
				),
				array(
					'type' 			=> 'checkbox',
					'name' 			=> 'show_icon',
					'label' 		=> __( 'Show Icon?', 'mini_composer' ),
					'description' 	=> '',
					'options' 		=> array(
						'yes' => __('Yes, Please', 'mini_composer'),
					)
				),
				array(
					'type' 			=> 'icon_picker',
					'name'		 	=> 'icon',
					'label' 		=> __( 'Icon', 'mini_composer' ),
					'admin_label' 	=> true,
					'description' 	=> __( 'Select icon for button', 'mini_composer' ),
					'relation'		=> array(
						'parent'	=> 'show_icon',
						'show_when'	=> 'yes'
					)
				),
				array(
					'type' => 'dropdown',
					'name' => 'icon_position',
					'label' => __( 'Icon position', 'mini_composer' ),
					'description' => '',
					'options' => array(
						'left' => __('Left', 'mini_composer'),
						'center' => __('Center without text', 'mini_composer'),
						'right' => __('Right', 'mini_composer'),
					),
					'relation'		=> array(
						'parent'	=> 'show_icon',
						'show_when'	=> 'yes'
					)
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Wrapper class name', 'mini_composer' ),
					'name'			=> 'wrap_class',
					'description'	=> __( 'Custom class for wrapper of shortcode widget', 'mini_composer' ),
				),
			)
		),

		'mini_video_play' => array(

			'name' => __('Video Player', 'mini_composer'),
			'description' => __('', 'mini_composer'),
			'icon' => 'mini-icon-play',
			'category' => 'Content',
			'css_box' => true,
			'params' => array(

				array(
					'type'			=> 'text',
					'label'			=> __( 'Video link', 'mini_composer' ),
					'name'			=> 'video_link',
					'description'	=> __( 'Enter url from youtube or vimeo. For example: https://www.youtube.com/watch?v=iNJdPyoqt8U', 'mini_composer' ),
					'admin_label'	=> true,
					'value'			=> 'https://www.youtube.com/watch?v=iNJdPyoqt8U'
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Title', 'mini_composer' ),
					'name'			=> 'title',
					'description'	=> __( 'Enter title for this video, Leave it for hidden', 'mini_composer' ),
				),
				array(
					'type'			=> 'textarea',
					'label'			=> __( 'Description', 'mini_composer' ),
					'name'			=> 'description',
					'description'	=> __( 'This is some text description for video', 'mini_composer' ),
				),
				array(
					'type' 			=> 'checkbox',
					'name' 	=> 'full_width',
					'label' 		=> __( 'Video Fullwidth', 'mini_composer' ),
					'description' 	=> __('Video width will fit with parent wrapper when checked this', 'mini_composer'),
					'options' 		=> array(
						'yes' => __('Yes, Please!', 'mini_composer'),
					)
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Video Width', 'mini_composer' ),
					'name'			=> 'video_width',
					'description'	=> __( 'Width for this video', 'mini_composer' ),
					'value'			=> 600,
					'relation'		=> array(
						'parent'	=> 'full_width',
						'hide_when' => 'yes'
					)
				),
				array(
					'type' 			=> 'checkbox',
					'name' 	=> 'auto_play',
					'label' 		=> __( 'Auto Play', 'mini_composer' ),
					'description' 	=> __('Auto play video', 'mini_composer'),
					'options' 		=> array(
						'yes' => __('Yes, Please!', 'mini_composer'),
					)
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Wrapper class name', 'mini_composer' ),
					'name'			=> 'wrap_class',
					'description'	=> __( 'Custom class for wrapper of shortcode widget', 'mini_composer' ),
				),
			)

		),
		'mini_counter_box' => array(

			'name' => __('Counter Box', 'mini_composer'),
			'description' => __('', 'mini_composer'),
			'icon' => 'mini-icon-counter',
			'category' => 'Content',
			'params'		=> array(
				array(
					'type'			=> 'text',
					'label'			=> __( 'Number', 'mini_composer' ),
					'name'			=> 'number',
					'description'	=> __( 'Number count up animate', 'mini_composer' ),
					'admin_label'	=> true,
					'value'			=> '100'
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Label', 'mini_composer' ),
					'name'			=> 'label',
					'description'	=> __( 'This is short text description for count number', 'mini_composer' ),
					'admin_label'	=> true,
					'value'			=> 'Percent number'
				),
				array(
					'type' 			=> 'checkbox',
					'name' 			=> 'label_above',
					'label' 		=> __( 'Label above number', 'mini_composer' ),
					'description' 	=> __('Label above number, default "under" number', 'mini_composer'),
					'options' 		=> array(
						'yes' => __('Yes, Please!', 'mini_composer'),
					)
				),
				array(
					'type'			=> 'dropdown',
					'label'			=> __( 'Style', 'mini_composer' ),
					'name'			=> 'style',
					'description'	=> __( 'Select style display counter box', 'mini_composer' ),
					'options' => array(
						'1' => __( 'Style 1 (No icon)', 'mini_composer' ),
						'2' => __( 'Style 2 (Box and icon)', 'mini_composer' ),
						'3' => __( 'Style 3 (Icon & title)', 'mini_composer' )
					),
				),
				array(
					'type'			=> 'icon_picker',
					'label'			=> __( 'Icon', 'mini_composer' ),
					'name'			=> 'icon',
					'description'	=> __( 'Icon in counter box', 'mini_composer' ),
					'relation'		=> array(
						'parent'	=> 'style',
						'show_when'	=> array( '2', '3' )
					)
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Number color', 'mini_composer' ),
					'name'			=> 'number_color',
					'description'	=> __( '', 'mini_composer' ),
					'value'			=> '#393939'
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Label color', 'mini_composer' ),
					'name'			=> 'label_color',
					'description'	=> __( '', 'mini_composer' ),
					'value'			=> '#393939'
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Icon color', 'mini_composer' ),
					'name'			=> 'icon_color',
					'description'	=> __( '', 'mini_composer' ),
					'value'			=> '#393939',
					'relation'		=> array(
						'parent'	=> 'style',
						'show_when'	=> array( '2', '3')
					)
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Box background color', 'mini_composer' ),
					'name'			=> 'box_bg_color',
					'description'	=> __( '', 'mini_composer' ),
					'value'			=> '#d9d9d9',
					'relation'		=> array(
						'parent'	=> 'style',
						'show_when' => '2'
					)
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Wrapper class name', 'mini_composer' ),
					'name'			=> 'wrap_class',
					'description'	=> __( 'Custom class for wrapper of shortcode widget', 'mini_composer' ),
				),
			)

		),

		'mini_post_type_list' => array(

			'name' => __('Post Type List', 'mini_composer'),
			'description' => __('', 'mini_composer'),
			'icon' => 'mini-icon-post',
			'category' => 'Content',
			'params'		=> array(

				array(
					'type'			=> 'text',
					'label'			=> __( 'Title', 'mini_composer' ),
					'name'			=> 'title',
					'description'	=> __( 'This is text title. Leave blank if no title is needed.', 'mini_composer' ),
					'value'			=> __( 'Recent post title', 'mini_composer' ),
					'admin_label'	=> true
				),
				array(
					'type'			=> 'number_slider',
					'label'			=> __( 'Number post show', 'mini_composer' ),
					'name'			=> 'number_post',
					'description'	=> __( 'Display number of posts', 'mini_composer' ),
					'value'			=> '5',
					'admin_label'	=> true,
					'options' => array(
						'min' => 1,
						'max' => 12
					)
				),
				array(
					'type'			=> 'post_taxonomy',
					'label'			=> __( 'Content Type', 'mini_composer' ),
					'name'			=> 'post_taxonomy',
					'description'	=> __( '', 'mini_composer' ),
					'admin_label'	=> true
				),
				array(
					'type'			=> 'dropdown',
					'label'			=> __( 'Order by', 'mini_composer' ),
					'name'			=> 'order_by',
					'description'	=> __( '', 'mini_composer' ),
					'admin_label'	=> true,
					'options' 		=> array(
						'ID'		=> __('Post ID', 'mini_composer'),
						'author'	=> __('Author', 'mini_composer'),
						'title'		=> __('Title', 'mini_composer'),
						'name'		=> __('Post name (post slug)', 'mini_composer'),
						'type'		=> __('Post type (available since Version 4.0)', 'mini_composer'),
						'date'		=> __('Date', 'mini_composer'),
						'modified'	=> __('Last modified date', 'mini_composer'),
						'rand'		=> __('Random order', 'mini_composer'),
						'comment_count'	=> __('Number of comments', 'mini_composer')
					)
				),
				array(
					'type'			=> 'dropdown',
					'label'			=> __( 'Order post', 'mini_composer' ),
					'name'			=> 'order_list',
					'description'	=> __( '', 'mini_composer' ),
					'admin_label'	=> true,
					'options' 		=> array(
						'ASC'		=> __('ASC', 'mini_composer'),
						'DESC'		=> __('DESC', 'mini_composer'),
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show thumbnail', 'mini_composer' ),
					'name'			=> 'thumbnail',
					'description'	=> __( 'Show the post thumbnai', 'mini_composer' ),
					'options' 		=> array(
						 'yes' => __('Yes, Please!', 'mini_composer'),
					)
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Image size', 'mini_composer' ),
					'name'			=> 'image_size',
					'description'	=> __( 'Add your image size, For example: thumbnail, medium, large, full).', 'mini_composer' ),
					'value'			=> 'thumbnail',
					'relation' 	=> array(
						'parent'	=> 'thumbnail',
						'show_when'		=> 'yes'
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show date', 'mini_composer' ),
					'name'			=> 'show_date',
					'description'	=> __( 'Show the post date', 'mini_composer' ),
					'options' 		=> array(
						'yes' => __('Yes, Please!', 'mini_composer'),
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show author', 'mini_composer' ),
					'name'			=> 'show_author',
					'description'	=> __( 'Show the post author', 'mini_composer' ),
					'options' 		=> array(
						'yes' => __('Yes, Please!', 'mini_composer'),
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show tags', 'mini_composer' ),
					'name'			=> 'show_tags',
					'description'	=> __( 'Show the post tags', 'mini_composer' ),
					'options' 		=> array(
						'yes' => __('Yes, Please!', 'mini_composer'),
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show categories', 'mini_composer' ),
					'name'			=> 'show_category',
					'description'	=> __( 'Show the post categories', 'mini_composer' ),
					'options' 		=> array(
						'yes' => __('Yes, Please!', 'mini_composer'),
					)
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Number of words', 'mini_composer' ),
					'name'			=> 'number_word',
					'description'	=> __( 'number of words from content', 'mini_composer' ),
					'value'			=> '30'
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show read more button', 'mini_composer' ),
					'name'			=> 'show_button',
					'description'	=> __( 'Show the post categories', 'mini_composer' ),
					'options' 		=> array(
						'yes' => __('Yes, Please!', 'mini_composer'),
					),
					'value'			=> 'yes'
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Read more text', 'mini_composer' ),
					'name'			=> 'readmore_text',
					'description'	=> __( 'Read more text button', 'mini_composer' ),
					'relation'		=> array(
						'parent'	=> 'show_button',
						'show_when' => 'yes'
					),
					'value'			=> 'Read more'
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Wrapper class name', 'mini_composer' ),
					'name'			=> 'wrap_class',
					'description'	=> __( 'Custom class for wrapper of shortcode widget', 'mini_composer' ),
				)
			)
		),
		'mini_carousel_images' => array(

			'name' => __('Carousel Image', 'mini_composer'),
			'description' => __('', 'mini_composer'),
			'icon' => 'mini-icon-icarousel',
			'category' => 'Content',
			'params' => array(

				array(
					'type'			=> 'text',
					'label'			=> __( 'Title', 'mini_composer' ),
					'name'			=> 'title',
					'description'	=> __( 'This is text title. Leave blank if no title is needed.', 'mini_composer' ),
					'admin_label'	=> true
				),
				array(
					'type' 			=> 'attach_images',
					'label' 		=> __( 'Images', 'mini_composer' ),
					'name'			=> 'images',
					'description' 	=> __( 'Select images from media library.', 'mini_composer' ),
					'admin_label'	=> true
				),
				array(
					'type'        	=> 'text',
					'label'     	=> __( 'Image size', 'mini_composer' ),
					'name' 		 	=> 'img_size',
					'description' 	=> __( 'Enter image size. Example: thumbnail, medium, large, full.', 'mini_composer' ),
					'value'       	=> 'large',
				),
				array(
					'type'     		=> 'dropdown',
					'label'  	 	=> __( 'On click action', 'mini_composer' ),
					'name'			=> 'onclick',
					'options' 		=> array(
						'none' => __( 'None', 'mini_composer' ),
						'lightbox' => __( 'Open on lightbox', 'mini_composer' ),
						'custom_link' => __( 'Open custom links', 'mini_composer' )
					),
					'description'	=> __( 'Select action for click event.', 'mini_composer' )
				),
				array(
					'type' 			=> 'number_slider',
					'label' 		=> __( 'Items number', 'mini_composer' ),
					'name' 			=> 'items_number',
					'description' 	=> __( 'Number of item per slide', 'mini_composer' ),
					'admin_label'	=> true,
					'value'			=> '3',
					'options' => array(
						'min' => 1,
						'max' => 10
					)
				),
				array(
					'type' 			=> 'number_slider',
					'label' 		=> __( 'Speed', 'mini_composer' ),
					'name' 			=> 'speed',
					'description' 	=> __( 'Number of second for auto play slider', 'mini_composer' ),
					'value'			=> 5,
					'admin_label'	=> true,
					'options' => array(
						'min' => 1,
						'max' => 15,
						'unit' => 's'
					)
				),
				array(
					'type'        	=> 'textarea',
					'label'     	=> __( 'Custom links', 'mini_composer' ),
					'name'  	=> 'custom_links',
					'description' 	=> __( 'Enter links for each slide (Note: divide links with linebreaks (Enter)).', 'mini_composer' ),
					'relation'  	=> array(
						'parent'	=> 'onclick',
						'show_when' => 'custom_link'
					)
				),
				array(
					'type'        	=> 'dropdown',
					'label'     	=> __( 'Custom link target', 'mini_composer' ),
					'name'  		=> 'custom_links_target',
					'description' 	=> __( 'Select how to open custom links.', 'mini_composer' ),
					'options'       	=> array(
						'_self' => __( 'Same window', 'mini_composer' ),
						'_blank' => __( 'New window', 'mini_composer' )
					),
					'relation'  	=> array(
						'parent'	=> 'onclick',
						'show_when' => 'custom_link'
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Navigation', 'mini_composer' ),
					'name'			=> 'navigation',
					'description'	=> __( 'Display "next" and "prev" buttons.', 'mini_composer' ),
					'options' 		=> array(
						'yes' => __('Yes, Please!', 'mini_composer'),
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Pagination', 'mini_composer' ),
					'name'			=> 'pagination',
					'description'	=> __( 'Show pagination.', 'mini_composer' ),
					'options' 		=> array(
						'yes' => __('Yes, Please!', 'mini_composer'),
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Auto height', 'mini_composer' ),
					'name'			=> 'auto_height',
					'description'	=> __( 'Add height to owl-wrapper-outer so you can use diffrent heights on slides. Use it only for one item per page setting.', 'mini_composer' ),
					'options' 		=> array(
						'yes' => __('Yes, Please!', 'mini_composer'),
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Auto Play', 'mini_composer' ),
					'name'			=> 'auto_play',
					'description'	=> __( 'Auto play when site loaded', 'mini_composer' ),
					'options' 		=> array(
						'yes' => __('Yes, Please!', 'mini_composer'),
					),
					'value'			=> 'yes'
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Progress Bar', 'mini_composer' ),
					'name'			=> 'progress_bar',
					'description'	=> __( 'Show or hide progress bar.', 'mini_composer' ),
					'options' 		=> array(
						'yes' => __('Yes, Please!', 'mini_composer'),
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show thumbnail', 'mini_composer' ),
					'name'			=> 'show_thumb',
					'description'	=> __( 'Show or hide thumbnail in carousel.', 'mini_composer' ),
					'options' 		=> array(
						'yes' => __('Yes, Please!', 'mini_composer'),
					)
				),
				array(
					'type' => 'text',
					'label' => __( 'Wrapper class name', 'mini_composer' ),
					'name' => 'wrap_class',
					'description' => __( 'Custom class for wrapper of shortcode widget', 'mini_composer' )
				),
			)

		),

		'mini_carousel_post' => array(

			'name' => __('Carousel Post', 'mini_composer'),
			'description' => __('', 'mini_composer'),
			'icon' => 'mini-icon-pcarousel',
			'category' => 'Content',
			'params' => array(

				array(
					'type'			=> 'text',
					'label'			=> __( 'Title', 'mini_composer' ),
					'name'			=> 'title',
					'description'	=> __( 'This is text title. Leave blank if no title is needed.', 'mini_composer' ),
					'admin_label'	=> true
				),
				array(
					'type'			=> 'post_taxonomy',
					'label'			=> __( 'Content Type', 'mini_composer' ),
					'name'			=> 'post_taxonomy',
					'description'	=> __( 'Content Type such as post, custom post type..etc..', 'mini_composer' ),
				),
				array(
					'type'			=> 'dropdown',
					'label'			=> __( 'Order by', 'mini_composer' ),
					'name'			=> 'order_by',
					'description'	=> __( '', 'mini_composer' ),
					'admin_label'	=> true,
					'options' 		=> array(
						'ID'		=> __('Post ID', 'mini_composer'),
						'author'	=> __('Author', 'mini_composer'),
						'title'		=> __('Title', 'mini_composer'),
						'name'		=> __('Post name (post slug)', 'mini_composer'),
						'type'		=> __('Post type (available since Version 4.0)', 'mini_composer'),
						'date'		=> __('Date', 'mini_composer'),
						'modified'	=> __('Last modified date', 'mini_composer'),
						'rand'		=> __('Random order', 'mini_composer'),
						'comment_count'	=> __('Number of comments', 'mini_composer')
					)
				),
				array(
					'type'			=> 'dropdown',
					'label'			=> __( 'Order post', 'mini_composer' ),
					'name'			=> 'order_list',
					'description'	=> __( '', 'mini_composer' ),
					'admin_label'	=> true,
					'options' 		=> array(
						'ASC'		=> __('ASC', 'mini_composer'),
						'DESC'		=> __('DESC', 'mini_composer'),
					)
				),
				array(
					'type'			=> 'number_slider',
					'label'			=> __( 'Number posts show', 'mini_composer' ),
					'name'			=> 'number_post',
					'description'	=> __( 'Number posts you want to show', 'mini_composer' ),
					'value'			=> '5',
					'admin_label'	=> true,
					'options' => array(
						'min' => 1,
						'max' => 20
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show thumbnail', 'mini_composer' ),
					'name'			=> 'thumbnail',
					'description'	=> __( 'Show the post thumbnail', 'mini_composer' ),
					'options' 		=> array(
						'yes'		=> __('Yes', 'mini_composer'),
					)
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Image size', 'mini_composer' ),
					'name'			=> 'image_size',
					'description'	=> __( 'Add your image size, For example: thumbnail, medium, large, full).', 'mini_composer' ),
					'value'			=> 'thumbnail',
					'relation' 	=> array(
						'parent'	=> 'thumbnail',
						'show_when'		=> 'yes'
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show date', 'mini_composer' ),
					'name'			=> 'show_date',
					'description'	=> __( 'Show the post date', 'mini_composer' ),
					'options' 		=> array(
						'yes' 		=> __('Yes', 'mini_composer'),
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Show read more button', 'mini_composer' ),
					'name'			=> 'show_button',
					'description'	=> __( 'Show or hide read more button', 'mini_composer' ),
					'options' 		=> array(
						'yes'		=> __('Yes', 'mini_composer'),
					),
					'value'			=> 'yes'
				),
				array(
					'type' 			=> 'number_slider',
					'label' 		=> __( 'Items per slide', 'mini_composer' ),
					'name' 	=> 'items_number',
					'description' 	=> __( 'Number of item per slide', 'mini_composer' ),
					'value'			=> '3',
					'options' => array(
						'min' => 1,
						'max' => 10
					)
				),
				array(
					'type' 			=> 'number_slider',
					'label' 		=> __( 'Speed', 'mini_composer' ),
					'name' 			=> 'speed',
					'description' 	=> __( 'Number of second for auto play slider', 'mini_composer' ),
					'value'			=> '5',
					'options' => array(
						'min' => 1,
						'max' => 15,
						'unit' => 's'
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Navigation', 'mini_composer' ),
					'name'			=> 'navigation',
					'description'	=> __( 'Display "next" and "prev" buttons.', 'mini_composer' ),
					'options' 		=> array(
						'yes'		=> __('Yes', 'mini_composer'),
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Pagination', 'mini_composer' ),
					'name'			=> 'pagination',
					'description'	=> __( 'Show pagination.', 'mini_composer' ),
					'options' 		=> array(
						'yes' 		=> __('Yes', 'mini_composer'),
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Auto height', 'mini_composer' ),
					'name'			=> 'auto_height',
					'description'	=> __( 'Add height to owl-wrapper-outer so you can use diffrent heights on slides. Use it only for one item per page setting.', 'mini_composer' ),
					'options' 		=> array(
						'yes' 		=> __('Yes, Please!', 'mini_composer'),
					),
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Auto Play', 'mini_composer' ),
					'name'			=> 'auto_play',
					'description'	=> __( 'Auto play when site loaded', 'mini_composer' ),
					'options' 		=> array(
						'yes' 		=> __('Yes, Please!', 'mini_composer'),
					),
					'value'			=> 'yes'
				),
				array(
					'type' => 'text',
					'label' => __( 'Wrapper class name', 'mini_composer' ),
					'name' => 'wrap_class',
					'description' => __( 'Custom class for wrapper of shortcode widget', 'mini_composer' )
				),

			)
		),

		'mini_image_gallery' => array(

			'name' => __('Image Gallery', 'mini_composer'),
			'description' => __('', 'mini_composer'),
			'icon' => 'mini-icon-gallery',
			'category' => 'Content',
			'params' => array(

				array(
					'type'			=> 'text',
					'label'			=> __( 'Title', 'mini_composer' ),
					'name'			=> 'title',
					'description'	=> __( 'This is text title. Leave blank if no title is needed.', 'mini_composer' ),
					'admin_label'	=> true
				),
				array(
					'type'			=> 'attach_images',
					'label'			=> __( 'Images', 'mini_composer' ),
					'name'			=> 'images',
					'description'	=> __( 'Upload multiple image for carousel', 'mini_composer' ),
					'admin_label'	=> true
				),
				array(
					'type'			=> 'dropdown',
					'label'			=> __( 'Gallery type', 'mini_composer' ),
					'name'			=> 'type',
					'description'	=> __( 'Select gallery style type', 'mini_composer' ),
					'options' 		=> array(
						'grid' 		=> __( 'Images grid', 'mini_composer' ),
						'slider' 	=> __( 'Slider', 'mini_composer' ),
					),
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Image masonry', 'mini_composer' ),
					'name'			=> 'image_masonry',
					'description'	=> __( 'Masonry is a JavaScript grid layout library. It works by placing elements in optimal position based on available vertical space, sort of like a mason fitting stones in a wall.', 'mini_composer' ),
					'options' 		=> array(
						'yes' 		=> __('Yes', 'mini_composer'),
					),
					'relation' 	=> array(
						'parent'	=> 'type',
						'show_when' => array('grid')
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Auto Play', 'mini_composer' ),
					'name'			=> 'auto_rotate',
					'description'	=> __( 'Auto Play on slider type', 'mini_composer' ),
					'options' 		=> array(
						'yes' 		=> __('Yes', 'mini_composer'),
					),
					'relation' 	=> array(
						'parent'	=> 'type',
						'show_when' => array('slider')
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Navigation', 'mini_composer' ),
					'name'			=> 'navigation',
					'description'	=> __( 'Display "next" and "prev" buttons.', 'mini_composer' ),
					'options' 		=> array(
						'yes' 		=> __('Yes', 'mini_composer'),
					),
					'relation' 	=> array(
						'parent'	=> 'type',
						'show_when' => array('slider')
					)
				),
				array(
					'type'			=> 'checkbox',
					'label'			=> __( 'Pagination', 'mini_composer' ),
					'name'			=> 'pagination',
					'description'	=> __( 'Show pagination.', 'mini_composer' ),
					'options' 		=> array(
						'yes' 		=> __('Yes', 'mini_composer'),
					),
					'relation' 	=> array(
						'parent'	=> 'type',
						'show_when' => array('slider')
					)
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Slider width', 'mini_composer' ),
					'name'			=> 'slider_width',
					'description'	=> __( 'Wrapper slider width, unit (px)', 'mini_composer' ),
					'relation' 	=> array(
						'parent'	=> 'type',
						'show_when' => array('slider')
					),
					'value'			=> '400'
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Image size', 'mini_composer' ),
					'name'			=> 'image_size',
					'description'	=> __( 'Add your image size, For example: thumbnail, medium, large, full).', 'mini_composer' ),
					'value'			=> 'full'
				),
				array(
					'type'			=> 'dropdown',
					'label'			=> __( 'Click on image action', 'mini_composer' ),
					'name'			=> 'click_action',
					'description'	=> __( 'Action click on image.', 'mini_composer' ),
					'options' 		=> array(
						'none' 			=> __( 'No action', 'mini_composer' ),
						'large_image' 	=> __( 'Open large image', 'mini_composer' ),
						'lightbox' 		=> __( 'Open on lightbox', 'mini_composer' ),
						'custom_link' 	=> __( 'Open on custom link', 'mini_composer' )
					),
					'relation' 	=> array(
						'parent'	=> 'type',
						'show_when' => 'grid'
					)
				),
				array(
					'type'			=> 'textarea',
					'label'			=> __( 'Custom links', 'mini_composer' ),
					'name'			=> 'custom_links',
					'description'	=> __( 'Each custom link per new line and corresponding to each image uploaded', 'mini_composer' ),
					'relation'	=> array(
						'parent'	=> 'click_action',
						'show_when'	=> 'custom_link'
					)
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Wrapper class name', 'mini_composer' ),
					'name'			=> 'wrap_class',
					'description'	=> __( 'Custom class for wrapper of shortcode widget', 'mini_composer' ),
				),


			)
		),

		'mini_coundown_timer' => array(
			'name' => __('Countdown Timer', 'mini_composer'),
			'description' => __('', 'mini_composer'),
			'icon' => 'mini-icon-coundown',
			'category' => 'Content',
			'css_box' => true,
			'system_only' => true,
			'params' => array(

				array(
					'type'			=> 'text',
					'label'			=> __( 'Title', 'mini_composer' ),
					'name'			=> 'title',
					'description'	=> __( 'This is text title. Leave blank if no title is needed.', 'mini_composer' ),
					'admin_label'	=> true
				),
				array(
					'type'			=> 'dropdown',
					'label'			=> __( 'Timer Style', 'mini_composer' ),
					'name'			=> 'timer_style',
					'options'		=> array(
						'1' => __( 'Digit and Unit Side by Side', 'mini_composer' ),
						'2' => __( 'Digit and Unit Up and Down', 'mini_composer' ),
						'3' => __( 'Custom style template', 'mini_composer' )
					),
					'description'	=> __( 'Select style for countdown timer.', 'mini_composer' ),
				),
				array(
					'type'			=> 'textarea',
					'label'			=> __( 'Custom template', 'mini_composer' ),
					'name'			=> 'custom_template',
					'description'	=> __( "For example: %D days %H:%M:%S.\n --- %Y: \"years\", %m: \"months\", %n: \"daysToMonth\", %w: \"weeks\", %d: \"daysToWeek\", %D: \"totalDays\", %H: \"hours\", %M: \"minutes\", %S: \"seconds\"", 'mini_composer' ),
					'relation'	=> array(
						'parent'	=> 'timer_style',
						'show_when'	=> '3'
					)
				),
				array(
					'type'			=> 'date_picker',
					'label'			=> __( 'Date time', 'mini_composer' ),
					'name'			=> 'datetime',
					'description'	=> __( 'Target date For Countdown.', 'mini_composer' ),
					'admin_label'	=> true
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Background color group', 'mini_composer' ),
					'name'			=> 'bgcolor_group',
					'description'	=> __( 'Background color for each group (days, hours, minutes, seconds)', 'mini_composer' )
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Background color digit', 'mini_composer' ),
					'name'			=> 'bgcolor_digit',
					'description'	=> __( 'Background color for digit', 'mini_composer' ),
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Text Color', 'mini_composer' ),
					'name'			=> 'text_color',
					'description'	=> __( 'Timer Digit Text Color', 'mini_composer' ),
				),
				array(
					'type'			=> 'color_picker',
					'label'			=> __( 'Unit Color', 'mini_composer' ),
					'name'			=> 'unit_color',
					'description'	=> __( 'Timer Unit Text Color', 'mini_composer' ),
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Digit Text Size', 'mini_composer' ),
					'name'			=> 'digit_text_size',
					'description'	=> __( 'Timer Digit Text Size, Font size of digit text.', 'mini_composer' ),
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Unit Text Size', 'mini_composer' ),
					'name'			=> 'unit_text_size',
					'description'	=> __( 'Timer unit Text Size, Font size of unit text.', 'mini_composer' ),
				),
				array(
					'type'			=> 'text',
					'label'			=> __( 'Wrapper class name', 'mini_composer' ),
					'name'			=> 'wrap_class',
					'description'	=> __( 'Custom class for wrapper of shortcode widget', 'mini_composer' ),
				),
				array(
					'type' 			=> 'css_editor',
					'label' 		=> __( 'CSS box', 'mini_composer' ),
					'name' 			=> 'css',
					'description'	=> __( 'Default Design Options tab on VC, apply for wrapper of box', 'mini_composer' ),
					'group' 		=> __( 'Design Options', 'mini_composer' ),
				)

			)
		),

	)

);
